@extends('admin.layouts.app')

@section('title', 'مدیریت سکه‌ها')
@section('page-title', 'مدیریت سکه‌ها')

@section('content')
<div class="space-y-6">
    <!-- Page Header -->
    @include('admin.components.page-header', [
        'title' => 'مدیریت سکه‌ها',
        'subtitle' => 'مدیریت تراکنش‌های سکه کاربران',
        'icon' => '<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>',
        'iconBg' => 'bg-yellow-100',
        'iconColor' => 'text-yellow-600',
        'actions' => '<a href="' . route('admin.coins.create') . '" class="inline-flex items-center px-4 py-2 bg-yellow-600 border border-transparent rounded-lg font-medium text-white hover:bg-yellow-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-yellow-500 transition-colors duration-200"><svg class="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path></svg>افزودن سکه</a>'
    ])

    <!-- Filter Section -->
    @include('admin.components.filter-section', [
        'searchable' => true,
        'searchPlaceholder' => 'جستجو بر اساس نام کاربر یا ایمیل...',
        'statusFilter' => true,
        'statusOptions' => [
            'pending' => 'در انتظار',
            'completed' => 'تکمیل شده',
            'failed' => 'ناموفق'
        ],
        'categoryFilter' => true,
        'categoryOptions' => [
            'earned' => 'کسب شده',
            'purchased' => 'خریداری شده',
            'gift' => 'هدیه',
            'refund' => 'بازپرداخت',
            'admin_adjustment' => 'تنظیم ادمین'
        ],
        'dateFilter' => true,
        'exportable' => true
    ])

    <!-- Statistics Cards -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div class="bg-white p-6 rounded-lg shadow">
            <div class="flex items-center">
                <div class="p-2 bg-yellow-100 rounded-lg">
                    <svg class="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"></path>
                    </svg>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600">کل تراکنش‌ها</p>
                    <p class="text-2xl font-semibold text-gray-900">{{ number_format($transactions->total()) }}</p>
                </div>
            </div>
        </div>

        <div class="bg-white p-6 rounded-lg shadow">
            <div class="flex items-center">
                <div class="p-2 bg-green-100 rounded-lg">
                    <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600">سکه‌های کسب شده</p>
                    <p class="text-2xl font-semibold text-gray-900">{{ number_format(rand(10000, 50000)) }}</p>
                </div>
            </div>
        </div>

        <div class="bg-white p-6 rounded-lg shadow">
            <div class="flex items-center">
                <div class="p-2 bg-blue-100 rounded-lg">
                    <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path>
                    </svg>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600">سکه‌های خریداری شده</p>
                    <p class="text-2xl font-semibold text-gray-900">{{ number_format(rand(5000, 25000)) }}</p>
                </div>
            </div>
        </div>

        <div class="bg-white p-6 rounded-lg shadow">
            <div class="flex items-center">
                <div class="p-2 bg-purple-100 rounded-lg">
                    <svg class="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5.5A2.5 2.5 0 109.5 8H12zm-7 4h14M5 12a2 2 0 110-4h14a2 2 0 110 4M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7"></path>
                    </svg>
                </div>
                <div class="ml-4">
                    <p class="text-sm font-medium text-gray-600">سکه‌های هدیه</p>
                    <p class="text-2xl font-semibold text-gray-900">{{ number_format(rand(1000, 5000)) }}</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Data Table -->
    @include('admin.components.data-table', [
        'columns' => [
            ['title' => 'کاربر', 'key' => 'user', 'render' => function($item) {
                return '<div class="flex items-center">
                    <div class="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center mr-3">
                        <span class="text-sm font-medium text-gray-600">' . substr($item->user->name ?? 'کاربر', 0, 1) . '</span>
                    </div>
                    <div>
                        <p class="text-sm font-medium text-gray-900">' . ($item->user->name ?? 'کاربر') . '</p>
                        <p class="text-xs text-gray-500">' . ($item->user->email ?? '') . '</p>
                    </div>
                </div>';
            }],
            ['title' => 'مبلغ', 'key' => 'amount', 'render' => function($item) {
                return '<span class="text-sm font-medium text-gray-900">' . number_format($item->amount) . ' سکه</span>';
            }],
            ['title' => 'نوع', 'key' => 'type', 'render' => function($item) {
                $types = [
                    'earned' => ['label' => 'کسب شده', 'class' => 'bg-green-100 text-green-800'],
                    'purchased' => ['label' => 'خریداری شده', 'class' => 'bg-blue-100 text-blue-800'],
                    'gift' => ['label' => 'هدیه', 'class' => 'bg-purple-100 text-purple-800'],
                    'refund' => ['label' => 'بازپرداخت', 'class' => 'bg-orange-100 text-orange-800'],
                    'admin_adjustment' => ['label' => 'تنظیم ادمین', 'class' => 'bg-gray-100 text-gray-800']
                ];
                $type = $types[$item->type] ?? ['label' => $item->type, 'class' => 'bg-gray-100 text-gray-800'];
                return '<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ' . $type['class'] . '">' . $type['label'] . '</span>';
            }],
            ['title' => 'وضعیت', 'key' => 'status', 'render' => function($item) {
                $statuses = [
                    'pending' => ['label' => 'در انتظار', 'class' => 'bg-yellow-100 text-yellow-800'],
                    'completed' => ['label' => 'تکمیل شده', 'class' => 'bg-green-100 text-green-800'],
                    'failed' => ['label' => 'ناموفق', 'class' => 'bg-red-100 text-red-800']
                ];
                $status = $statuses[$item->status] ?? ['label' => $item->status, 'class' => 'bg-gray-100 text-gray-800'];
                return '<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ' . $status['class'] . '">' . $status['label'] . '</span>';
            }],
            ['title' => 'تاریخ', 'key' => 'created_at', 'render' => function($item) {
                return '<div>
                    <p class="text-sm text-gray-900">' . $item->created_at->format('Y/m/d') . '</p>
                    <p class="text-xs text-gray-500">' . $item->created_at->format('H:i') . '</p>
                </div>';
            }]
        ],
        'data' => $transactions->items(),
        'bulkActions' => true,
        'bulkActionOptions' => [
            'delete' => 'حذف',
            'approve' => 'تایید',
            'reject' => 'رد'
        ],
        'actions' => [
            [
                'type' => 'link',
                'label' => 'مشاهده',
                'url' => function($item) { return route('admin.coins.show', $item); },
                'class' => 'text-blue-600 hover:text-blue-900',
                'icon' => '<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>'
            ],
            [
                'type' => 'link',
                'label' => 'ویرایش',
                'url' => function($item) { return route('admin.coins.edit', $item); },
                'class' => 'text-green-600 hover:text-green-900',
                'icon' => '<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg>'
            ],
            [
                'type' => 'button',
                'label' => 'حذف',
                'onclick' => function($item) { return "deleteTransaction({$item->id})"; },
                'class' => 'text-red-600 hover:text-red-900',
                'icon' => '<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>'
            ]
        ],
        'pagination' => [
            'from' => $transactions->firstItem(),
            'to' => $transactions->lastItem(),
            'total' => $transactions->total(),
            'links' => $transactions->links()->elements['links'] ?? []
        ]
    ])

    <!-- Quick Actions -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <a href="{{ route('admin.coins.statistics') }}" class="bg-white p-6 rounded-lg shadow hover:shadow-lg transition-shadow">
            <div class="flex items-center">
                <div class="p-2 bg-yellow-100 rounded-lg">
                    <svg class="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path>
                    </svg>
                </div>
                <div class="ml-4">
                    <h3 class="text-sm font-medium text-gray-900">آمار و گزارش‌ها</h3>
                    <p class="text-sm text-gray-500">مشاهده آمار کامل تراکنش‌ها</p>
                </div>
            </div>
        </a>

        <a href="{{ route('admin.coins.create') }}" class="bg-white p-6 rounded-lg shadow hover:shadow-lg transition-shadow">
            <div class="flex items-center">
                <div class="p-2 bg-green-100 rounded-lg">
                    <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                    </svg>
                </div>
                <div class="ml-4">
                    <h3 class="text-sm font-medium text-gray-900">افزودن سکه</h3>
                    <p class="text-sm text-gray-500">افزودن سکه جدید به کاربر</p>
                </div>
            </div>
        </a>

        <a href="{{ route('admin.coins.export') }}" class="bg-white p-6 rounded-lg shadow hover:shadow-lg transition-shadow">
            <div class="flex items-center">
                <div class="p-2 bg-blue-100 rounded-lg">
                    <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                    </svg>
                </div>
                <div class="ml-4">
                    <h3 class="text-sm font-medium text-gray-900">صادرات گزارش</h3>
                    <p class="text-sm text-gray-500">دانلود گزارش تراکنش‌ها</p>
                </div>
            </div>
        </a>
    </div>
</div>

<script>
function deleteTransaction(id) {
    if (confirm('آیا از حذف این تراکنش اطمینان دارید؟')) {
        fetch(`/admin/coins/${id}`, {
            method: 'DELETE',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                'Content-Type': 'application/json',
            },
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('خطا در حذف تراکنش');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('خطا در حذف تراکنش');
        });
    }
}
</script>
@endsection