-- MySQL dump 10.13  Distrib 8.0.35, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: sarvca_st
-- ------------------------------------------------------
-- Server version	8.0.35-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `achievements`
--

DROP TABLE IF EXISTS `achievements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `achievements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `badge_color` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#3B82F6',
  `category` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `criteria` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `points` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_hidden` tinyint(1) NOT NULL DEFAULT '0',
  `sort_order` int NOT NULL DEFAULT '0',
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `achievements_slug_unique` (`slug`),
  KEY `achievements_category_is_active_index` (`category`,`is_active`),
  KEY `achievements_type_is_active_index` (`type`,`is_active`),
  KEY `achievements_points_is_active_index` (`points`,`is_active`),
  CONSTRAINT `achievements_chk_1` CHECK (json_valid(`criteria`)),
  CONSTRAINT `achievements_chk_2` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `achievements`
--

LOCK TABLES `achievements` WRITE;
/*!40000 ALTER TABLE `achievements` DISABLE KEYS */;
/*!40000 ALTER TABLE `achievements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `affiliate_partners`
--

DROP TABLE IF EXISTS `affiliate_partners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `affiliate_partners` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` enum('teacher','influencer','school','corporate') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tier` enum('micro','mid','macro','enterprise') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','active','suspended','terminated') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `commission_rate` decimal(5,2) NOT NULL DEFAULT '0.00',
  `follower_count` int DEFAULT NULL,
  `social_media_handle` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bio` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `website` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `verification_documents` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `is_verified` tinyint(1) NOT NULL DEFAULT '0',
  `verified_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `affiliate_partners_email_unique` (`email`),
  KEY `affiliate_partners_type_status_index` (`type`,`status`),
  KEY `affiliate_partners_tier_status_index` (`tier`,`status`),
  CONSTRAINT `affiliate_partners_chk_1` CHECK (json_valid(`verification_documents`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `affiliate_partners`
--

LOCK TABLES `affiliate_partners` WRITE;
/*!40000 ALTER TABLE `affiliate_partners` DISABLE KEYS */;
/*!40000 ALTER TABLE `affiliate_partners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `api_performance_logs`
--

DROP TABLE IF EXISTS `api_performance_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_performance_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `endpoint` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `method` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_code` int NOT NULL,
  `response_time` decimal(8,3) NOT NULL,
  `memory_usage` int DEFAULT NULL,
  `user_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `response_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `requested_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `api_performance_logs_endpoint_requested_at_index` (`endpoint`,`requested_at`),
  KEY `api_performance_logs_status_code_requested_at_index` (`status_code`,`requested_at`),
  KEY `api_performance_logs_response_time_requested_at_index` (`response_time`,`requested_at`),
  KEY `api_performance_logs_requested_at_index` (`requested_at`),
  CONSTRAINT `api_performance_logs_chk_1` CHECK (json_valid(`request_data`)),
  CONSTRAINT `api_performance_logs_chk_2` CHECK (json_valid(`response_data`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_performance_logs`
--

LOCK TABLES `api_performance_logs` WRITE;
/*!40000 ALTER TABLE `api_performance_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `api_performance_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_versions`
--

DROP TABLE IF EXISTS `app_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_versions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `build_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `platform` enum('android','ios','web','all') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'all',
  `billing_platform` enum('website','cafebazaar','myket') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_config` json DEFAULT NULL,
  `update_type` enum('optional','forced','maintenance') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'optional',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `changelog` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `update_notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `download_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website_update_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cafebazaar_update_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `myket_update_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `minimum_os_version` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `compatibility` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_latest` tinyint(1) NOT NULL DEFAULT '0',
  `release_date` timestamp NULL DEFAULT NULL,
  `effective_date` timestamp NULL DEFAULT NULL,
  `expiry_date` timestamp NULL DEFAULT NULL,
  `force_update_date` timestamp NULL DEFAULT NULL,
  `priority` int NOT NULL DEFAULT '0',
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `app_versions_version_unique` (`version`),
  KEY `app_versions_platform_is_active_index` (`platform`,`is_active`),
  KEY `app_versions_platform_is_latest_index` (`platform`,`is_latest`),
  KEY `app_versions_update_type_is_active_index` (`update_type`,`is_active`),
  KEY `app_versions_release_date_index` (`release_date`),
  KEY `app_versions_effective_date_index` (`effective_date`),
  KEY `app_versions_expiry_date_index` (`expiry_date`),
  KEY `app_versions_billing_platform_index` (`billing_platform`),
  CONSTRAINT `app_versions_chk_1` CHECK (json_valid(`compatibility`)),
  CONSTRAINT `app_versions_chk_2` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_versions`
--

LOCK TABLES `app_versions` WRITE;
/*!40000 ALTER TABLE `app_versions` DISABLE KEYS */;
INSERT INTO `app_versions` VALUES (3,'1.3.0+5','1','android',NULL,NULL,'optional','نسخه جدید',NULL,NULL,NULL,'https://my.sarvcast.ir',NULL,NULL,NULL,NULL,'[\"android\"]',1,0,NULL,NULL,NULL,NULL,50,NULL,'2025-10-13 00:28:30','2025-11-26 15:39:34'),(4,'1.3.2+6','6','android',NULL,NULL,'optional','نسخه 1.3.2',NULL,NULL,NULL,'https://www.sarvcast.ir/',NULL,NULL,NULL,NULL,'[\"android\"]',1,0,'2025-12-18 00:00:00',NULL,NULL,'2025-12-30 00:00:00',50,NULL,'2025-11-26 15:39:34','2025-12-18 12:28:50');
/*!40000 ALTER TABLE `app_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backups`
--

DROP TABLE IF EXISTS `backups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backups` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `type` enum('database','files','config','full') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'full',
  `include_files` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `exclude_files` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `compression` tinyint(1) NOT NULL DEFAULT '0',
  `encryption` tinyint(1) NOT NULL DEFAULT '0',
  `schedule` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','in_progress','completed','failed','cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `file_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` bigint DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `error_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `backups_status_type_index` (`status`,`type`),
  KEY `backups_created_at_status_index` (`created_at`,`status`),
  KEY `backups_created_by_foreign` (`created_by`),
  CONSTRAINT `backups_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `backups_chk_1` CHECK (json_valid(`include_files`)),
  CONSTRAINT `backups_chk_2` CHECK (json_valid(`exclude_files`)),
  CONSTRAINT `backups_chk_3` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backups`
--

LOCK TABLES `backups` WRITE;
/*!40000 ALTER TABLE `backups` DISABLE KEYS */;
/*!40000 ALTER TABLE `backups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `badges`
--

DROP TABLE IF EXISTS `badges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `badges` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#3B82F6',
  `category` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `rarity` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `requirements` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_hidden` tinyint(1) NOT NULL DEFAULT '0',
  `sort_order` int NOT NULL DEFAULT '0',
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `badges_slug_unique` (`slug`),
  KEY `badges_category_is_active_index` (`category`,`is_active`),
  KEY `badges_rarity_is_active_index` (`rarity`,`is_active`),
  CONSTRAINT `badges_chk_1` CHECK (json_valid(`requirements`)),
  CONSTRAINT `badges_chk_2` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `badges`
--

LOCK TABLES `badges` WRITE;
/*!40000 ALTER TABLE `badges` DISABLE KEYS */;
/*!40000 ALTER TABLE `badges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES ('laravel-cache-admin:3:184.174.96.91','i:1;',1766052523),('laravel-cache-admin:3:45.93.170.110','i:9;',1766051637),('laravel-cache-api_api/v1/categories','a:3:{s:7:\"success\";b:1;s:7:\"message\";s:33:\"Categories retrieved successfully\";s:4:\"data\";a:4:{i:0;a:12:{s:2:\"id\";i:2;s:4:\"name\";s:18:\"ماجراجویی\";s:4:\"slug\";s:17:\"adventure-stories\";s:11:\"description\";s:93:\"داستان‌های هیجان‌انگیز و ماجراجویانه برای کودکان\";s:5:\"color\";s:7:\"#f59e0b\";s:6:\"status\";s:6:\"active\";s:5:\"order\";i:2;s:11:\"story_count\";i:1;s:9:\"icon_path\";s:107:\"categories/1759755571_20251006_1622_Magical Forest Adventure_simple_compose_01k6ws6nmjfvbtf6tk8vzj96mg.webp\";s:9:\"image_url\";s:137:\"https://my.sarvcast.ir/images/categories/1759755571_20251006_1622_Magical Forest Adventure_simple_compose_01k6ws6nmjfvbtf6tk8vzj96mg.webp\";s:10:\"created_at\";s:27:\"2025-10-05T16:27:24.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-28T20:32:46.000000Z\";}i:1;a:12:{s:2:\"id\";i:3;s:4:\"name\";s:12:\"آموزشی\";s:4:\"slug\";s:19:\"educational-stories\";s:11:\"description\";s:97:\"داستان‌هایی که مفاهیم آموزشی را به کودکان می‌آموزند\";s:5:\"color\";s:7:\"#10b981\";s:6:\"status\";s:6:\"active\";s:5:\"order\";i:3;s:11:\"story_count\";i:2;s:9:\"icon_path\";s:109:\"categories/1759755521_20251006_1624_Magical Classroom Learning_simple_compose_01k6wsa61tf2p9m2wvht6sye7n.webp\";s:9:\"image_url\";s:139:\"https://my.sarvcast.ir/images/categories/1759755521_20251006_1624_Magical Classroom Learning_simple_compose_01k6wsa61tf2p9m2wvht6sye7n.webp\";s:10:\"created_at\";s:27:\"2025-10-05T16:27:24.000000Z\";s:10:\"updated_at\";s:27:\"2025-12-18T09:52:57.000000Z\";}i:2;a:12:{s:2:\"id\";i:4;s:4:\"name\";s:12:\"فانتزی\";s:4:\"slug\";s:15:\"fantasy-stories\";s:11:\"description\";s:79:\"داستان‌های تخیلی و فانتزی با موجودات خیالی\";s:5:\"color\";s:7:\"#ec4899\";s:6:\"status\";s:6:\"active\";s:5:\"order\";i:4;s:11:\"story_count\";i:3;s:9:\"icon_path\";s:103:\"categories/1759755532_20251006_1622_Dreamy Fantasy Realm_simple_compose_01k6ws7jyfenj92cayqqbng186.webp\";s:9:\"image_url\";s:133:\"https://my.sarvcast.ir/images/categories/1759755532_20251006_1622_Dreamy Fantasy Realm_simple_compose_01k6ws7jyfenj92cayqqbng186.webp\";s:10:\"created_at\";s:27:\"2025-10-05T16:27:24.000000Z\";s:10:\"updated_at\";s:27:\"2025-12-18T09:34:18.000000Z\";}i:3;a:12:{s:2:\"id\";i:5;s:4:\"name\";s:14:\"حیوانات\";s:4:\"slug\";s:14:\"animal-stories\";s:11:\"description\";s:95:\"داستان‌هایی که شخصیت‌های اصلی آن‌ها حیوانات هستند\";s:5:\"color\";s:7:\"#f97316\";s:6:\"status\";s:6:\"active\";s:5:\"order\";i:5;s:11:\"story_count\";i:2;s:9:\"icon_path\";s:107:\"categories/1759755558_20251006_1624_Forest Friends Gathering_simple_compose_01k6wsa9reefd8a2dhgxhft2wk.webp\";s:9:\"image_url\";s:137:\"https://my.sarvcast.ir/images/categories/1759755558_20251006_1624_Forest Friends Gathering_simple_compose_01k6wsa9reefd8a2dhgxhft2wk.webp\";s:10:\"created_at\";s:27:\"2025-10-05T16:27:24.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:17:48.000000Z\";}}}',1766052319),('laravel-cache-api_api/v1/episodes/3_user_17','a:2:{s:7:\"success\";b:1;s:4:\"data\";a:3:{s:7:\"episode\";a:51:{s:2:\"id\";i:3;s:8:\"story_id\";i:7;s:11:\"narrator_id\";i:8;s:5:\"title\";s:40:\"کل داستان مداد رنگی ها\";s:11:\"description\";N;s:9:\"audio_url\";s:108:\"https://my.sarvcast.ir/storage/audio/episodes/audio_iH3J5SVoYdCyNP8OhfMsZRzGAuLw9Ipv-2025-10-06_16-51-34.mp3\";s:16:\"local_audio_path\";N;s:8:\"duration\";i:429;s:14:\"episode_number\";i:1;s:10:\"is_premium\";b:0;s:10:\"image_urls\";a:0:{}s:10:\"play_count\";i:28;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";N;s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";i:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:21:34.000000Z\";s:10:\"updated_at\";s:27:\"2025-12-18T09:54:32.000000Z\";s:25:\"has_multiple_voice_actors\";b:0;s:17:\"voice_actor_count\";i:0;s:18:\"use_image_timeline\";b:0;s:5:\"story\";a:52:{s:2:\"id\";i:7;s:5:\"title\";s:39:\"مداد رنگی‌های جادویی\";s:8:\"subtitle\";s:31:\"قدرت خلاقیت و هنر\";s:11:\"description\";s:490:\"سارا دختر نه ساله‌ای که جعبه‌ای از مدادهای رنگی جادویی را کشف می‌کند که می‌توانند هر چیزی که می‌کشند را زنده کنند. او از طریق ماجراهایش با این مدادهای جادویی درباره خلاقیت، همکاری و قدرت هنر می‌آموزد. این داستان جادویی کودکان را با دنیای بی‌نهایت خلاقیت آشنا می‌کند.\";s:9:\"image_url\";s:59:\"https://my.sarvcast.ir/images/stories/1759756511_cover.webp\";s:15:\"cover_image_url\";s:65:\"https://my.sarvcast.ir/images/stories/1759756511_cover_cover.webp\";s:11:\"category_id\";i:4;s:11:\"director_id\";N;s:9:\"writer_id\";N;s:9:\"author_id\";N;s:11:\"narrator_id\";N;s:9:\"age_group\";s:3:\"3-5\";s:8:\"language\";s:7:\"persian\";s:8:\"duration\";i:429;s:14:\"total_episodes\";i:1;s:13:\"free_episodes\";i:1;s:10:\"is_premium\";b:0;s:18:\"is_completely_free\";b:1;s:10:\"play_count\";i:0;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";a:1:{i:0;s:6:\"هنر\";}s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";b:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:15:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:18:\"use_image_timeline\";b:1;}s:8:\"narrator\";a:12:{s:2:\"id\";i:8;s:4:\"name\";s:21:\"سمانه اصغری\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:2:{i:0;s:11:\"voice_actor\";i:1;s:8:\"narrator\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:02:20.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:04:29.000000Z\";}s:6:\"people\";a:0:{}s:15:\"image_timelines\";a:19:{i:0;a:14:{s:2:\"id\";i:129;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:0;s:8:\"end_time\";i:69;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_kc9UyQRBv2FwjhH4egXdIibNWmoYxtPD-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:1;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:1;a:14:{s:2:\"id\";i:130;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:69;s:8:\"end_time\";i:117;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_cSGtbFj9nxoTwKkMe7v4356dRqpUQWVH-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:2;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:2;a:14:{s:2:\"id\";i:131;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:117;s:8:\"end_time\";i:127;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_DlZYf5H9VQ73gFpqzioJuahEOvrn8bsS-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:3;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:3;a:14:{s:2:\"id\";i:132;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:127;s:8:\"end_time\";i:139;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_bRVOBvsYpNmjdlL09Ef8MUFqxQona517-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:4;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:4;a:14:{s:2:\"id\";i:133;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:139;s:8:\"end_time\";i:151;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_ejAdyGfnaq6KgzZO7lEWcQ9t3BowHpUF-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:5;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:5;a:14:{s:2:\"id\";i:134;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:151;s:8:\"end_time\";i:161;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_NrLIRX1v8aGwbWCxmV9pHMJqY5FoShjB-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:6;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:6;a:14:{s:2:\"id\";i:135;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:161;s:8:\"end_time\";i:188;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_L5xEn2rAPjXTwDMmd7ivl4JHQC3U8sGW-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:7;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:7;a:14:{s:2:\"id\";i:136;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:188;s:8:\"end_time\";i:198;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_3qzxAKcYtjliJ7kUOQ6spLHC02VyfXW8-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:8;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:8;a:14:{s:2:\"id\";i:137;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:198;s:8:\"end_time\";i:216;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_kQsdfxX2PowV1HhlGcTu07pAENiIFj9a-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:9;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:9;a:14:{s:2:\"id\";i:138;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:216;s:8:\"end_time\";i:222;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_8KIYi3tcnb1AlGaSC5qy2HpzkRuUoFMN-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:10;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:10;a:14:{s:2:\"id\";i:139;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:222;s:8:\"end_time\";i:231;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_pTocV3qejaysbgKDAZYLBu51z6iPEWQI-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:11;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:11;a:14:{s:2:\"id\";i:140;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:231;s:8:\"end_time\";i:238;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_GT7AuvOFnzdIJ2DLx5QflCa168MgpNYR-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:12;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:12;a:14:{s:2:\"id\";i:141;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:238;s:8:\"end_time\";i:242;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_BFnyfGAKw0QodYpirs2Vzea6lEOvNcWX-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:13;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:13;a:14:{s:2:\"id\";i:142;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:242;s:8:\"end_time\";i:249;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_hYXgcu3ks1epiDHbaEFyKQG9ZltPJx7f-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:14;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:14;a:14:{s:2:\"id\";i:143;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:249;s:8:\"end_time\";i:261;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_hQw6RbzHa5CpgA8BsjDIiVoyuFxrvfYc-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:15;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:15;a:14:{s:2:\"id\";i:144;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:261;s:8:\"end_time\";i:279;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_E59iXT7pZauAYqKWBLgIbHmGMj6oJkwz-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:16;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:16;a:14:{s:2:\"id\";i:145;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:279;s:8:\"end_time\";i:302;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_tkRUrfZVE6Snd5yM2FeYBc1TipWuvsOh-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:17;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:17;a:14:{s:2:\"id\";i:146;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:302;s:8:\"end_time\";i:323;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_HJl3SiC1yRpnUe2qfrQgG0PMkFuBZ9c5-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:18;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:18;a:14:{s:2:\"id\";i:147;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:323;s:8:\"end_time\";i:429;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_9ijt3QmxPacpDUCf6X4ORndkY81eBq0r-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:19;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}}}s:11:\"access_info\";a:3:{s:10:\"has_access\";b:1;s:6:\"reason\";s:12:\"free_content\";s:7:\"message\";s:28:\"قسمت رایگان است\";}s:18:\"is_story_favorited\";b:0;}}',1766051895),('laravel-cache-api_api/v1/episodes/3_user_7','a:2:{s:7:\"success\";b:1;s:4:\"data\";a:3:{s:7:\"episode\";a:51:{s:2:\"id\";i:3;s:8:\"story_id\";i:7;s:11:\"narrator_id\";i:8;s:5:\"title\";s:40:\"کل داستان مداد رنگی ها\";s:11:\"description\";N;s:9:\"audio_url\";s:108:\"https://my.sarvcast.ir/storage/audio/episodes/audio_iH3J5SVoYdCyNP8OhfMsZRzGAuLw9Ipv-2025-10-06_16-51-34.mp3\";s:16:\"local_audio_path\";N;s:8:\"duration\";i:429;s:14:\"episode_number\";i:1;s:10:\"is_premium\";b:0;s:10:\"image_urls\";a:0:{}s:10:\"play_count\";i:27;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";N;s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";i:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:21:34.000000Z\";s:10:\"updated_at\";s:27:\"2025-12-18T06:39:24.000000Z\";s:25:\"has_multiple_voice_actors\";b:0;s:17:\"voice_actor_count\";i:0;s:18:\"use_image_timeline\";b:0;s:5:\"story\";a:52:{s:2:\"id\";i:7;s:5:\"title\";s:39:\"مداد رنگی‌های جادویی\";s:8:\"subtitle\";s:31:\"قدرت خلاقیت و هنر\";s:11:\"description\";s:490:\"سارا دختر نه ساله‌ای که جعبه‌ای از مدادهای رنگی جادویی را کشف می‌کند که می‌توانند هر چیزی که می‌کشند را زنده کنند. او از طریق ماجراهایش با این مدادهای جادویی درباره خلاقیت، همکاری و قدرت هنر می‌آموزد. این داستان جادویی کودکان را با دنیای بی‌نهایت خلاقیت آشنا می‌کند.\";s:9:\"image_url\";s:59:\"https://my.sarvcast.ir/images/stories/1759756511_cover.webp\";s:15:\"cover_image_url\";s:65:\"https://my.sarvcast.ir/images/stories/1759756511_cover_cover.webp\";s:11:\"category_id\";i:4;s:11:\"director_id\";N;s:9:\"writer_id\";N;s:9:\"author_id\";N;s:11:\"narrator_id\";N;s:9:\"age_group\";s:3:\"3-5\";s:8:\"language\";s:7:\"persian\";s:8:\"duration\";i:429;s:14:\"total_episodes\";i:1;s:13:\"free_episodes\";i:1;s:10:\"is_premium\";b:0;s:18:\"is_completely_free\";b:1;s:10:\"play_count\";i:0;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";a:1:{i:0;s:6:\"هنر\";}s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";b:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:15:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:18:\"use_image_timeline\";b:1;}s:8:\"narrator\";a:12:{s:2:\"id\";i:8;s:4:\"name\";s:21:\"سمانه اصغری\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:2:{i:0;s:11:\"voice_actor\";i:1;s:8:\"narrator\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:02:20.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:04:29.000000Z\";}s:6:\"people\";a:0:{}s:15:\"image_timelines\";a:19:{i:0;a:14:{s:2:\"id\";i:129;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:0;s:8:\"end_time\";i:69;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_kc9UyQRBv2FwjhH4egXdIibNWmoYxtPD-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:1;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:1;a:14:{s:2:\"id\";i:130;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:69;s:8:\"end_time\";i:117;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_cSGtbFj9nxoTwKkMe7v4356dRqpUQWVH-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:2;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:2;a:14:{s:2:\"id\";i:131;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:117;s:8:\"end_time\";i:127;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_DlZYf5H9VQ73gFpqzioJuahEOvrn8bsS-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:3;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:3;a:14:{s:2:\"id\";i:132;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:127;s:8:\"end_time\";i:139;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_bRVOBvsYpNmjdlL09Ef8MUFqxQona517-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:4;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:4;a:14:{s:2:\"id\";i:133;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:139;s:8:\"end_time\";i:151;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_ejAdyGfnaq6KgzZO7lEWcQ9t3BowHpUF-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:5;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:5;a:14:{s:2:\"id\";i:134;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:151;s:8:\"end_time\";i:161;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_NrLIRX1v8aGwbWCxmV9pHMJqY5FoShjB-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:6;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:6;a:14:{s:2:\"id\";i:135;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:161;s:8:\"end_time\";i:188;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_L5xEn2rAPjXTwDMmd7ivl4JHQC3U8sGW-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:7;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:7;a:14:{s:2:\"id\";i:136;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:188;s:8:\"end_time\";i:198;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_3qzxAKcYtjliJ7kUOQ6spLHC02VyfXW8-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:8;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:8;a:14:{s:2:\"id\";i:137;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:198;s:8:\"end_time\";i:216;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_kQsdfxX2PowV1HhlGcTu07pAENiIFj9a-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:9;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:9;a:14:{s:2:\"id\";i:138;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:216;s:8:\"end_time\";i:222;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_8KIYi3tcnb1AlGaSC5qy2HpzkRuUoFMN-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:10;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:10;a:14:{s:2:\"id\";i:139;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:222;s:8:\"end_time\";i:231;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_pTocV3qejaysbgKDAZYLBu51z6iPEWQI-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:11;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:11;a:14:{s:2:\"id\";i:140;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:231;s:8:\"end_time\";i:238;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_GT7AuvOFnzdIJ2DLx5QflCa168MgpNYR-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:12;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:12;a:14:{s:2:\"id\";i:141;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:238;s:8:\"end_time\";i:242;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_BFnyfGAKw0QodYpirs2Vzea6lEOvNcWX-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:13;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:13;a:14:{s:2:\"id\";i:142;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:242;s:8:\"end_time\";i:249;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_hYXgcu3ks1epiDHbaEFyKQG9ZltPJx7f-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:14;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:14;a:14:{s:2:\"id\";i:143;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:249;s:8:\"end_time\";i:261;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_hQw6RbzHa5CpgA8BsjDIiVoyuFxrvfYc-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:15;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:15;a:14:{s:2:\"id\";i:144;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:261;s:8:\"end_time\";i:279;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_E59iXT7pZauAYqKWBLgIbHmGMj6oJkwz-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:16;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:16;a:14:{s:2:\"id\";i:145;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:279;s:8:\"end_time\";i:302;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_tkRUrfZVE6Snd5yM2FeYBc1TipWuvsOh-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:17;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:17;a:14:{s:2:\"id\";i:146;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:302;s:8:\"end_time\";i:323;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_HJl3SiC1yRpnUe2qfrQgG0PMkFuBZ9c5-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:18;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:18;a:14:{s:2:\"id\";i:147;s:8:\"story_id\";i:7;s:10:\"episode_id\";i:3;s:10:\"start_time\";i:323;s:8:\"end_time\";i:429;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_9ijt3QmxPacpDUCf6X4ORndkY81eBq0r-2025-10-11_09-28-45.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:19;s:10:\"created_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}}}s:11:\"access_info\";a:3:{s:10:\"has_access\";b:1;s:6:\"reason\";s:12:\"free_content\";s:7:\"message\";s:28:\"قسمت رایگان است\";}s:18:\"is_story_favorited\";b:0;}}',1766051851),('laravel-cache-api_api/v1/episodes/4_user_16','a:2:{s:7:\"success\";b:1;s:4:\"data\";a:3:{s:7:\"episode\";a:51:{s:2:\"id\";i:4;s:8:\"story_id\";i:4;s:11:\"narrator_id\";i:5;s:5:\"title\";s:26:\"کل داستان گاوی\";s:11:\"description\";N;s:9:\"audio_url\";s:108:\"https://my.sarvcast.ir/storage/audio/episodes/audio_xA58lhWbTQ9H1iFIKaB6vkVqCRDoecjd-2025-10-06_16-54-25.mp3\";s:16:\"local_audio_path\";N;s:8:\"duration\";i:401;s:14:\"episode_number\";i:1;s:10:\"is_premium\";b:0;s:10:\"image_urls\";a:0:{}s:10:\"play_count\";i:47;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";N;s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";i:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:24:26.000000Z\";s:10:\"updated_at\";s:27:\"2025-12-18T09:58:57.000000Z\";s:25:\"has_multiple_voice_actors\";b:0;s:17:\"voice_actor_count\";i:0;s:18:\"use_image_timeline\";b:0;s:5:\"story\";a:52:{s:2:\"id\";i:4;s:5:\"title\";s:20:\"گاو و گنجشک\";s:8:\"subtitle\";s:51:\"داستان دوستی و شادی در مزرعه\";s:11:\"description\";s:429:\"گاوی گاو قهوه‌ای بزرگ که از آفتاب گرم ناراضی است، با چی‌چی گنجشک کوچولوی شاد آشنا می‌شود. چی‌چی به او می‌آموزد که شادی از گذراندن وقت با دوستان در مزرعه می‌آید. این داستان شیرین کودکان را با ارزش دوستی و لذت زندگی در طبیعت آشنا می‌کند.\";s:9:\"image_url\";s:59:\"https://my.sarvcast.ir/images/stories/1759756220_cover.webp\";s:15:\"cover_image_url\";s:65:\"https://my.sarvcast.ir/images/stories/1759756220_cover_cover.webp\";s:11:\"category_id\";i:5;s:11:\"director_id\";i:2;s:9:\"writer_id\";i:10;s:9:\"author_id\";i:10;s:11:\"narrator_id\";i:5;s:9:\"age_group\";s:3:\"3-5\";s:8:\"language\";s:7:\"persian\";s:8:\"duration\";i:401;s:14:\"total_episodes\";i:1;s:13:\"free_episodes\";i:1;s:10:\"is_premium\";b:0;s:18:\"is_completely_free\";b:1;s:10:\"play_count\";i:0;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";a:1:{i:0;s:10:\"دوستی\";}s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";b:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:10:20.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:18:\"use_image_timeline\";b:1;}s:8:\"narrator\";a:12:{s:2:\"id\";i:5;s:4:\"name\";s:24:\"نجمه گندم کار\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:2:{i:0;s:11:\"voice_actor\";i:1;s:8:\"narrator\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:01:28.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:04:38.000000Z\";}s:6:\"people\";a:0:{}s:15:\"image_timelines\";a:14:{i:0;a:14:{s:2:\"id\";i:148;s:8:\"story_id\";i:4;s:10:\"episode_id\";i:4;s:10:\"start_time\";i:4;s:8:\"end_time\";i:83;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_Hz8iYw7mder4LpoVy6REkNu1sBJWlUDt-2025-10-11_09-33-29.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:1;s:10:\"created_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:1;a:14:{s:2:\"id\";i:149;s:8:\"story_id\";i:4;s:10:\"episode_id\";i:4;s:10:\"start_time\";i:83;s:8:\"end_time\";i:119;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_yIG6xo4iAQVEf0UZznDR1FteYT7bcjJB-2025-10-11_09-33-29.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:2;s:10:\"created_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:2;a:14:{s:2:\"id\";i:150;s:8:\"story_id\";i:4;s:10:\"episode_id\";i:4;s:10:\"start_time\";i:119;s:8:\"end_time\";i:138;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_nuXYHtirgUz1oKEfqRTQWwBcG3JxeN5a-2025-10-11_09-33-29.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:3;s:10:\"created_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:3;a:14:{s:2:\"id\";i:151;s:8:\"story_id\";i:4;s:10:\"episode_id\";i:4;s:10:\"start_time\";i:138;s:8:\"end_time\";i:153;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_BP4jSn18eT0QRGmNrI7OLW5H23plu9wF-2025-10-11_09-33-29.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:4;s:10:\"created_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:4;a:14:{s:2:\"id\";i:152;s:8:\"story_id\";i:4;s:10:\"episode_id\";i:4;s:10:\"start_time\";i:153;s:8:\"end_time\";i:184;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_JoitIxDz29Lh3pTWGqZNygCdKPaSAlcj-2025-10-11_09-33-29.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:5;s:10:\"created_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:5;a:14:{s:2:\"id\";i:153;s:8:\"story_id\";i:4;s:10:\"episode_id\";i:4;s:10:\"start_time\";i:184;s:8:\"end_time\";i:214;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_Ew0bh3oIO9PWn7aMrDuZN1m4g6TfpHjC-2025-10-11_09-33-29.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:6;s:10:\"created_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:6;a:14:{s:2:\"id\";i:154;s:8:\"story_id\";i:4;s:10:\"episode_id\";i:4;s:10:\"start_time\";i:214;s:8:\"end_time\";i:236;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_YZnsBPtcxkEJiDTpQu8R7qA4C5Iv2jlf-2025-10-11_09-33-29.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:7;s:10:\"created_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:7;a:14:{s:2:\"id\";i:155;s:8:\"story_id\";i:4;s:10:\"episode_id\";i:4;s:10:\"start_time\";i:236;s:8:\"end_time\";i:271;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_yA5M3z8nKu9miT427tWE1klejZ6owFGx-2025-10-11_09-33-29.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:8;s:10:\"created_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:8;a:14:{s:2:\"id\";i:156;s:8:\"story_id\";i:4;s:10:\"episode_id\";i:4;s:10:\"start_time\";i:271;s:8:\"end_time\";i:289;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_B0GEJeWY6uLnVXizCRUcMolQZsg9fHbT-2025-10-11_09-33-29.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:9;s:10:\"created_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:9;a:14:{s:2:\"id\";i:157;s:8:\"story_id\";i:4;s:10:\"episode_id\";i:4;s:10:\"start_time\";i:289;s:8:\"end_time\";i:310;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_NnYtmkVAuW2v6JzMySZxFUiapT3hgdcs-2025-10-11_09-33-29.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:10;s:10:\"created_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:10;a:14:{s:2:\"id\";i:158;s:8:\"story_id\";i:4;s:10:\"episode_id\";i:4;s:10:\"start_time\";i:310;s:8:\"end_time\";i:327;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_kcrf4X1gQIxFNUYCZwJqWR7p02TdiKbj-2025-10-11_09-33-29.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:11;s:10:\"created_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:11;a:14:{s:2:\"id\";i:159;s:8:\"story_id\";i:4;s:10:\"episode_id\";i:4;s:10:\"start_time\";i:327;s:8:\"end_time\";i:338;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_aOsItHBWRckg6XzorZyG97v5bSdqCEeM-2025-10-11_09-33-29.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:12;s:10:\"created_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:12;a:14:{s:2:\"id\";i:160;s:8:\"story_id\";i:4;s:10:\"episode_id\";i:4;s:10:\"start_time\";i:338;s:8:\"end_time\";i:347;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_tFscgnwkUrXBxj4DNzC8ZiYvSEOyapoH-2025-10-11_09-33-29.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:13;s:10:\"created_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:13;a:14:{s:2:\"id\";i:161;s:8:\"story_id\";i:4;s:10:\"episode_id\";i:4;s:10:\"start_time\";i:347;s:8:\"end_time\";i:401;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_MXbqJ529faCp6IxPjW3tYRouNszT7dEv-2025-10-11_09-33-29.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:14;s:10:\"created_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}}}s:11:\"access_info\";a:3:{s:10:\"has_access\";b:1;s:6:\"reason\";s:12:\"free_content\";s:7:\"message\";s:28:\"قسمت رایگان است\";}s:18:\"is_story_favorited\";b:0;}}',1766052336),('laravel-cache-api_api/v1/episodes/4_user_7','a:2:{s:7:\"success\";b:1;s:4:\"data\";a:3:{s:7:\"episode\";a:51:{s:2:\"id\";i:4;s:8:\"story_id\";i:4;s:11:\"narrator_id\";i:5;s:5:\"title\";s:26:\"کل داستان گاوی\";s:11:\"description\";N;s:9:\"audio_url\";s:108:\"https://my.sarvcast.ir/storage/audio/episodes/audio_xA58lhWbTQ9H1iFIKaB6vkVqCRDoecjd-2025-10-06_16-54-25.mp3\";s:16:\"local_audio_path\";N;s:8:\"duration\";i:401;s:14:\"episode_number\";i:1;s:10:\"is_premium\";b:0;s:10:\"image_urls\";a:0:{}s:10:\"play_count\";i:44;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";N;s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";i:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:24:26.000000Z\";s:10:\"updated_at\";s:27:\"2025-12-17T22:38:06.000000Z\";s:25:\"has_multiple_voice_actors\";b:0;s:17:\"voice_actor_count\";i:0;s:18:\"use_image_timeline\";b:0;s:5:\"story\";a:52:{s:2:\"id\";i:4;s:5:\"title\";s:20:\"گاو و گنجشک\";s:8:\"subtitle\";s:51:\"داستان دوستی و شادی در مزرعه\";s:11:\"description\";s:429:\"گاوی گاو قهوه‌ای بزرگ که از آفتاب گرم ناراضی است، با چی‌چی گنجشک کوچولوی شاد آشنا می‌شود. چی‌چی به او می‌آموزد که شادی از گذراندن وقت با دوستان در مزرعه می‌آید. این داستان شیرین کودکان را با ارزش دوستی و لذت زندگی در طبیعت آشنا می‌کند.\";s:9:\"image_url\";s:59:\"https://my.sarvcast.ir/images/stories/1759756220_cover.webp\";s:15:\"cover_image_url\";s:65:\"https://my.sarvcast.ir/images/stories/1759756220_cover_cover.webp\";s:11:\"category_id\";i:5;s:11:\"director_id\";i:2;s:9:\"writer_id\";i:10;s:9:\"author_id\";i:10;s:11:\"narrator_id\";i:5;s:9:\"age_group\";s:3:\"3-5\";s:8:\"language\";s:7:\"persian\";s:8:\"duration\";i:401;s:14:\"total_episodes\";i:1;s:13:\"free_episodes\";i:1;s:10:\"is_premium\";b:0;s:18:\"is_completely_free\";b:1;s:10:\"play_count\";i:0;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";a:1:{i:0;s:10:\"دوستی\";}s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";b:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:10:20.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:18:\"use_image_timeline\";b:1;}s:8:\"narrator\";a:12:{s:2:\"id\";i:5;s:4:\"name\";s:24:\"نجمه گندم کار\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:2:{i:0;s:11:\"voice_actor\";i:1;s:8:\"narrator\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:01:28.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:04:38.000000Z\";}s:6:\"people\";a:0:{}s:15:\"image_timelines\";a:14:{i:0;a:14:{s:2:\"id\";i:148;s:8:\"story_id\";i:4;s:10:\"episode_id\";i:4;s:10:\"start_time\";i:4;s:8:\"end_time\";i:83;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_Hz8iYw7mder4LpoVy6REkNu1sBJWlUDt-2025-10-11_09-33-29.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:1;s:10:\"created_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:1;a:14:{s:2:\"id\";i:149;s:8:\"story_id\";i:4;s:10:\"episode_id\";i:4;s:10:\"start_time\";i:83;s:8:\"end_time\";i:119;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_yIG6xo4iAQVEf0UZznDR1FteYT7bcjJB-2025-10-11_09-33-29.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:2;s:10:\"created_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:2;a:14:{s:2:\"id\";i:150;s:8:\"story_id\";i:4;s:10:\"episode_id\";i:4;s:10:\"start_time\";i:119;s:8:\"end_time\";i:138;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_nuXYHtirgUz1oKEfqRTQWwBcG3JxeN5a-2025-10-11_09-33-29.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:3;s:10:\"created_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:3;a:14:{s:2:\"id\";i:151;s:8:\"story_id\";i:4;s:10:\"episode_id\";i:4;s:10:\"start_time\";i:138;s:8:\"end_time\";i:153;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_BP4jSn18eT0QRGmNrI7OLW5H23plu9wF-2025-10-11_09-33-29.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:4;s:10:\"created_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:4;a:14:{s:2:\"id\";i:152;s:8:\"story_id\";i:4;s:10:\"episode_id\";i:4;s:10:\"start_time\";i:153;s:8:\"end_time\";i:184;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_JoitIxDz29Lh3pTWGqZNygCdKPaSAlcj-2025-10-11_09-33-29.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:5;s:10:\"created_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:5;a:14:{s:2:\"id\";i:153;s:8:\"story_id\";i:4;s:10:\"episode_id\";i:4;s:10:\"start_time\";i:184;s:8:\"end_time\";i:214;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_Ew0bh3oIO9PWn7aMrDuZN1m4g6TfpHjC-2025-10-11_09-33-29.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:6;s:10:\"created_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:6;a:14:{s:2:\"id\";i:154;s:8:\"story_id\";i:4;s:10:\"episode_id\";i:4;s:10:\"start_time\";i:214;s:8:\"end_time\";i:236;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_YZnsBPtcxkEJiDTpQu8R7qA4C5Iv2jlf-2025-10-11_09-33-29.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:7;s:10:\"created_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:7;a:14:{s:2:\"id\";i:155;s:8:\"story_id\";i:4;s:10:\"episode_id\";i:4;s:10:\"start_time\";i:236;s:8:\"end_time\";i:271;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_yA5M3z8nKu9miT427tWE1klejZ6owFGx-2025-10-11_09-33-29.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:8;s:10:\"created_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:8;a:14:{s:2:\"id\";i:156;s:8:\"story_id\";i:4;s:10:\"episode_id\";i:4;s:10:\"start_time\";i:271;s:8:\"end_time\";i:289;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_B0GEJeWY6uLnVXizCRUcMolQZsg9fHbT-2025-10-11_09-33-29.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:9;s:10:\"created_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:9;a:14:{s:2:\"id\";i:157;s:8:\"story_id\";i:4;s:10:\"episode_id\";i:4;s:10:\"start_time\";i:289;s:8:\"end_time\";i:310;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_NnYtmkVAuW2v6JzMySZxFUiapT3hgdcs-2025-10-11_09-33-29.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:10;s:10:\"created_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:10;a:14:{s:2:\"id\";i:158;s:8:\"story_id\";i:4;s:10:\"episode_id\";i:4;s:10:\"start_time\";i:310;s:8:\"end_time\";i:327;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_kcrf4X1gQIxFNUYCZwJqWR7p02TdiKbj-2025-10-11_09-33-29.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:11;s:10:\"created_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:11;a:14:{s:2:\"id\";i:159;s:8:\"story_id\";i:4;s:10:\"episode_id\";i:4;s:10:\"start_time\";i:327;s:8:\"end_time\";i:338;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_aOsItHBWRckg6XzorZyG97v5bSdqCEeM-2025-10-11_09-33-29.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:12;s:10:\"created_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:12;a:14:{s:2:\"id\";i:160;s:8:\"story_id\";i:4;s:10:\"episode_id\";i:4;s:10:\"start_time\";i:338;s:8:\"end_time\";i:347;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_tFscgnwkUrXBxj4DNzC8ZiYvSEOyapoH-2025-10-11_09-33-29.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:13;s:10:\"created_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:13;a:14:{s:2:\"id\";i:161;s:8:\"story_id\";i:4;s:10:\"episode_id\";i:4;s:10:\"start_time\";i:347;s:8:\"end_time\";i:401;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_MXbqJ529faCp6IxPjW3tYRouNszT7dEv-2025-10-11_09-33-29.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:14;s:10:\"created_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}}}s:11:\"access_info\";a:3:{s:10:\"has_access\";b:1;s:6:\"reason\";s:12:\"free_content\";s:7:\"message\";s:28:\"قسمت رایگان است\";}s:18:\"is_story_favorited\";b:0;}}',1766051858),('laravel-cache-api_api/v1/episodes/5_user_7','a:2:{s:7:\"success\";b:1;s:4:\"data\";a:3:{s:7:\"episode\";a:51:{s:2:\"id\";i:5;s:8:\"story_id\";i:6;s:11:\"narrator_id\";i:3;s:5:\"title\";s:37:\"کل داستان مورچه شجاع\";s:11:\"description\";N;s:9:\"audio_url\";s:108:\"https://my.sarvcast.ir/storage/audio/episodes/audio_jIAFUnwL72WgsqitZ1Bm4uXGYOvKx3QJ-2025-10-06_17-00-38.mp3\";s:16:\"local_audio_path\";N;s:8:\"duration\";i:505;s:14:\"episode_number\";i:1;s:10:\"is_premium\";b:0;s:10:\"image_urls\";a:0:{}s:10:\"play_count\";i:19;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";N;s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";i:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:30:39.000000Z\";s:10:\"updated_at\";s:27:\"2025-12-18T06:46:24.000000Z\";s:25:\"has_multiple_voice_actors\";b:0;s:17:\"voice_actor_count\";i:0;s:18:\"use_image_timeline\";b:0;s:5:\"story\";a:52:{s:2:\"id\";i:6;s:5:\"title\";s:28:\"مورچه‌های شجاع\";s:8:\"subtitle\";s:40:\"قدرت کار تیمی و همکاری\";s:11:\"description\";s:392:\"گروهی از مورچه‌های شجاع و سختکوش دانه گندم طلایی بزرگی را کشف می‌کنند و باید با همکاری یکدیگر موانع را پشت سر بگذارند تا آن را به لانه‌شان ببرند. این داستان الهام‌بخش کودکان را با ارزش کار تیمی و همکاری آشنا می‌کند.\";s:9:\"image_url\";s:59:\"https://my.sarvcast.ir/images/stories/1759756441_cover.webp\";s:15:\"cover_image_url\";s:65:\"https://my.sarvcast.ir/images/stories/1759756441_cover_cover.webp\";s:11:\"category_id\";i:5;s:11:\"director_id\";i:2;s:9:\"writer_id\";i:10;s:9:\"author_id\";i:10;s:11:\"narrator_id\";i:3;s:9:\"age_group\";s:3:\"3-5\";s:8:\"language\";s:7:\"persian\";s:8:\"duration\";i:505;s:14:\"total_episodes\";i:1;s:13:\"free_episodes\";i:1;s:10:\"is_premium\";b:0;s:18:\"is_completely_free\";b:1;s:10:\"play_count\";i:0;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";a:1:{i:0;s:10:\"دوستی\";}s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";b:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:14:01.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:18:\"use_image_timeline\";b:1;}s:8:\"narrator\";a:12:{s:2:\"id\";i:3;s:4:\"name\";s:26:\"نجمه موسوی فرد\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:6:{i:0;s:11:\"voice_actor\";i:1;s:8:\"director\";i:2;s:6:\"writer\";i:3;s:8:\"producer\";i:4;s:6:\"author\";i:5;s:8:\"narrator\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:00:30.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:00:30.000000Z\";}s:6:\"people\";a:0:{}s:15:\"image_timelines\";a:17:{i:0;a:14:{s:2:\"id\";i:162;s:8:\"story_id\";i:6;s:10:\"episode_id\";i:5;s:10:\"start_time\";i:0;s:8:\"end_time\";i:99;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_8WQOj6fPq52tKzwI74evhlbsLVYZ1BcD-2025-10-11_09-43-21.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:1;s:10:\"created_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:1;a:14:{s:2:\"id\";i:163;s:8:\"story_id\";i:6;s:10:\"episode_id\";i:5;s:10:\"start_time\";i:99;s:8:\"end_time\";i:137;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_21mus8TVbrwdhxLRBijC6qvGntaUDk5P-2025-10-11_09-43-21.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:2;s:10:\"created_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:2;a:14:{s:2:\"id\";i:164;s:8:\"story_id\";i:6;s:10:\"episode_id\";i:5;s:10:\"start_time\";i:137;s:8:\"end_time\";i:151;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_mni5g6OQXtbIEf834x1LTA2qBwo9JWu7-2025-10-11_09-43-21.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:3;s:10:\"created_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:3;a:14:{s:2:\"id\";i:165;s:8:\"story_id\";i:6;s:10:\"episode_id\";i:5;s:10:\"start_time\";i:151;s:8:\"end_time\";i:170;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_bcxM7Sen6oCNUR1fKOJrysVGjBZg3Fmw-2025-10-11_09-43-21.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:4;s:10:\"created_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:4;a:14:{s:2:\"id\";i:166;s:8:\"story_id\";i:6;s:10:\"episode_id\";i:5;s:10:\"start_time\";i:170;s:8:\"end_time\";i:187;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_hkUfo3tNV6ip10ExHCYFLr9eb7qMZsJa-2025-10-11_09-43-21.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:5;s:10:\"created_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:5;a:14:{s:2:\"id\";i:167;s:8:\"story_id\";i:6;s:10:\"episode_id\";i:5;s:10:\"start_time\";i:187;s:8:\"end_time\";i:233;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_GLzYH8u1mWkyNSi2stReFKTC6bEwAdBJ-2025-10-11_09-43-21.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:6;s:10:\"created_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:6;a:14:{s:2:\"id\";i:168;s:8:\"story_id\";i:6;s:10:\"episode_id\";i:5;s:10:\"start_time\";i:233;s:8:\"end_time\";i:248;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_BIzhXH0KM6cGrLA74Vsjb9kPv3Roula1-2025-10-11_09-43-21.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:7;s:10:\"created_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:7;a:14:{s:2:\"id\";i:169;s:8:\"story_id\";i:6;s:10:\"episode_id\";i:5;s:10:\"start_time\";i:248;s:8:\"end_time\";i:265;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_veaV0fzdBXkqDPZohiON8TbHtIU7A2CF-2025-10-11_09-43-21.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:8;s:10:\"created_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:8;a:14:{s:2:\"id\";i:170;s:8:\"story_id\";i:6;s:10:\"episode_id\";i:5;s:10:\"start_time\";i:265;s:8:\"end_time\";i:283;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_lUdcTAeXWxosKy7SpHvJmFirGE5Pj39N-2025-10-11_09-43-21.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:9;s:10:\"created_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:9;a:14:{s:2:\"id\";i:171;s:8:\"story_id\";i:6;s:10:\"episode_id\";i:5;s:10:\"start_time\";i:283;s:8:\"end_time\";i:311;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_JK9bjGMS81hdmNrxs3uXoe7REqvfkZLi-2025-10-11_09-43-21.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:10;s:10:\"created_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:10;a:14:{s:2:\"id\";i:172;s:8:\"story_id\";i:6;s:10:\"episode_id\";i:5;s:10:\"start_time\";i:311;s:8:\"end_time\";i:328;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_V5fv7drPYzkJx2Cp6FctnhwjelX8Dsmq-2025-10-11_09-43-21.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:11;s:10:\"created_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:11;a:14:{s:2:\"id\";i:173;s:8:\"story_id\";i:6;s:10:\"episode_id\";i:5;s:10:\"start_time\";i:328;s:8:\"end_time\";i:341;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_1UncYqTuOpkQob0Xga5Vwl4RfySAvLHd-2025-10-11_09-43-21.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:12;s:10:\"created_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:12;a:14:{s:2:\"id\";i:174;s:8:\"story_id\";i:6;s:10:\"episode_id\";i:5;s:10:\"start_time\";i:341;s:8:\"end_time\";i:360;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_TZvpGcS0WY84UIOForxiJ9yRjC7LbEwK-2025-10-11_09-43-21.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:13;s:10:\"created_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:13;a:14:{s:2:\"id\";i:175;s:8:\"story_id\";i:6;s:10:\"episode_id\";i:5;s:10:\"start_time\";i:360;s:8:\"end_time\";i:371;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_EerGtl3z1QLMCaJvsxof8jPO4p27qUig-2025-10-11_09-43-21.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:14;s:10:\"created_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:14;a:14:{s:2:\"id\";i:176;s:8:\"story_id\";i:6;s:10:\"episode_id\";i:5;s:10:\"start_time\";i:371;s:8:\"end_time\";i:386;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_Mn7Rz6wGACTtaWN1cepUiZqPrgmHvJ0X-2025-10-11_09-43-21.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:15;s:10:\"created_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:15;a:14:{s:2:\"id\";i:177;s:8:\"story_id\";i:6;s:10:\"episode_id\";i:5;s:10:\"start_time\";i:386;s:8:\"end_time\";i:410;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_g15hfVLDnpBeG0XsWiQj6b89dFazZ7tq-2025-10-11_09-43-21.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:16;s:10:\"created_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:16;a:14:{s:2:\"id\";i:178;s:8:\"story_id\";i:6;s:10:\"episode_id\";i:5;s:10:\"start_time\";i:410;s:8:\"end_time\";i:505;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_cb71fSx2aGDrunsk3gQCAyw4EdRWe0zv-2025-10-11_09-43-21.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:17;s:10:\"created_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}}}s:11:\"access_info\";a:3:{s:10:\"has_access\";b:1;s:6:\"reason\";s:12:\"free_content\";s:7:\"message\";s:28:\"قسمت رایگان است\";}s:18:\"is_story_favorited\";b:1;}}',1766051896),('laravel-cache-api_api/v1/episodes/6_user_16','a:2:{s:7:\"success\";b:1;s:4:\"data\";a:3:{s:7:\"episode\";a:51:{s:2:\"id\";i:6;s:8:\"story_id\";i:5;s:11:\"narrator_id\";i:4;s:5:\"title\";s:41:\"کل داستان هیولای غمگین\";s:11:\"description\";N;s:9:\"audio_url\";s:108:\"https://my.sarvcast.ir/storage/audio/episodes/audio_16hN2mZX3G5JjoF7wDisHY8bPWnLxSAV-2025-10-06_17-02-09.mp3\";s:16:\"local_audio_path\";N;s:8:\"duration\";i:502;s:14:\"episode_number\";i:1;s:10:\"is_premium\";b:1;s:10:\"image_urls\";a:0:{}s:10:\"play_count\";i:27;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";N;s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";i:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:32:10.000000Z\";s:10:\"updated_at\";s:27:\"2025-12-18T09:55:08.000000Z\";s:25:\"has_multiple_voice_actors\";b:0;s:17:\"voice_actor_count\";i:0;s:18:\"use_image_timeline\";b:0;s:5:\"story\";a:52:{s:2:\"id\";i:5;s:5:\"title\";s:23:\"هیولای غمگین\";s:8:\"subtitle\";s:56:\"سفری برای درک احساسات و رنگ‌ها\";s:11:\"description\";s:406:\"رنگی هیولای کوچولوی پشمالویی که احساساتش را به صورت رنگ‌های مختلف تجربه می‌کند. او با کمک دوستان جنگلی‌اش می‌آموزد که همه احساسات طبیعی و زیبا هستند. این داستان آموزشی کودکان را با هوش هیجانی و مدیریت احساسات آشنا می‌کند.\";s:9:\"image_url\";s:59:\"https://my.sarvcast.ir/images/stories/1759756340_cover.webp\";s:15:\"cover_image_url\";s:65:\"https://my.sarvcast.ir/images/stories/1759756340_cover_cover.webp\";s:11:\"category_id\";i:4;s:11:\"director_id\";i:2;s:9:\"writer_id\";i:3;s:9:\"author_id\";i:3;s:11:\"narrator_id\";i:4;s:9:\"age_group\";s:3:\"3-5\";s:8:\"language\";s:7:\"persian\";s:8:\"duration\";i:502;s:14:\"total_episodes\";i:1;s:13:\"free_episodes\";i:0;s:10:\"is_premium\";b:0;s:18:\"is_completely_free\";b:1;s:10:\"play_count\";i:0;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";a:1:{i:0;s:18:\"ماجراجویی\";}s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";b:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:12:20.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:18:\"use_image_timeline\";b:1;}s:8:\"narrator\";a:12:{s:2:\"id\";i:4;s:4:\"name\";s:30:\"سوگند محمود شاهی\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:6:{i:0;s:11:\"voice_actor\";i:1;s:8:\"director\";i:2;s:6:\"writer\";i:3;s:8:\"producer\";i:4;s:6:\"author\";i:5;s:8:\"narrator\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:00:41.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:04:32.000000Z\";}s:6:\"people\";a:0:{}s:15:\"image_timelines\";a:17:{i:0;a:14:{s:2:\"id\";i:179;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:0;s:8:\"end_time\";i:108;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_9OSHJ0nm1XbC2RhoVu5KWa8UeAqMwTtk-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:1;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:1;a:14:{s:2:\"id\";i:180;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:108;s:8:\"end_time\";i:118;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_3zVsy2nQwZr9mgbuEaxqF1oXCAkDhI4R-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:2;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:2;a:14:{s:2:\"id\";i:181;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:118;s:8:\"end_time\";i:138;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_cQqLrbUvJBIHOluE12zDxGdiPfmoZK8s-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:3;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:3;a:14:{s:2:\"id\";i:182;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:138;s:8:\"end_time\";i:155;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_grwDltiM8b4vHWXYoj25musJ3LS916CK-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:4;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:4;a:14:{s:2:\"id\";i:183;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:155;s:8:\"end_time\";i:181;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_c4fuD5OBsCPpt3ikWjl1TMvZYrhyUHx9-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:5;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:5;a:14:{s:2:\"id\";i:184;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:181;s:8:\"end_time\";i:195;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_OQu8lP2BU63MyJ1TNpZ9civKHsREbCFA-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:6;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:6;a:14:{s:2:\"id\";i:185;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:195;s:8:\"end_time\";i:237;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_OIR5EmzVsxiL3reDAwgjolt69Q1vh42B-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:7;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:7;a:14:{s:2:\"id\";i:186;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:237;s:8:\"end_time\";i:246;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_5HgZvy3VmpYQXKeRFi7t1EshlnGDMBOa-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:8;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:8;a:14:{s:2:\"id\";i:187;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:246;s:8:\"end_time\";i:268;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_FG0wA2ecnIjQEsBdPCqht8uYylaZKzR5-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:9;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:9;a:14:{s:2:\"id\";i:188;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:268;s:8:\"end_time\";i:311;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_0SAP3yEWHw52tDgpbZB6Oos9RrGKnhYv-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:10;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:10;a:14:{s:2:\"id\";i:189;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:311;s:8:\"end_time\";i:329;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_9ZQarAsFEDUpefxWG1qS3BgnVJvTjLM2-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:11;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:11;a:14:{s:2:\"id\";i:190;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:329;s:8:\"end_time\";i:357;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_uji9N1bxS8nH20Vtkc4rIdfo3BTesvDC-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:12;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:12;a:14:{s:2:\"id\";i:191;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:357;s:8:\"end_time\";i:378;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_ET4Ac0wpKlIVNP2rtzD7kqgJGexCYO36-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:13;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:13;a:14:{s:2:\"id\";i:192;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:378;s:8:\"end_time\";i:395;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_6Tg8wsLN3bPqEUCBOiW1VArDdFKH4Mjn-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:14;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:14;a:14:{s:2:\"id\";i:193;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:395;s:8:\"end_time\";i:416;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_zJROAusBvpfU4Wqe1NPS2Hdw9yMnlIx6-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:15;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:15;a:14:{s:2:\"id\";i:194;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:416;s:8:\"end_time\";i:433;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_UDy4PXwnj2KIbpZmd7h9Osf5RuiTBQYq-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:16;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:16;a:14:{s:2:\"id\";i:195;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:433;s:8:\"end_time\";i:502;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_Jb6LaEci5Wgp0HOfzoSFIhMUk782ARjv-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:17;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}}}s:11:\"access_info\";a:3:{s:10:\"has_access\";b:1;s:6:\"reason\";s:20:\"premium_subscription\";s:7:\"message\";s:39:\"دسترسی با اشتراک فعال\";}s:18:\"is_story_favorited\";b:1;}}',1766052325),('laravel-cache-api_api/v1/episodes/6_user_17','a:2:{s:7:\"success\";b:1;s:4:\"data\";a:3:{s:7:\"episode\";a:51:{s:2:\"id\";i:6;s:8:\"story_id\";i:5;s:11:\"narrator_id\";i:4;s:5:\"title\";s:41:\"کل داستان هیولای غمگین\";s:11:\"description\";N;s:9:\"audio_url\";s:108:\"https://my.sarvcast.ir/storage/audio/episodes/audio_16hN2mZX3G5JjoF7wDisHY8bPWnLxSAV-2025-10-06_17-02-09.mp3\";s:16:\"local_audio_path\";N;s:8:\"duration\";i:502;s:14:\"episode_number\";i:1;s:10:\"is_premium\";b:1;s:10:\"image_urls\";a:0:{}s:10:\"play_count\";i:25;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";N;s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";i:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:32:10.000000Z\";s:10:\"updated_at\";s:27:\"2025-12-18T06:47:09.000000Z\";s:25:\"has_multiple_voice_actors\";b:0;s:17:\"voice_actor_count\";i:0;s:18:\"use_image_timeline\";b:0;s:5:\"story\";a:52:{s:2:\"id\";i:5;s:5:\"title\";s:23:\"هیولای غمگین\";s:8:\"subtitle\";s:56:\"سفری برای درک احساسات و رنگ‌ها\";s:11:\"description\";s:406:\"رنگی هیولای کوچولوی پشمالویی که احساساتش را به صورت رنگ‌های مختلف تجربه می‌کند. او با کمک دوستان جنگلی‌اش می‌آموزد که همه احساسات طبیعی و زیبا هستند. این داستان آموزشی کودکان را با هوش هیجانی و مدیریت احساسات آشنا می‌کند.\";s:9:\"image_url\";s:59:\"https://my.sarvcast.ir/images/stories/1759756340_cover.webp\";s:15:\"cover_image_url\";s:65:\"https://my.sarvcast.ir/images/stories/1759756340_cover_cover.webp\";s:11:\"category_id\";i:4;s:11:\"director_id\";i:2;s:9:\"writer_id\";i:3;s:9:\"author_id\";i:3;s:11:\"narrator_id\";i:4;s:9:\"age_group\";s:3:\"3-5\";s:8:\"language\";s:7:\"persian\";s:8:\"duration\";i:502;s:14:\"total_episodes\";i:1;s:13:\"free_episodes\";i:0;s:10:\"is_premium\";b:0;s:18:\"is_completely_free\";b:1;s:10:\"play_count\";i:0;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";a:1:{i:0;s:18:\"ماجراجویی\";}s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";b:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:12:20.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:18:\"use_image_timeline\";b:1;}s:8:\"narrator\";a:12:{s:2:\"id\";i:4;s:4:\"name\";s:30:\"سوگند محمود شاهی\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:6:{i:0;s:11:\"voice_actor\";i:1;s:8:\"director\";i:2;s:6:\"writer\";i:3;s:8:\"producer\";i:4;s:6:\"author\";i:5;s:8:\"narrator\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:00:41.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:04:32.000000Z\";}s:6:\"people\";a:0:{}s:15:\"image_timelines\";a:17:{i:0;a:14:{s:2:\"id\";i:179;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:0;s:8:\"end_time\";i:108;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_9OSHJ0nm1XbC2RhoVu5KWa8UeAqMwTtk-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:1;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:1;a:14:{s:2:\"id\";i:180;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:108;s:8:\"end_time\";i:118;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_3zVsy2nQwZr9mgbuEaxqF1oXCAkDhI4R-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:2;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:2;a:14:{s:2:\"id\";i:181;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:118;s:8:\"end_time\";i:138;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_cQqLrbUvJBIHOluE12zDxGdiPfmoZK8s-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:3;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:3;a:14:{s:2:\"id\";i:182;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:138;s:8:\"end_time\";i:155;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_grwDltiM8b4vHWXYoj25musJ3LS916CK-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:4;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:4;a:14:{s:2:\"id\";i:183;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:155;s:8:\"end_time\";i:181;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_c4fuD5OBsCPpt3ikWjl1TMvZYrhyUHx9-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:5;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:5;a:14:{s:2:\"id\";i:184;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:181;s:8:\"end_time\";i:195;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_OQu8lP2BU63MyJ1TNpZ9civKHsREbCFA-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:6;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:6;a:14:{s:2:\"id\";i:185;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:195;s:8:\"end_time\";i:237;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_OIR5EmzVsxiL3reDAwgjolt69Q1vh42B-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:7;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:7;a:14:{s:2:\"id\";i:186;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:237;s:8:\"end_time\";i:246;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_5HgZvy3VmpYQXKeRFi7t1EshlnGDMBOa-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:8;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:8;a:14:{s:2:\"id\";i:187;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:246;s:8:\"end_time\";i:268;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_FG0wA2ecnIjQEsBdPCqht8uYylaZKzR5-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:9;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:9;a:14:{s:2:\"id\";i:188;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:268;s:8:\"end_time\";i:311;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_0SAP3yEWHw52tDgpbZB6Oos9RrGKnhYv-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:10;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:10;a:14:{s:2:\"id\";i:189;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:311;s:8:\"end_time\";i:329;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_9ZQarAsFEDUpefxWG1qS3BgnVJvTjLM2-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:11;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:11;a:14:{s:2:\"id\";i:190;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:329;s:8:\"end_time\";i:357;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_uji9N1bxS8nH20Vtkc4rIdfo3BTesvDC-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:12;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:12;a:14:{s:2:\"id\";i:191;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:357;s:8:\"end_time\";i:378;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_ET4Ac0wpKlIVNP2rtzD7kqgJGexCYO36-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:13;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:13;a:14:{s:2:\"id\";i:192;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:378;s:8:\"end_time\";i:395;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_6Tg8wsLN3bPqEUCBOiW1VArDdFKH4Mjn-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:14;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:14;a:14:{s:2:\"id\";i:193;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:395;s:8:\"end_time\";i:416;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_zJROAusBvpfU4Wqe1NPS2Hdw9yMnlIx6-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:15;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:15;a:14:{s:2:\"id\";i:194;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:416;s:8:\"end_time\";i:433;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_UDy4PXwnj2KIbpZmd7h9Osf5RuiTBQYq-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:16;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}i:16;a:14:{s:2:\"id\";i:195;s:8:\"story_id\";i:5;s:10:\"episode_id\";i:6;s:10:\"start_time\";i:433;s:8:\"end_time\";i:502;s:9:\"image_url\";s:91:\"images/episodes/timeline/timeline_Jb6LaEci5Wgp0HOfzoSFIhMUk782ARjv-2025-10-12_10-07-11.webp\";s:17:\"scene_description\";s:0:\"\";s:15:\"transition_type\";s:4:\"fade\";s:12:\"is_key_frame\";b:0;s:11:\"image_order\";i:17;s:10:\"created_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:14:\"voice_actor_id\";N;s:11:\"voice_actor\";N;}}}s:11:\"access_info\";a:3:{s:10:\"has_access\";b:1;s:6:\"reason\";s:20:\"premium_subscription\";s:7:\"message\";s:39:\"دسترسی با اشتراک فعال\";}s:18:\"is_story_favorited\";b:0;}}',1766051879),('laravel-cache-api_api/v1/stories','a:2:{s:7:\"success\";b:1;s:4:\"data\";a:8:{i:0;a:55:{s:2:\"id\";i:12;s:5:\"title\";s:31:\"آزمایشگاه جادویی\";s:8:\"subtitle\";s:44:\"ماجرای کشف جاذبه با آرین\";s:11:\"description\";s:786:\"آرین، پسر کوچکی که عاشق یادگیری است، یک اتاق مخفی در خانه پیدا می‌کند که در آن آزمایشگاهی جادویی با وسایل زنده وجود دارد: یک لوله شیشه‌ای، یک توپ قرمز و یک پر سبک. آن‌ها با هم درباره جاذبه صحبت می‌کنند و با انداختن توپ و پر در هوا و در داخل لوله، به آرین نشان می‌دهند که چگونه جاذبه همه چیز را به سمت زمین می‌کشد و باد چطور روی اجسام سبک‌تر اثر می‌گذارد. آرین با دیدن این \"جادوی واقعی\" عاشق علم می‌شود و تصمیم می‌گیرد هر روز آزمایش کند.\";s:9:\"image_url\";s:58:\"https://my.sarvcast.ir/images/stories/1766051577_cover.jpg\";s:15:\"cover_image_url\";s:64:\"https://my.sarvcast.ir/images/stories/1766051577_cover_cover.jpg\";s:11:\"category_id\";i:3;s:11:\"director_id\";i:2;s:9:\"writer_id\";i:3;s:9:\"author_id\";N;s:11:\"narrator_id\";i:5;s:9:\"age_group\";s:3:\"6-8\";s:8:\"language\";s:7:\"persian\";s:8:\"duration\";i:12;s:14:\"total_episodes\";i:1;s:13:\"free_episodes\";i:0;s:10:\"is_premium\";b:0;s:18:\"is_completely_free\";b:1;s:10:\"play_count\";i:0;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";a:1:{i:0;s:18:\"ماجراجویی\";}s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";b:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-12-18T09:52:57.000000Z\";s:10:\"updated_at\";s:27:\"2025-12-18T09:52:57.000000Z\";s:18:\"use_image_timeline\";b:0;s:8:\"category\";a:14:{s:2:\"id\";i:3;s:4:\"name\";s:12:\"آموزشی\";s:4:\"slug\";s:19:\"educational-stories\";s:11:\"description\";s:97:\"داستان‌هایی که مفاهیم آموزشی را به کودکان می‌آموزند\";s:9:\"icon_path\";s:109:\"categories/1759755521_20251006_1624_Magical Classroom Learning_simple_compose_01k6wsa61tf2p9m2wvht6sye7n.webp\";s:5:\"color\";s:7:\"#10b981\";s:11:\"story_count\";i:2;s:14:\"total_episodes\";i:2;s:14:\"total_duration\";i:24;s:14:\"average_rating\";s:4:\"0.00\";s:9:\"is_active\";b:1;s:10:\"sort_order\";i:3;s:10:\"created_at\";s:27:\"2025-10-05T16:27:24.000000Z\";s:10:\"updated_at\";s:27:\"2025-12-18T09:52:57.000000Z\";}s:8:\"director\";a:12:{s:2:\"id\";i:2;s:4:\"name\";s:34:\"امیر مسعود عابدینی\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:4:{i:0;s:11:\"voice_actor\";i:1;s:8:\"director\";i:2;s:8:\"producer\";i:3;s:8:\"narrator\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:00:01.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:00:14.000000Z\";}s:8:\"narrator\";a:12:{s:2:\"id\";i:5;s:4:\"name\";s:24:\"نجمه گندم کار\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:2:{i:0;s:11:\"voice_actor\";i:1;s:8:\"narrator\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:01:28.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:04:38.000000Z\";}}i:1;a:55:{s:2:\"id\";i:11;s:5:\"title\";s:46:\"دوستان از سرزمین‌های دور\";s:8:\"subtitle\";s:53:\"داستان دوستی پان‌پان و کانگی\";s:11:\"description\";s:793:\"در یک جنگل جادویی، یک پاندای آرام و مهربان به نام پان‌پان از چین و یک کانگوروی پرانرژی به نام کانگی از استرالیا با هم آشنا می‌شوند. آن‌ها اول به خاطر تفاوت در سبک بازی و فرهنگ کمی دچار سوءتفاهم می‌شوند، اما بعد یاد می‌گیرند که می‌توانند از هم چیزهای جدید یاد بگیرند و تفاوت‌ها دوستی‌شان را قوی‌تر می‌کند. در پایان روز، آن‌ها با به اشتراک گذاشتن غذا، بازی‌ها و داستان‌های سرزمین‌هایشان، بهترین دوست‌های از سرزمین‌های دور می‌شوند.\";s:9:\"image_url\";s:58:\"https://my.sarvcast.ir/images/stories/1766051249_cover.jpg\";s:15:\"cover_image_url\";s:64:\"https://my.sarvcast.ir/images/stories/1766051249_cover_cover.jpg\";s:11:\"category_id\";i:3;s:11:\"director_id\";i:2;s:9:\"writer_id\";i:10;s:9:\"author_id\";N;s:11:\"narrator_id\";i:8;s:9:\"age_group\";s:3:\"3-5\";s:8:\"language\";s:7:\"persian\";s:8:\"duration\";i:12;s:14:\"total_episodes\";i:1;s:13:\"free_episodes\";i:0;s:10:\"is_premium\";b:0;s:18:\"is_completely_free\";b:1;s:10:\"play_count\";i:0;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";a:1:{i:0;s:18:\"ماجراجویی\";}s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";b:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-12-18T09:47:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-12-18T09:47:29.000000Z\";s:18:\"use_image_timeline\";b:0;s:8:\"category\";a:14:{s:2:\"id\";i:3;s:4:\"name\";s:12:\"آموزشی\";s:4:\"slug\";s:19:\"educational-stories\";s:11:\"description\";s:97:\"داستان‌هایی که مفاهیم آموزشی را به کودکان می‌آموزند\";s:9:\"icon_path\";s:109:\"categories/1759755521_20251006_1624_Magical Classroom Learning_simple_compose_01k6wsa61tf2p9m2wvht6sye7n.webp\";s:5:\"color\";s:7:\"#10b981\";s:11:\"story_count\";i:2;s:14:\"total_episodes\";i:2;s:14:\"total_duration\";i:24;s:14:\"average_rating\";s:4:\"0.00\";s:9:\"is_active\";b:1;s:10:\"sort_order\";i:3;s:10:\"created_at\";s:27:\"2025-10-05T16:27:24.000000Z\";s:10:\"updated_at\";s:27:\"2025-12-18T09:52:57.000000Z\";}s:8:\"director\";a:12:{s:2:\"id\";i:2;s:4:\"name\";s:34:\"امیر مسعود عابدینی\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:4:{i:0;s:11:\"voice_actor\";i:1;s:8:\"director\";i:2;s:8:\"producer\";i:3;s:8:\"narrator\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:00:01.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:00:14.000000Z\";}s:8:\"narrator\";a:12:{s:2:\"id\";i:8;s:4:\"name\";s:21:\"سمانه اصغری\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:2:{i:0;s:11:\"voice_actor\";i:1;s:8:\"narrator\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:02:20.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:04:29.000000Z\";}}i:2;a:55:{s:2:\"id\";i:10;s:5:\"title\";s:42:\"اژدهای نگهبان کتابخانه\";s:8:\"subtitle\";s:29:\"اژدهای کتابخانه\";s:11:\"description\";s:774:\"سارای ده‌ساله، دختر کتاب‌دوست، در کتابخانه قدیمی شهر با اژدهای کوچکی به نام دراکو آشنا می‌شود که نگهبان جادویی کتاب‌هاست. با هم متوجه می‌شوند که «ملکه بی‌حوصله» کلمات و داستان‌ها را می‌دزدد، و مجبورند به چهار دنیای کتاب (جنگل شعرها، شهر ریاضی، دریاچه تاریخ و قصر آینده) سفر کنند تا خیال و قصه‌ها را نجات دهند. در پایان، حتی ملکه بی‌حوصله هم با خواندن کتاب و دوستی، قلبش نرم می‌شود و کتابخانه و دنیای تخیل نجات پیدا می‌کند.\";s:9:\"image_url\";s:58:\"https://my.sarvcast.ir/images/stories/1766050458_cover.jpg\";s:15:\"cover_image_url\";s:64:\"https://my.sarvcast.ir/images/stories/1766050458_cover_cover.jpg\";s:11:\"category_id\";i:4;s:11:\"director_id\";i:2;s:9:\"writer_id\";i:3;s:9:\"author_id\";N;s:11:\"narrator_id\";N;s:9:\"age_group\";s:3:\"6-8\";s:8:\"language\";s:7:\"persian\";s:8:\"duration\";i:0;s:14:\"total_episodes\";i:1;s:13:\"free_episodes\";i:0;s:10:\"is_premium\";b:0;s:18:\"is_completely_free\";b:1;s:10:\"play_count\";i:0;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";a:1:{i:0;s:18:\"ماجراجویی\";}s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";b:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-12-18T09:34:18.000000Z\";s:10:\"updated_at\";s:27:\"2025-12-18T09:44:55.000000Z\";s:18:\"use_image_timeline\";b:0;s:8:\"category\";a:14:{s:2:\"id\";i:4;s:4:\"name\";s:12:\"فانتزی\";s:4:\"slug\";s:15:\"fantasy-stories\";s:11:\"description\";s:79:\"داستان‌های تخیلی و فانتزی با موجودات خیالی\";s:9:\"icon_path\";s:103:\"categories/1759755532_20251006_1622_Dreamy Fantasy Realm_simple_compose_01k6ws7jyfenj92cayqqbng186.webp\";s:5:\"color\";s:7:\"#ec4899\";s:11:\"story_count\";i:3;s:14:\"total_episodes\";i:3;s:14:\"total_duration\";i:939;s:14:\"average_rating\";s:4:\"0.00\";s:9:\"is_active\";b:1;s:10:\"sort_order\";i:4;s:10:\"created_at\";s:27:\"2025-10-05T16:27:24.000000Z\";s:10:\"updated_at\";s:27:\"2025-12-18T09:34:18.000000Z\";}s:8:\"director\";a:12:{s:2:\"id\";i:2;s:4:\"name\";s:34:\"امیر مسعود عابدینی\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:4:{i:0;s:11:\"voice_actor\";i:1;s:8:\"director\";i:2;s:8:\"producer\";i:3;s:8:\"narrator\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:00:01.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:00:14.000000Z\";}s:8:\"narrator\";N;}i:3;a:55:{s:2:\"id\";i:7;s:5:\"title\";s:39:\"مداد رنگی‌های جادویی\";s:8:\"subtitle\";s:31:\"قدرت خلاقیت و هنر\";s:11:\"description\";s:490:\"سارا دختر نه ساله‌ای که جعبه‌ای از مدادهای رنگی جادویی را کشف می‌کند که می‌توانند هر چیزی که می‌کشند را زنده کنند. او از طریق ماجراهایش با این مدادهای جادویی درباره خلاقیت، همکاری و قدرت هنر می‌آموزد. این داستان جادویی کودکان را با دنیای بی‌نهایت خلاقیت آشنا می‌کند.\";s:9:\"image_url\";s:59:\"https://my.sarvcast.ir/images/stories/1759756511_cover.webp\";s:15:\"cover_image_url\";s:65:\"https://my.sarvcast.ir/images/stories/1759756511_cover_cover.webp\";s:11:\"category_id\";i:4;s:11:\"director_id\";N;s:9:\"writer_id\";N;s:9:\"author_id\";N;s:11:\"narrator_id\";N;s:9:\"age_group\";s:3:\"3-5\";s:8:\"language\";s:7:\"persian\";s:8:\"duration\";i:429;s:14:\"total_episodes\";i:1;s:13:\"free_episodes\";i:1;s:10:\"is_premium\";b:0;s:18:\"is_completely_free\";b:1;s:10:\"play_count\";i:0;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";a:1:{i:0;s:6:\"هنر\";}s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";b:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:15:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:18:\"use_image_timeline\";b:1;s:8:\"category\";a:14:{s:2:\"id\";i:4;s:4:\"name\";s:12:\"فانتزی\";s:4:\"slug\";s:15:\"fantasy-stories\";s:11:\"description\";s:79:\"داستان‌های تخیلی و فانتزی با موجودات خیالی\";s:9:\"icon_path\";s:103:\"categories/1759755532_20251006_1622_Dreamy Fantasy Realm_simple_compose_01k6ws7jyfenj92cayqqbng186.webp\";s:5:\"color\";s:7:\"#ec4899\";s:11:\"story_count\";i:3;s:14:\"total_episodes\";i:3;s:14:\"total_duration\";i:939;s:14:\"average_rating\";s:4:\"0.00\";s:9:\"is_active\";b:1;s:10:\"sort_order\";i:4;s:10:\"created_at\";s:27:\"2025-10-05T16:27:24.000000Z\";s:10:\"updated_at\";s:27:\"2025-12-18T09:34:18.000000Z\";}s:8:\"director\";N;s:8:\"narrator\";N;}i:4;a:55:{s:2:\"id\";i:6;s:5:\"title\";s:28:\"مورچه‌های شجاع\";s:8:\"subtitle\";s:40:\"قدرت کار تیمی و همکاری\";s:11:\"description\";s:392:\"گروهی از مورچه‌های شجاع و سختکوش دانه گندم طلایی بزرگی را کشف می‌کنند و باید با همکاری یکدیگر موانع را پشت سر بگذارند تا آن را به لانه‌شان ببرند. این داستان الهام‌بخش کودکان را با ارزش کار تیمی و همکاری آشنا می‌کند.\";s:9:\"image_url\";s:59:\"https://my.sarvcast.ir/images/stories/1759756441_cover.webp\";s:15:\"cover_image_url\";s:65:\"https://my.sarvcast.ir/images/stories/1759756441_cover_cover.webp\";s:11:\"category_id\";i:5;s:11:\"director_id\";i:2;s:9:\"writer_id\";i:10;s:9:\"author_id\";i:10;s:11:\"narrator_id\";i:3;s:9:\"age_group\";s:3:\"3-5\";s:8:\"language\";s:7:\"persian\";s:8:\"duration\";i:505;s:14:\"total_episodes\";i:1;s:13:\"free_episodes\";i:1;s:10:\"is_premium\";b:0;s:18:\"is_completely_free\";b:1;s:10:\"play_count\";i:0;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";a:1:{i:0;s:10:\"دوستی\";}s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";b:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:14:01.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:18:\"use_image_timeline\";b:1;s:8:\"category\";a:14:{s:2:\"id\";i:5;s:4:\"name\";s:14:\"حیوانات\";s:4:\"slug\";s:14:\"animal-stories\";s:11:\"description\";s:95:\"داستان‌هایی که شخصیت‌های اصلی آن‌ها حیوانات هستند\";s:9:\"icon_path\";s:107:\"categories/1759755558_20251006_1624_Forest Friends Gathering_simple_compose_01k6wsa9reefd8a2dhgxhft2wk.webp\";s:5:\"color\";s:7:\"#f97316\";s:11:\"story_count\";i:2;s:14:\"total_episodes\";i:2;s:14:\"total_duration\";i:19;s:14:\"average_rating\";s:4:\"0.00\";s:9:\"is_active\";b:1;s:10:\"sort_order\";i:5;s:10:\"created_at\";s:27:\"2025-10-05T16:27:24.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:17:48.000000Z\";}s:8:\"director\";a:12:{s:2:\"id\";i:2;s:4:\"name\";s:34:\"امیر مسعود عابدینی\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:4:{i:0;s:11:\"voice_actor\";i:1;s:8:\"director\";i:2;s:8:\"producer\";i:3;s:8:\"narrator\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:00:01.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:00:14.000000Z\";}s:8:\"narrator\";a:12:{s:2:\"id\";i:3;s:4:\"name\";s:26:\"نجمه موسوی فرد\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:6:{i:0;s:11:\"voice_actor\";i:1;s:8:\"director\";i:2;s:6:\"writer\";i:3;s:8:\"producer\";i:4;s:6:\"author\";i:5;s:8:\"narrator\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:00:30.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:00:30.000000Z\";}}i:5;a:55:{s:2:\"id\";i:5;s:5:\"title\";s:23:\"هیولای غمگین\";s:8:\"subtitle\";s:56:\"سفری برای درک احساسات و رنگ‌ها\";s:11:\"description\";s:406:\"رنگی هیولای کوچولوی پشمالویی که احساساتش را به صورت رنگ‌های مختلف تجربه می‌کند. او با کمک دوستان جنگلی‌اش می‌آموزد که همه احساسات طبیعی و زیبا هستند. این داستان آموزشی کودکان را با هوش هیجانی و مدیریت احساسات آشنا می‌کند.\";s:9:\"image_url\";s:59:\"https://my.sarvcast.ir/images/stories/1759756340_cover.webp\";s:15:\"cover_image_url\";s:65:\"https://my.sarvcast.ir/images/stories/1759756340_cover_cover.webp\";s:11:\"category_id\";i:4;s:11:\"director_id\";i:2;s:9:\"writer_id\";i:3;s:9:\"author_id\";i:3;s:11:\"narrator_id\";i:4;s:9:\"age_group\";s:3:\"3-5\";s:8:\"language\";s:7:\"persian\";s:8:\"duration\";i:502;s:14:\"total_episodes\";i:1;s:13:\"free_episodes\";i:0;s:10:\"is_premium\";b:0;s:18:\"is_completely_free\";b:1;s:10:\"play_count\";i:0;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";a:1:{i:0;s:18:\"ماجراجویی\";}s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";b:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:12:20.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:18:\"use_image_timeline\";b:1;s:8:\"category\";a:14:{s:2:\"id\";i:4;s:4:\"name\";s:12:\"فانتزی\";s:4:\"slug\";s:15:\"fantasy-stories\";s:11:\"description\";s:79:\"داستان‌های تخیلی و فانتزی با موجودات خیالی\";s:9:\"icon_path\";s:103:\"categories/1759755532_20251006_1622_Dreamy Fantasy Realm_simple_compose_01k6ws7jyfenj92cayqqbng186.webp\";s:5:\"color\";s:7:\"#ec4899\";s:11:\"story_count\";i:3;s:14:\"total_episodes\";i:3;s:14:\"total_duration\";i:939;s:14:\"average_rating\";s:4:\"0.00\";s:9:\"is_active\";b:1;s:10:\"sort_order\";i:4;s:10:\"created_at\";s:27:\"2025-10-05T16:27:24.000000Z\";s:10:\"updated_at\";s:27:\"2025-12-18T09:34:18.000000Z\";}s:8:\"director\";a:12:{s:2:\"id\";i:2;s:4:\"name\";s:34:\"امیر مسعود عابدینی\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:4:{i:0;s:11:\"voice_actor\";i:1;s:8:\"director\";i:2;s:8:\"producer\";i:3;s:8:\"narrator\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:00:01.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:00:14.000000Z\";}s:8:\"narrator\";a:12:{s:2:\"id\";i:4;s:4:\"name\";s:30:\"سوگند محمود شاهی\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:6:{i:0;s:11:\"voice_actor\";i:1;s:8:\"director\";i:2;s:6:\"writer\";i:3;s:8:\"producer\";i:4;s:6:\"author\";i:5;s:8:\"narrator\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:00:41.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:04:32.000000Z\";}}i:6;a:55:{s:2:\"id\";i:4;s:5:\"title\";s:20:\"گاو و گنجشک\";s:8:\"subtitle\";s:51:\"داستان دوستی و شادی در مزرعه\";s:11:\"description\";s:429:\"گاوی گاو قهوه‌ای بزرگ که از آفتاب گرم ناراضی است، با چی‌چی گنجشک کوچولوی شاد آشنا می‌شود. چی‌چی به او می‌آموزد که شادی از گذراندن وقت با دوستان در مزرعه می‌آید. این داستان شیرین کودکان را با ارزش دوستی و لذت زندگی در طبیعت آشنا می‌کند.\";s:9:\"image_url\";s:59:\"https://my.sarvcast.ir/images/stories/1759756220_cover.webp\";s:15:\"cover_image_url\";s:65:\"https://my.sarvcast.ir/images/stories/1759756220_cover_cover.webp\";s:11:\"category_id\";i:5;s:11:\"director_id\";i:2;s:9:\"writer_id\";i:10;s:9:\"author_id\";i:10;s:11:\"narrator_id\";i:5;s:9:\"age_group\";s:3:\"3-5\";s:8:\"language\";s:7:\"persian\";s:8:\"duration\";i:401;s:14:\"total_episodes\";i:1;s:13:\"free_episodes\";i:1;s:10:\"is_premium\";b:0;s:18:\"is_completely_free\";b:1;s:10:\"play_count\";i:0;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";a:1:{i:0;s:10:\"دوستی\";}s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";b:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:10:20.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:18:\"use_image_timeline\";b:1;s:8:\"category\";a:14:{s:2:\"id\";i:5;s:4:\"name\";s:14:\"حیوانات\";s:4:\"slug\";s:14:\"animal-stories\";s:11:\"description\";s:95:\"داستان‌هایی که شخصیت‌های اصلی آن‌ها حیوانات هستند\";s:9:\"icon_path\";s:107:\"categories/1759755558_20251006_1624_Forest Friends Gathering_simple_compose_01k6wsa9reefd8a2dhgxhft2wk.webp\";s:5:\"color\";s:7:\"#f97316\";s:11:\"story_count\";i:2;s:14:\"total_episodes\";i:2;s:14:\"total_duration\";i:19;s:14:\"average_rating\";s:4:\"0.00\";s:9:\"is_active\";b:1;s:10:\"sort_order\";i:5;s:10:\"created_at\";s:27:\"2025-10-05T16:27:24.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:17:48.000000Z\";}s:8:\"director\";a:12:{s:2:\"id\";i:2;s:4:\"name\";s:34:\"امیر مسعود عابدینی\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:4:{i:0;s:11:\"voice_actor\";i:1;s:8:\"director\";i:2;s:8:\"producer\";i:3;s:8:\"narrator\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:00:01.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:00:14.000000Z\";}s:8:\"narrator\";a:12:{s:2:\"id\";i:5;s:4:\"name\";s:24:\"نجمه گندم کار\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:2:{i:0;s:11:\"voice_actor\";i:1;s:8:\"narrator\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:01:28.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:04:38.000000Z\";}}i:7;a:55:{s:2:\"id\";i:3;s:5:\"title\";s:32:\"پشمالو شیر کوچولو\";s:8:\"subtitle\";s:50:\"سفری برای یافتن شجاعت واقعی\";s:11:\"description\";s:463:\"داستان شیر کوچولوی پشمالویی که نمی‌تواند مثل شیرهای دیگر غرش کند. او در سفری جادویی با دوستان جنگلی‌اش ملاقات می‌کند و می‌آموزد که شجاعت واقعی از درون می‌آید، نه از صدای بلند. این داستان زیبا کودکان را با مفاهیم شجاعت، دوستی و اعتماد به نفس آشنا می‌کند.\";s:9:\"image_url\";s:59:\"https://my.sarvcast.ir/images/stories/1759756084_cover.webp\";s:15:\"cover_image_url\";s:65:\"https://my.sarvcast.ir/images/stories/1759756084_cover_cover.webp\";s:11:\"category_id\";i:2;s:11:\"director_id\";i:2;s:9:\"writer_id\";i:3;s:9:\"author_id\";i:3;s:11:\"narrator_id\";i:6;s:9:\"age_group\";s:3:\"3-5\";s:8:\"language\";s:7:\"persian\";s:8:\"duration\";i:409;s:14:\"total_episodes\";i:1;s:13:\"free_episodes\";i:1;s:10:\"is_premium\";b:0;s:18:\"is_completely_free\";b:1;s:10:\"play_count\";i:0;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";a:1:{i:0;s:18:\"ماجراجویی\";}s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";b:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:08:04.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T14:15:18.000000Z\";s:18:\"use_image_timeline\";b:1;s:8:\"category\";a:14:{s:2:\"id\";i:2;s:4:\"name\";s:18:\"ماجراجویی\";s:4:\"slug\";s:17:\"adventure-stories\";s:11:\"description\";s:93:\"داستان‌های هیجان‌انگیز و ماجراجویانه برای کودکان\";s:9:\"icon_path\";s:107:\"categories/1759755571_20251006_1622_Magical Forest Adventure_simple_compose_01k6ws6nmjfvbtf6tk8vzj96mg.webp\";s:5:\"color\";s:7:\"#f59e0b\";s:11:\"story_count\";i:1;s:14:\"total_episodes\";i:1;s:14:\"total_duration\";i:409;s:14:\"average_rating\";s:4:\"0.00\";s:9:\"is_active\";b:1;s:10:\"sort_order\";i:2;s:10:\"created_at\";s:27:\"2025-10-05T16:27:24.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-28T20:32:46.000000Z\";}s:8:\"director\";a:12:{s:2:\"id\";i:2;s:4:\"name\";s:34:\"امیر مسعود عابدینی\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:4:{i:0;s:11:\"voice_actor\";i:1;s:8:\"director\";i:2;s:8:\"producer\";i:3;s:8:\"narrator\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:00:01.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:00:14.000000Z\";}s:8:\"narrator\";a:12:{s:2:\"id\";i:6;s:4:\"name\";s:19:\"لیلا عزیزی\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:2:{i:0;s:11:\"voice_actor\";i:1;s:8:\"narrator\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:01:44.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:01:44.000000Z\";}}}}',1766052318),('laravel-cache-api_api/v1/stories/4','a:2:{s:7:\"success\";b:1;s:4:\"data\";a:5:{s:5:\"story\";a:59:{s:2:\"id\";i:4;s:5:\"title\";s:20:\"گاو و گنجشک\";s:8:\"subtitle\";s:51:\"داستان دوستی و شادی در مزرعه\";s:11:\"description\";s:429:\"گاوی گاو قهوه‌ای بزرگ که از آفتاب گرم ناراضی است، با چی‌چی گنجشک کوچولوی شاد آشنا می‌شود. چی‌چی به او می‌آموزد که شادی از گذراندن وقت با دوستان در مزرعه می‌آید. این داستان شیرین کودکان را با ارزش دوستی و لذت زندگی در طبیعت آشنا می‌کند.\";s:9:\"image_url\";s:59:\"https://my.sarvcast.ir/images/stories/1759756220_cover.webp\";s:15:\"cover_image_url\";s:65:\"https://my.sarvcast.ir/images/stories/1759756220_cover_cover.webp\";s:11:\"category_id\";i:5;s:11:\"director_id\";i:2;s:9:\"writer_id\";i:10;s:9:\"author_id\";i:10;s:11:\"narrator_id\";i:5;s:9:\"age_group\";s:3:\"3-5\";s:8:\"language\";s:7:\"persian\";s:8:\"duration\";i:401;s:14:\"total_episodes\";i:1;s:13:\"free_episodes\";i:1;s:10:\"is_premium\";b:0;s:18:\"is_completely_free\";b:1;s:10:\"play_count\";i:0;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";a:1:{i:0;s:10:\"دوستی\";}s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";b:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:10:20.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:03:29.000000Z\";s:18:\"use_image_timeline\";b:1;s:8:\"category\";a:14:{s:2:\"id\";i:5;s:4:\"name\";s:14:\"حیوانات\";s:4:\"slug\";s:14:\"animal-stories\";s:11:\"description\";s:95:\"داستان‌هایی که شخصیت‌های اصلی آن‌ها حیوانات هستند\";s:9:\"icon_path\";s:107:\"categories/1759755558_20251006_1624_Forest Friends Gathering_simple_compose_01k6wsa9reefd8a2dhgxhft2wk.webp\";s:5:\"color\";s:7:\"#f97316\";s:11:\"story_count\";i:2;s:14:\"total_episodes\";i:2;s:14:\"total_duration\";i:19;s:14:\"average_rating\";s:4:\"0.00\";s:9:\"is_active\";b:1;s:10:\"sort_order\";i:5;s:10:\"created_at\";s:27:\"2025-10-05T16:27:24.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:17:48.000000Z\";}s:8:\"director\";a:12:{s:2:\"id\";i:2;s:4:\"name\";s:34:\"امیر مسعود عابدینی\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:4:{i:0;s:11:\"voice_actor\";i:1;s:8:\"director\";i:2;s:8:\"producer\";i:3;s:8:\"narrator\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:00:01.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:00:14.000000Z\";}s:6:\"writer\";a:12:{s:2:\"id\";i:10;s:4:\"name\";s:25:\"ابوالفضل نجفی\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:2:{i:0;s:6:\"writer\";i:1;s:6:\"author\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:08:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:08:29.000000Z\";}s:6:\"author\";a:12:{s:2:\"id\";i:10;s:4:\"name\";s:25:\"ابوالفضل نجفی\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:2:{i:0;s:6:\"writer\";i:1;s:6:\"author\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:08:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:08:29.000000Z\";}s:8:\"narrator\";a:12:{s:2:\"id\";i:5;s:4:\"name\";s:24:\"نجمه گندم کار\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:2:{i:0;s:11:\"voice_actor\";i:1;s:8:\"narrator\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:01:28.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:04:38.000000Z\";}s:8:\"episodes\";a:1:{i:0;a:47:{s:2:\"id\";i:4;s:8:\"story_id\";i:4;s:11:\"narrator_id\";i:5;s:5:\"title\";s:26:\"کل داستان گاوی\";s:11:\"description\";N;s:9:\"audio_url\";s:108:\"https://my.sarvcast.ir/storage/audio/episodes/audio_xA58lhWbTQ9H1iFIKaB6vkVqCRDoecjd-2025-10-06_16-54-25.mp3\";s:16:\"local_audio_path\";N;s:8:\"duration\";i:401;s:14:\"episode_number\";i:1;s:10:\"is_premium\";b:0;s:10:\"image_urls\";a:0:{}s:10:\"play_count\";i:47;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";N;s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";i:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:24:26.000000Z\";s:10:\"updated_at\";s:27:\"2025-12-18T09:58:57.000000Z\";s:25:\"has_multiple_voice_actors\";b:0;s:17:\"voice_actor_count\";i:0;s:18:\"use_image_timeline\";b:0;}}s:6:\"people\";a:0:{}}s:11:\"access_info\";a:3:{s:10:\"has_access\";b:1;s:6:\"reason\";s:12:\"free_content\";s:7:\"message\";s:32:\"داستان رایگان است\";}s:19:\"accessible_episodes\";a:1:{i:0;a:47:{s:2:\"id\";i:4;s:8:\"story_id\";i:4;s:11:\"narrator_id\";i:5;s:5:\"title\";s:26:\"کل داستان گاوی\";s:11:\"description\";N;s:9:\"audio_url\";s:108:\"https://my.sarvcast.ir/storage/audio/episodes/audio_xA58lhWbTQ9H1iFIKaB6vkVqCRDoecjd-2025-10-06_16-54-25.mp3\";s:16:\"local_audio_path\";N;s:8:\"duration\";i:401;s:14:\"episode_number\";i:1;s:10:\"is_premium\";b:0;s:10:\"image_urls\";a:0:{}s:10:\"play_count\";i:47;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";N;s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";i:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:24:26.000000Z\";s:10:\"updated_at\";s:27:\"2025-12-18T09:58:57.000000Z\";s:25:\"has_multiple_voice_actors\";b:0;s:17:\"voice_actor_count\";i:0;s:18:\"use_image_timeline\";b:0;}}s:11:\"is_favorite\";b:0;s:11:\"user_rating\";N;}}',1766052334),('laravel-cache-api_api/v1/stories/5','a:2:{s:7:\"success\";b:1;s:4:\"data\";a:5:{s:5:\"story\";a:59:{s:2:\"id\";i:5;s:5:\"title\";s:23:\"هیولای غمگین\";s:8:\"subtitle\";s:56:\"سفری برای درک احساسات و رنگ‌ها\";s:11:\"description\";s:406:\"رنگی هیولای کوچولوی پشمالویی که احساساتش را به صورت رنگ‌های مختلف تجربه می‌کند. او با کمک دوستان جنگلی‌اش می‌آموزد که همه احساسات طبیعی و زیبا هستند. این داستان آموزشی کودکان را با هوش هیجانی و مدیریت احساسات آشنا می‌کند.\";s:9:\"image_url\";s:59:\"https://my.sarvcast.ir/images/stories/1759756340_cover.webp\";s:15:\"cover_image_url\";s:65:\"https://my.sarvcast.ir/images/stories/1759756340_cover_cover.webp\";s:11:\"category_id\";i:4;s:11:\"director_id\";i:2;s:9:\"writer_id\";i:3;s:9:\"author_id\";i:3;s:11:\"narrator_id\";i:4;s:9:\"age_group\";s:3:\"3-5\";s:8:\"language\";s:7:\"persian\";s:8:\"duration\";i:502;s:14:\"total_episodes\";i:1;s:13:\"free_episodes\";i:0;s:10:\"is_premium\";b:0;s:18:\"is_completely_free\";b:1;s:10:\"play_count\";i:0;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";a:1:{i:0;s:18:\"ماجراجویی\";}s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";b:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:12:20.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-12T06:37:11.000000Z\";s:18:\"use_image_timeline\";b:1;s:8:\"category\";a:14:{s:2:\"id\";i:4;s:4:\"name\";s:12:\"فانتزی\";s:4:\"slug\";s:15:\"fantasy-stories\";s:11:\"description\";s:79:\"داستان‌های تخیلی و فانتزی با موجودات خیالی\";s:9:\"icon_path\";s:103:\"categories/1759755532_20251006_1622_Dreamy Fantasy Realm_simple_compose_01k6ws7jyfenj92cayqqbng186.webp\";s:5:\"color\";s:7:\"#ec4899\";s:11:\"story_count\";i:3;s:14:\"total_episodes\";i:3;s:14:\"total_duration\";i:939;s:14:\"average_rating\";s:4:\"0.00\";s:9:\"is_active\";b:1;s:10:\"sort_order\";i:4;s:10:\"created_at\";s:27:\"2025-10-05T16:27:24.000000Z\";s:10:\"updated_at\";s:27:\"2025-12-18T09:34:18.000000Z\";}s:8:\"director\";a:12:{s:2:\"id\";i:2;s:4:\"name\";s:34:\"امیر مسعود عابدینی\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:4:{i:0;s:11:\"voice_actor\";i:1;s:8:\"director\";i:2;s:8:\"producer\";i:3;s:8:\"narrator\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:00:01.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:00:14.000000Z\";}s:6:\"writer\";a:12:{s:2:\"id\";i:3;s:4:\"name\";s:26:\"نجمه موسوی فرد\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:6:{i:0;s:11:\"voice_actor\";i:1;s:8:\"director\";i:2;s:6:\"writer\";i:3;s:8:\"producer\";i:4;s:6:\"author\";i:5;s:8:\"narrator\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:00:30.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:00:30.000000Z\";}s:6:\"author\";a:12:{s:2:\"id\";i:3;s:4:\"name\";s:26:\"نجمه موسوی فرد\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:6:{i:0;s:11:\"voice_actor\";i:1;s:8:\"director\";i:2;s:6:\"writer\";i:3;s:8:\"producer\";i:4;s:6:\"author\";i:5;s:8:\"narrator\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:00:30.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:00:30.000000Z\";}s:8:\"narrator\";a:12:{s:2:\"id\";i:4;s:4:\"name\";s:30:\"سوگند محمود شاهی\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:6:{i:0;s:11:\"voice_actor\";i:1;s:8:\"director\";i:2;s:6:\"writer\";i:3;s:8:\"producer\";i:4;s:6:\"author\";i:5;s:8:\"narrator\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:00:41.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:04:32.000000Z\";}s:8:\"episodes\";a:1:{i:0;a:47:{s:2:\"id\";i:6;s:8:\"story_id\";i:5;s:11:\"narrator_id\";i:4;s:5:\"title\";s:41:\"کل داستان هیولای غمگین\";s:11:\"description\";N;s:9:\"audio_url\";s:108:\"https://my.sarvcast.ir/storage/audio/episodes/audio_16hN2mZX3G5JjoF7wDisHY8bPWnLxSAV-2025-10-06_17-02-09.mp3\";s:16:\"local_audio_path\";N;s:8:\"duration\";i:502;s:14:\"episode_number\";i:1;s:10:\"is_premium\";b:1;s:10:\"image_urls\";a:0:{}s:10:\"play_count\";i:27;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";N;s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";i:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:32:10.000000Z\";s:10:\"updated_at\";s:27:\"2025-12-18T09:55:08.000000Z\";s:25:\"has_multiple_voice_actors\";b:0;s:17:\"voice_actor_count\";i:0;s:18:\"use_image_timeline\";b:0;}}s:6:\"people\";a:0:{}}s:11:\"access_info\";a:3:{s:10:\"has_access\";b:1;s:6:\"reason\";s:12:\"free_content\";s:7:\"message\";s:32:\"داستان رایگان است\";}s:19:\"accessible_episodes\";a:0:{}s:11:\"is_favorite\";b:0;s:11:\"user_rating\";N;}}',1766052323),('laravel-cache-api_api/v1/stories/6','a:2:{s:7:\"success\";b:1;s:4:\"data\";a:5:{s:5:\"story\";a:59:{s:2:\"id\";i:6;s:5:\"title\";s:28:\"مورچه‌های شجاع\";s:8:\"subtitle\";s:40:\"قدرت کار تیمی و همکاری\";s:11:\"description\";s:392:\"گروهی از مورچه‌های شجاع و سختکوش دانه گندم طلایی بزرگی را کشف می‌کنند و باید با همکاری یکدیگر موانع را پشت سر بگذارند تا آن را به لانه‌شان ببرند. این داستان الهام‌بخش کودکان را با ارزش کار تیمی و همکاری آشنا می‌کند.\";s:9:\"image_url\";s:59:\"https://my.sarvcast.ir/images/stories/1759756441_cover.webp\";s:15:\"cover_image_url\";s:65:\"https://my.sarvcast.ir/images/stories/1759756441_cover_cover.webp\";s:11:\"category_id\";i:5;s:11:\"director_id\";i:2;s:9:\"writer_id\";i:10;s:9:\"author_id\";i:10;s:11:\"narrator_id\";i:3;s:9:\"age_group\";s:3:\"3-5\";s:8:\"language\";s:7:\"persian\";s:8:\"duration\";i:505;s:14:\"total_episodes\";i:1;s:13:\"free_episodes\";i:1;s:10:\"is_premium\";b:0;s:18:\"is_completely_free\";b:1;s:10:\"play_count\";i:0;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";a:1:{i:0;s:10:\"دوستی\";}s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";b:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:14:01.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T06:13:21.000000Z\";s:18:\"use_image_timeline\";b:1;s:8:\"category\";a:14:{s:2:\"id\";i:5;s:4:\"name\";s:14:\"حیوانات\";s:4:\"slug\";s:14:\"animal-stories\";s:11:\"description\";s:95:\"داستان‌هایی که شخصیت‌های اصلی آن‌ها حیوانات هستند\";s:9:\"icon_path\";s:107:\"categories/1759755558_20251006_1624_Forest Friends Gathering_simple_compose_01k6wsa9reefd8a2dhgxhft2wk.webp\";s:5:\"color\";s:7:\"#f97316\";s:11:\"story_count\";i:2;s:14:\"total_episodes\";i:2;s:14:\"total_duration\";i:19;s:14:\"average_rating\";s:4:\"0.00\";s:9:\"is_active\";b:1;s:10:\"sort_order\";i:5;s:10:\"created_at\";s:27:\"2025-10-05T16:27:24.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:17:48.000000Z\";}s:8:\"director\";a:12:{s:2:\"id\";i:2;s:4:\"name\";s:34:\"امیر مسعود عابدینی\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:4:{i:0;s:11:\"voice_actor\";i:1;s:8:\"director\";i:2;s:8:\"producer\";i:3;s:8:\"narrator\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:00:01.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:00:14.000000Z\";}s:6:\"writer\";a:12:{s:2:\"id\";i:10;s:4:\"name\";s:25:\"ابوالفضل نجفی\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:2:{i:0;s:6:\"writer\";i:1;s:6:\"author\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:08:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:08:29.000000Z\";}s:6:\"author\";a:12:{s:2:\"id\";i:10;s:4:\"name\";s:25:\"ابوالفضل نجفی\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:2:{i:0;s:6:\"writer\";i:1;s:6:\"author\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:08:29.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:08:29.000000Z\";}s:8:\"narrator\";a:12:{s:2:\"id\";i:3;s:4:\"name\";s:26:\"نجمه موسوی فرد\";s:3:\"bio\";N;s:9:\"image_url\";N;s:5:\"roles\";a:6:{i:0;s:11:\"voice_actor\";i:1;s:8:\"director\";i:2;s:6:\"writer\";i:3;s:8:\"producer\";i:4;s:6:\"author\";i:5;s:8:\"narrator\";}s:13:\"total_stories\";i:0;s:14:\"total_episodes\";i:0;s:14:\"average_rating\";s:4:\"0.00\";s:11:\"is_verified\";b:1;s:14:\"last_active_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:00:30.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-06T13:00:30.000000Z\";}s:8:\"episodes\";a:1:{i:0;a:47:{s:2:\"id\";i:5;s:8:\"story_id\";i:6;s:11:\"narrator_id\";i:3;s:5:\"title\";s:37:\"کل داستان مورچه شجاع\";s:11:\"description\";N;s:9:\"audio_url\";s:108:\"https://my.sarvcast.ir/storage/audio/episodes/audio_jIAFUnwL72WgsqitZ1Bm4uXGYOvKx3QJ-2025-10-06_17-00-38.mp3\";s:16:\"local_audio_path\";N;s:8:\"duration\";i:505;s:14:\"episode_number\";i:1;s:10:\"is_premium\";b:0;s:10:\"image_urls\";a:0:{}s:10:\"play_count\";i:19;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";N;s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";i:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:30:39.000000Z\";s:10:\"updated_at\";s:27:\"2025-12-18T06:46:24.000000Z\";s:25:\"has_multiple_voice_actors\";b:0;s:17:\"voice_actor_count\";i:0;s:18:\"use_image_timeline\";b:0;}}s:6:\"people\";a:0:{}}s:11:\"access_info\";a:3:{s:10:\"has_access\";b:1;s:6:\"reason\";s:12:\"free_content\";s:7:\"message\";s:32:\"داستان رایگان است\";}s:19:\"accessible_episodes\";a:1:{i:0;a:47:{s:2:\"id\";i:5;s:8:\"story_id\";i:6;s:11:\"narrator_id\";i:3;s:5:\"title\";s:37:\"کل داستان مورچه شجاع\";s:11:\"description\";N;s:9:\"audio_url\";s:108:\"https://my.sarvcast.ir/storage/audio/episodes/audio_jIAFUnwL72WgsqitZ1Bm4uXGYOvKx3QJ-2025-10-06_17-00-38.mp3\";s:16:\"local_audio_path\";N;s:8:\"duration\";i:505;s:14:\"episode_number\";i:1;s:10:\"is_premium\";b:0;s:10:\"image_urls\";a:0:{}s:10:\"play_count\";i:19;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";N;s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";i:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:30:39.000000Z\";s:10:\"updated_at\";s:27:\"2025-12-18T06:46:24.000000Z\";s:25:\"has_multiple_voice_actors\";b:0;s:17:\"voice_actor_count\";i:0;s:18:\"use_image_timeline\";b:0;}}s:11:\"is_favorite\";b:0;s:11:\"user_rating\";N;}}',1766051894),('laravel-cache-api_api/v1/stories/7','a:2:{s:7:\"success\";b:1;s:4:\"data\";a:5:{s:5:\"story\";a:59:{s:2:\"id\";i:7;s:5:\"title\";s:39:\"مداد رنگی‌های جادویی\";s:8:\"subtitle\";s:31:\"قدرت خلاقیت و هنر\";s:11:\"description\";s:490:\"سارا دختر نه ساله‌ای که جعبه‌ای از مدادهای رنگی جادویی را کشف می‌کند که می‌توانند هر چیزی که می‌کشند را زنده کنند. او از طریق ماجراهایش با این مدادهای جادویی درباره خلاقیت، همکاری و قدرت هنر می‌آموزد. این داستان جادویی کودکان را با دنیای بی‌نهایت خلاقیت آشنا می‌کند.\";s:9:\"image_url\";s:59:\"https://my.sarvcast.ir/images/stories/1759756511_cover.webp\";s:15:\"cover_image_url\";s:65:\"https://my.sarvcast.ir/images/stories/1759756511_cover_cover.webp\";s:11:\"category_id\";i:4;s:11:\"director_id\";N;s:9:\"writer_id\";N;s:9:\"author_id\";N;s:11:\"narrator_id\";N;s:9:\"age_group\";s:3:\"3-5\";s:8:\"language\";s:7:\"persian\";s:8:\"duration\";i:429;s:14:\"total_episodes\";i:1;s:13:\"free_episodes\";i:1;s:10:\"is_premium\";b:0;s:18:\"is_completely_free\";b:1;s:10:\"play_count\";i:0;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";a:1:{i:0;s:6:\"هنر\";}s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";b:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:15:11.000000Z\";s:10:\"updated_at\";s:27:\"2025-10-11T05:58:45.000000Z\";s:18:\"use_image_timeline\";b:1;s:8:\"category\";a:14:{s:2:\"id\";i:4;s:4:\"name\";s:12:\"فانتزی\";s:4:\"slug\";s:15:\"fantasy-stories\";s:11:\"description\";s:79:\"داستان‌های تخیلی و فانتزی با موجودات خیالی\";s:9:\"icon_path\";s:103:\"categories/1759755532_20251006_1622_Dreamy Fantasy Realm_simple_compose_01k6ws7jyfenj92cayqqbng186.webp\";s:5:\"color\";s:7:\"#ec4899\";s:11:\"story_count\";i:3;s:14:\"total_episodes\";i:3;s:14:\"total_duration\";i:939;s:14:\"average_rating\";s:4:\"0.00\";s:9:\"is_active\";b:1;s:10:\"sort_order\";i:4;s:10:\"created_at\";s:27:\"2025-10-05T16:27:24.000000Z\";s:10:\"updated_at\";s:27:\"2025-12-18T09:34:18.000000Z\";}s:8:\"director\";N;s:6:\"writer\";N;s:6:\"author\";N;s:8:\"narrator\";N;s:8:\"episodes\";a:1:{i:0;a:47:{s:2:\"id\";i:3;s:8:\"story_id\";i:7;s:11:\"narrator_id\";i:8;s:5:\"title\";s:40:\"کل داستان مداد رنگی ها\";s:11:\"description\";N;s:9:\"audio_url\";s:108:\"https://my.sarvcast.ir/storage/audio/episodes/audio_iH3J5SVoYdCyNP8OhfMsZRzGAuLw9Ipv-2025-10-06_16-51-34.mp3\";s:16:\"local_audio_path\";N;s:8:\"duration\";i:429;s:14:\"episode_number\";i:1;s:10:\"is_premium\";b:0;s:10:\"image_urls\";a:0:{}s:10:\"play_count\";i:27;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";N;s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";i:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:21:34.000000Z\";s:10:\"updated_at\";s:27:\"2025-12-18T06:39:24.000000Z\";s:25:\"has_multiple_voice_actors\";b:0;s:17:\"voice_actor_count\";i:0;s:18:\"use_image_timeline\";b:0;}}s:6:\"people\";a:0:{}}s:11:\"access_info\";a:3:{s:10:\"has_access\";b:1;s:6:\"reason\";s:12:\"free_content\";s:7:\"message\";s:32:\"داستان رایگان است\";}s:19:\"accessible_episodes\";a:1:{i:0;a:47:{s:2:\"id\";i:3;s:8:\"story_id\";i:7;s:11:\"narrator_id\";i:8;s:5:\"title\";s:40:\"کل داستان مداد رنگی ها\";s:11:\"description\";N;s:9:\"audio_url\";s:108:\"https://my.sarvcast.ir/storage/audio/episodes/audio_iH3J5SVoYdCyNP8OhfMsZRzGAuLw9Ipv-2025-10-06_16-51-34.mp3\";s:16:\"local_audio_path\";N;s:8:\"duration\";i:429;s:14:\"episode_number\";i:1;s:10:\"is_premium\";b:0;s:10:\"image_urls\";a:0:{}s:10:\"play_count\";i:27;s:11:\"total_plays\";i:0;s:15:\"total_favorites\";i:0;s:13:\"total_ratings\";i:0;s:10:\"avg_rating\";s:4:\"0.00\";s:21:\"total_duration_played\";i:0;s:16:\"unique_listeners\";i:0;s:16:\"completion_count\";i:0;s:15:\"completion_rate\";s:4:\"0.00\";s:11:\"share_count\";i:0;s:14:\"download_count\";i:0;s:14:\"last_played_at\";N;s:14:\"trending_since\";N;s:14:\"analytics_data\";N;s:6:\"rating\";s:4:\"0.00\";s:4:\"tags\";N;s:6:\"status\";s:9:\"published\";s:17:\"moderation_status\";s:7:\"pending\";s:12:\"moderator_id\";N;s:12:\"moderated_at\";N;s:16:\"moderation_notes\";N;s:17:\"moderation_rating\";N;s:10:\"age_rating\";N;s:16:\"content_warnings\";N;s:14:\"rejection_code\";N;s:21:\"rejection_suggestions\";N;s:18:\"allow_resubmission\";i:1;s:19:\"moderation_priority\";s:6:\"medium\";s:9:\"flag_type\";N;s:18:\"moderation_history\";N;s:12:\"published_at\";N;s:10:\"created_at\";s:27:\"2025-10-06T13:21:34.000000Z\";s:10:\"updated_at\";s:27:\"2025-12-18T06:39:24.000000Z\";s:25:\"has_multiple_voice_actors\";b:0;s:17:\"voice_actor_count\";i:0;s:18:\"use_image_timeline\";b:0;}}s:11:\"is_favorite\";b:0;s:11:\"user_rating\";N;}}',1766051850),('laravel-cache-api_requests:172.236.192.94','i:13;',1766051744),('laravel-cache-api_requests:172.236.192.94:timer','i:1766051744;',1766051744),('laravel-cache-api_requests:45.93.170.110','i:9;',1766052198),('laravel-cache-api_requests:45.93.170.110:timer','i:1766052198;',1766052198),('laravel-cache-api_requests:5.209.63.200','i:13;',1766051730),('laravel-cache-api_requests:5.209.63.200:timer','i:1766051730;',1766051730);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `icon_path` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#4A90E2',
  `story_count` int NOT NULL DEFAULT '0',
  `total_episodes` int NOT NULL DEFAULT '0',
  `total_duration` int NOT NULL DEFAULT '0',
  `average_rating` decimal(3,2) NOT NULL DEFAULT '0.00',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `categories_is_active_index` (`is_active`),
  KEY `categories_sort_order_index` (`sort_order`),
  KEY `categories_slug_index` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (2,'ماجراجویی','adventure-stories','داستان‌های هیجان‌انگیز و ماجراجویانه برای کودکان','categories/1759755571_20251006_1622_Magical Forest Adventure_simple_compose_01k6ws6nmjfvbtf6tk8vzj96mg.webp','#f59e0b',1,1,409,0.00,1,2,'2025-10-05 19:57:24','2025-10-29 00:02:46'),(3,'آموزشی','educational-stories','داستان‌هایی که مفاهیم آموزشی را به کودکان می‌آموزند','categories/1759755521_20251006_1624_Magical Classroom Learning_simple_compose_01k6wsa61tf2p9m2wvht6sye7n.webp','#10b981',2,2,24,0.00,1,3,'2025-10-05 19:57:24','2025-12-18 13:22:57'),(4,'فانتزی','fantasy-stories','داستان‌های تخیلی و فانتزی با موجودات خیالی','categories/1759755532_20251006_1622_Dreamy Fantasy Realm_simple_compose_01k6ws7jyfenj92cayqqbng186.webp','#ec4899',3,3,939,0.00,1,4,'2025-10-05 19:57:24','2025-12-18 13:04:18'),(5,'حیوانات','animal-stories','داستان‌هایی که شخصیت‌های اصلی آن‌ها حیوانات هستند','categories/1759755558_20251006_1624_Forest Friends Gathering_simple_compose_01k6wsa9reefd8a2dhgxhft2wk.webp','#f97316',2,2,19,0.00,1,5,'2025-10-05 19:57:24','2025-10-06 16:47:48');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `challenges`
--

DROP TABLE IF EXISTS `challenges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `challenges` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `objectives` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `rewards` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_repeatable` tinyint(1) NOT NULL DEFAULT '0',
  `max_participants` int DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `challenges_slug_unique` (`slug`),
  KEY `challenges_type_is_active_index` (`type`,`is_active`),
  KEY `challenges_category_is_active_index` (`category`,`is_active`),
  KEY `challenges_start_date_end_date_index` (`start_date`,`end_date`),
  CONSTRAINT `challenges_chk_1` CHECK (json_valid(`objectives`)),
  CONSTRAINT `challenges_chk_2` CHECK (json_valid(`rewards`)),
  CONSTRAINT `challenges_chk_3` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `challenges`
--

LOCK TABLES `challenges` WRITE;
/*!40000 ALTER TABLE `challenges` DISABLE KEYS */;
/*!40000 ALTER TABLE `challenges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin_transactions`
--

DROP TABLE IF EXISTS `coin_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `coin_transactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `transaction_type` enum('earned','spent','bonus','referral','quiz','achievement','streak') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` int NOT NULL,
  `source_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_id` bigint unsigned DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `transacted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `coin_transactions_user_id_transaction_type_index` (`user_id`,`transaction_type`),
  KEY `coin_transactions_user_id_transacted_at_index` (`user_id`,`transacted_at`),
  KEY `coin_transactions_source_type_source_id_index` (`source_type`,`source_id`),
  CONSTRAINT `coin_transactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `coin_transactions_chk_1` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin_transactions`
--

LOCK TABLES `coin_transactions` WRITE;
/*!40000 ALTER TABLE `coin_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment_likes`
--

DROP TABLE IF EXISTS `comment_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment_likes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `comment_id` bigint unsigned NOT NULL,
  `liked_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `comment_likes_user_id_comment_id_unique` (`user_id`,`comment_id`),
  KEY `comment_likes_comment_id_liked_at_index` (`comment_id`,`liked_at`),
  KEY `comment_likes_user_id_liked_at_index` (`user_id`,`liked_at`),
  CONSTRAINT `comment_likes_comment_id_foreign` FOREIGN KEY (`comment_id`) REFERENCES `user_comments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comment_likes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment_likes`
--

LOCK TABLES `comment_likes` WRITE;
/*!40000 ALTER TABLE `comment_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `comment_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commission_payments`
--

DROP TABLE IF EXISTS `commission_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commission_payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `affiliate_partner_id` bigint unsigned NOT NULL,
  `coupon_usage_id` bigint unsigned DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'IRR',
  `payment_type` enum('coupon_commission','referral_commission','manual') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'coupon_commission',
  `status` enum('pending','processing','paid','failed','cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `payment_method` enum('bank_transfer','digital_wallet','manual') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'bank_transfer',
  `payment_reference` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `processed_at` timestamp NULL DEFAULT NULL,
  `paid_at` timestamp NULL DEFAULT NULL,
  `processed_by` bigint unsigned DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `commission_payments_coupon_usage_id_foreign` (`coupon_usage_id`),
  KEY `commission_payments_processed_by_foreign` (`processed_by`),
  KEY `commission_payments_affiliate_partner_id_status_index` (`affiliate_partner_id`,`status`),
  KEY `commission_payments_status_processed_at_index` (`status`,`processed_at`),
  KEY `commission_payments_payment_type_created_at_index` (`payment_type`,`created_at`),
  CONSTRAINT `commission_payments_affiliate_partner_id_foreign` FOREIGN KEY (`affiliate_partner_id`) REFERENCES `affiliate_partners` (`id`) ON DELETE CASCADE,
  CONSTRAINT `commission_payments_coupon_usage_id_foreign` FOREIGN KEY (`coupon_usage_id`) REFERENCES `coupon_usages` (`id`) ON DELETE SET NULL,
  CONSTRAINT `commission_payments_processed_by_foreign` FOREIGN KEY (`processed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `commission_payments_chk_1` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commission_payments`
--

LOCK TABLES `commission_payments` WRITE;
/*!40000 ALTER TABLE `commission_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `commission_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commissions`
--

DROP TABLE IF EXISTS `commissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `affiliate_partner_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `subscription_id` bigint unsigned NOT NULL,
  `subscription_amount` decimal(10,2) NOT NULL,
  `commission_rate` decimal(5,2) NOT NULL,
  `commission_amount` decimal(10,2) NOT NULL,
  `status` enum('pending','approved','paid','cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `commission_period_start` date NOT NULL,
  `commission_period_end` date NOT NULL,
  `paid_at` timestamp NULL DEFAULT NULL,
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `commissions_user_id_foreign` (`user_id`),
  KEY `commissions_subscription_id_foreign` (`subscription_id`),
  KEY `commissions_affiliate_partner_id_status_index` (`affiliate_partner_id`,`status`),
  KEY `commissions_commission_period_start_commission_period_end_index` (`commission_period_start`,`commission_period_end`),
  CONSTRAINT `commissions_affiliate_partner_id_foreign` FOREIGN KEY (`affiliate_partner_id`) REFERENCES `affiliate_partners` (`id`) ON DELETE CASCADE,
  CONSTRAINT `commissions_subscription_id_foreign` FOREIGN KEY (`subscription_id`) REFERENCES `subscriptions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `commissions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commissions`
--

LOCK TABLES `commissions` WRITE;
/*!40000 ALTER TABLE `commissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `commissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content_shares`
--

DROP TABLE IF EXISTS `content_shares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `content_shares` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `shareable_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `shareable_id` bigint unsigned NOT NULL,
  `share_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `platform` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `share_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `shared_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `content_shares_user_id_shared_at_index` (`user_id`,`shared_at`),
  KEY `content_shares_shareable_type_shareable_id_index` (`shareable_type`,`shareable_id`),
  KEY `content_shares_share_type_shared_at_index` (`share_type`,`shared_at`),
  KEY `content_shares_platform_shared_at_index` (`platform`,`shared_at`),
  CONSTRAINT `content_shares_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `content_shares_chk_1` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_shares`
--

LOCK TABLES `content_shares` WRITE;
/*!40000 ALTER TABLE `content_shares` DISABLE KEYS */;
/*!40000 ALTER TABLE `content_shares` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content_similarity_matrix`
--

DROP TABLE IF EXISTS `content_similarity_matrix`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `content_similarity_matrix` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `story_id` bigint unsigned NOT NULL,
  `similar_story_id` bigint unsigned NOT NULL,
  `similarity_score` decimal(5,4) NOT NULL,
  `similarity_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `calculated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_similarity_matrix_story_id_similar_story_id_unique` (`story_id`,`similar_story_id`),
  KEY `content_sim_story_idx` (`story_id`,`similarity_score`),
  KEY `content_sim_similar_idx` (`similar_story_id`,`similarity_score`),
  KEY `content_sim_type_idx` (`similarity_type`,`similarity_score`),
  CONSTRAINT `content_similarity_matrix_similar_story_id_foreign` FOREIGN KEY (`similar_story_id`) REFERENCES `stories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `content_similarity_matrix_story_id_foreign` FOREIGN KEY (`story_id`) REFERENCES `stories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_similarity_matrix`
--

LOCK TABLES `content_similarity_matrix` WRITE;
/*!40000 ALTER TABLE `content_similarity_matrix` DISABLE KEYS */;
/*!40000 ALTER TABLE `content_similarity_matrix` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `corporate_sponsorships`
--

DROP TABLE IF EXISTS `corporate_sponsorships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `corporate_sponsorships` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `affiliate_partner_id` bigint unsigned NOT NULL,
  `company_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `industry` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_size` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_person` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `website_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sponsorship_type` enum('content_sponsorship','brand_partnership','educational_initiative','cultural_preservation','technology_partnership') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sponsorship_amount` decimal(12,2) NOT NULL,
  `currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'IRR',
  `payment_frequency` enum('one_time','monthly','quarterly','annually') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sponsorship_start_date` date NOT NULL,
  `sponsorship_end_date` date NOT NULL,
  `status` enum('pending','approved','active','suspended','completed','cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `sponsorship_benefits` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `content_requirements` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `target_audience` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `requires_content_approval` tinyint(1) NOT NULL DEFAULT '1',
  `allows_brand_mention` tinyint(1) NOT NULL DEFAULT '1',
  `requires_logo_display` tinyint(1) NOT NULL DEFAULT '1',
  `special_requirements` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `verification_documents` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `is_verified` tinyint(1) NOT NULL DEFAULT '0',
  `verified_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `corporate_sponsorships_affiliate_partner_id_foreign` (`affiliate_partner_id`),
  KEY `corporate_sponsorships_status_sponsorship_type_index` (`status`,`sponsorship_type`),
  KEY `corporate_sponsorships_company_type_index` (`company_type`),
  KEY `corporate_sponsorships_industry_index` (`industry`),
  CONSTRAINT `corporate_sponsorships_affiliate_partner_id_foreign` FOREIGN KEY (`affiliate_partner_id`) REFERENCES `affiliate_partners` (`id`) ON DELETE CASCADE,
  CONSTRAINT `corporate_sponsorships_chk_1` CHECK (json_valid(`sponsorship_benefits`)),
  CONSTRAINT `corporate_sponsorships_chk_2` CHECK (json_valid(`content_requirements`)),
  CONSTRAINT `corporate_sponsorships_chk_3` CHECK (json_valid(`target_audience`)),
  CONSTRAINT `corporate_sponsorships_chk_4` CHECK (json_valid(`verification_documents`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `corporate_sponsorships`
--

LOCK TABLES `corporate_sponsorships` WRITE;
/*!40000 ALTER TABLE `corporate_sponsorships` DISABLE KEYS */;
/*!40000 ALTER TABLE `corporate_sponsorships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupon_codes`
--

DROP TABLE IF EXISTS `coupon_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupon_codes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `type` enum('percentage','fixed_amount','free_trial') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'percentage',
  `discount_value` decimal(10,2) NOT NULL,
  `minimum_amount` decimal(10,2) DEFAULT NULL,
  `maximum_discount` decimal(10,2) DEFAULT NULL,
  `partner_type` enum('influencer','teacher','partner','promotional') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'promotional',
  `partner_id` bigint unsigned DEFAULT NULL,
  `created_by` bigint unsigned NOT NULL,
  `usage_limit` int DEFAULT NULL,
  `usage_count` int NOT NULL DEFAULT '0',
  `user_limit` int DEFAULT NULL,
  `starts_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `applicable_plans` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `coupon_codes_code_unique` (`code`),
  KEY `coupon_codes_partner_id_foreign` (`partner_id`),
  KEY `coupon_codes_created_by_foreign` (`created_by`),
  KEY `coupon_codes_code_is_active_index` (`code`,`is_active`),
  KEY `coupon_codes_partner_type_partner_id_index` (`partner_type`,`partner_id`),
  KEY `coupon_codes_starts_at_expires_at_index` (`starts_at`,`expires_at`),
  CONSTRAINT `coupon_codes_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `coupon_codes_partner_id_foreign` FOREIGN KEY (`partner_id`) REFERENCES `affiliate_partners` (`id`) ON DELETE SET NULL,
  CONSTRAINT `coupon_codes_chk_1` CHECK (json_valid(`applicable_plans`)),
  CONSTRAINT `coupon_codes_chk_2` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupon_codes`
--

LOCK TABLES `coupon_codes` WRITE;
/*!40000 ALTER TABLE `coupon_codes` DISABLE KEYS */;
INSERT INTO `coupon_codes` VALUES (1,'OSVEH','OSVEH',NULL,'percentage',50.00,NULL,NULL,'promotional',NULL,3,NULL,0,NULL,NULL,'2026-10-12 12:12:00',1,NULL,NULL,'2025-10-12 14:16:00','2025-10-12 14:16:00'),(3,'WELCOME','WELCOME',NULL,'percentage',0.00,NULL,NULL,'promotional',NULL,3,NULL,0,NULL,NULL,'2028-10-13 17:49:00',1,NULL,NULL,'2025-10-13 02:47:22','2025-10-13 02:47:22'),(4,'ABOLFAZLTESTING','ABOLFAZLTESTING',NULL,'fixed_amount',159000.00,NULL,NULL,'promotional',NULL,3,NULL,0,NULL,NULL,'2027-10-27 12:12:00',1,NULL,NULL,'2025-10-29 17:47:55','2025-10-29 17:47:55'),(5,'MYKET','MYKET',NULL,'percentage',100.00,NULL,NULL,'promotional',NULL,3,NULL,0,NULL,NULL,'2027-12-15 12:12:00',1,NULL,NULL,'2025-10-30 12:50:50','2025-10-30 12:50:50'),(6,'SARV40','Sarv40',NULL,'percentage',40.00,NULL,NULL,'promotional',NULL,3,NULL,0,NULL,NULL,'2027-09-12 11:02:00',1,NULL,NULL,'2025-12-18 12:32:51','2025-12-18 12:32:51');
/*!40000 ALTER TABLE `coupon_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupon_usages`
--

DROP TABLE IF EXISTS `coupon_usages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupon_usages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `coupon_code_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `subscription_id` bigint unsigned DEFAULT NULL,
  `original_amount` decimal(10,2) NOT NULL,
  `discount_amount` decimal(10,2) NOT NULL,
  `final_amount` decimal(10,2) NOT NULL,
  `commission_amount` decimal(10,2) DEFAULT NULL,
  `status` enum('pending','completed','cancelled','refunded') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `used_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `coupon_usages_subscription_id_foreign` (`subscription_id`),
  KEY `coupon_usages_coupon_code_id_user_id_index` (`coupon_code_id`,`user_id`),
  KEY `coupon_usages_user_id_used_at_index` (`user_id`,`used_at`),
  KEY `coupon_usages_status_used_at_index` (`status`,`used_at`),
  CONSTRAINT `coupon_usages_coupon_code_id_foreign` FOREIGN KEY (`coupon_code_id`) REFERENCES `coupon_codes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `coupon_usages_subscription_id_foreign` FOREIGN KEY (`subscription_id`) REFERENCES `subscriptions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `coupon_usages_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `coupon_usages_chk_1` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupon_usages`
--

LOCK TABLES `coupon_usages` WRITE;
/*!40000 ALTER TABLE `coupon_usages` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupon_usages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `database_query_logs`
--

DROP TABLE IF EXISTS `database_query_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `database_query_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `query` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `execution_time` decimal(8,3) NOT NULL,
  `rows_affected` int DEFAULT NULL,
  `connection_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bindings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `executed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `database_query_logs_execution_time_executed_at_index` (`execution_time`,`executed_at`),
  KEY `database_query_logs_executed_at_index` (`executed_at`),
  CONSTRAINT `database_query_logs_chk_1` CHECK (json_valid(`bindings`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `database_query_logs`
--

LOCK TABLES `database_query_logs` WRITE;
/*!40000 ALTER TABLE `database_query_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `database_query_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `episode_people`
--

DROP TABLE IF EXISTS `episode_people`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `episode_people` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `episode_id` bigint unsigned NOT NULL,
  `person_id` bigint unsigned NOT NULL,
  `role` enum('voice_actor','director','writer','producer') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `episode_people_episode_id_person_id_role_unique` (`episode_id`,`person_id`,`role`),
  KEY `episode_people_episode_id_index` (`episode_id`),
  KEY `episode_people_person_id_index` (`person_id`),
  CONSTRAINT `episode_people_episode_id_foreign` FOREIGN KEY (`episode_id`) REFERENCES `episodes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `episode_people_person_id_foreign` FOREIGN KEY (`person_id`) REFERENCES `people` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `episode_people`
--

LOCK TABLES `episode_people` WRITE;
/*!40000 ALTER TABLE `episode_people` DISABLE KEYS */;
INSERT INTO `episode_people` VALUES (1,9,2,'voice_actor','2025-12-18 13:10:29','2025-12-18 13:10:29');
/*!40000 ALTER TABLE `episode_people` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `episode_questions`
--

DROP TABLE IF EXISTS `episode_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `episode_questions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `episode_id` bigint unsigned NOT NULL,
  `question` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `option_a` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `option_b` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `option_c` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `option_d` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `correct_answer` enum('a','b','c','d') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `explanation` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `coins_reward` int NOT NULL DEFAULT '5',
  `difficulty_level` int NOT NULL DEFAULT '1',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `episode_questions_episode_id_is_active_index` (`episode_id`,`is_active`),
  KEY `episode_questions_difficulty_level_index` (`difficulty_level`),
  CONSTRAINT `episode_questions_episode_id_foreign` FOREIGN KEY (`episode_id`) REFERENCES `episodes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `episode_questions`
--

LOCK TABLES `episode_questions` WRITE;
/*!40000 ALTER TABLE `episode_questions` DISABLE KEYS */;
/*!40000 ALTER TABLE `episode_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `episode_voice_actors`
--

DROP TABLE IF EXISTS `episode_voice_actors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `episode_voice_actors` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `episode_id` bigint unsigned NOT NULL,
  `person_id` bigint unsigned NOT NULL,
  `role` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'narrator, character, etc.',
  `character_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Name of the character being voiced',
  `start_time` int unsigned NOT NULL COMMENT 'Start time in seconds',
  `end_time` int unsigned NOT NULL COMMENT 'End time in seconds',
  `voice_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'Description of voice characteristics',
  `is_primary` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Primary voice actor for the episode',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_episode_person_role_time` (`episode_id`,`person_id`,`role`,`start_time`),
  KEY `episode_voice_actors_episode_id_index` (`episode_id`),
  KEY `episode_voice_actors_person_id_index` (`person_id`),
  KEY `episode_voice_actors_start_time_end_time_index` (`start_time`,`end_time`),
  KEY `episode_voice_actors_role_index` (`role`),
  KEY `episode_voice_actors_is_primary_index` (`is_primary`),
  CONSTRAINT `episode_voice_actors_episode_id_foreign` FOREIGN KEY (`episode_id`) REFERENCES `episodes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `episode_voice_actors_person_id_foreign` FOREIGN KEY (`person_id`) REFERENCES `people` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `episode_voice_actors`
--

LOCK TABLES `episode_voice_actors` WRITE;
/*!40000 ALTER TABLE `episode_voice_actors` DISABLE KEYS */;
/*!40000 ALTER TABLE `episode_voice_actors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `episodes`
--

DROP TABLE IF EXISTS `episodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `episodes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `story_id` bigint unsigned NOT NULL,
  `narrator_id` bigint unsigned DEFAULT NULL,
  `title` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `audio_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `local_audio_path` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration` int NOT NULL,
  `episode_number` int NOT NULL,
  `is_premium` tinyint(1) NOT NULL DEFAULT '0',
  `image_urls` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `play_count` int NOT NULL DEFAULT '0',
  `total_plays` int NOT NULL DEFAULT '0',
  `total_favorites` int NOT NULL DEFAULT '0',
  `total_ratings` int NOT NULL DEFAULT '0',
  `avg_rating` decimal(3,2) NOT NULL DEFAULT '0.00',
  `total_duration_played` int NOT NULL DEFAULT '0',
  `unique_listeners` int NOT NULL DEFAULT '0',
  `completion_count` int NOT NULL DEFAULT '0',
  `completion_rate` decimal(5,2) NOT NULL DEFAULT '0.00',
  `share_count` int NOT NULL DEFAULT '0',
  `download_count` int NOT NULL DEFAULT '0',
  `last_played_at` timestamp NULL DEFAULT NULL,
  `trending_since` timestamp NULL DEFAULT NULL,
  `analytics_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `rating` decimal(3,2) NOT NULL DEFAULT '0.00',
  `tags` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `status` enum('draft','pending','approved','rejected','published') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `moderation_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `moderator_id` bigint unsigned DEFAULT NULL,
  `moderated_at` timestamp NULL DEFAULT NULL,
  `moderation_notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `moderation_rating` int DEFAULT NULL,
  `age_rating` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_warnings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `rejection_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rejection_suggestions` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `allow_resubmission` tinyint(1) NOT NULL DEFAULT '1',
  `moderation_priority` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'medium',
  `flag_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `moderation_history` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `published_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `has_multiple_voice_actors` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Whether episode has multiple voice actors',
  `voice_actor_count` int unsigned NOT NULL DEFAULT '0' COMMENT 'Total number of voice actors in episode',
  `use_image_timeline` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Whether episode uses timeline-based image changes',
  PRIMARY KEY (`id`),
  UNIQUE KEY `episodes_story_id_episode_number_unique` (`story_id`,`episode_number`),
  KEY `episodes_story_id_index` (`story_id`),
  KEY `episodes_episode_number_index` (`episode_number`),
  KEY `episodes_status_index` (`status`),
  KEY `episodes_is_premium_index` (`is_premium`),
  KEY `episodes_moderation_status_index` (`moderation_status`),
  KEY `episodes_moderator_id_index` (`moderator_id`),
  KEY `episodes_moderated_at_index` (`moderated_at`),
  KEY `episodes_moderation_priority_index` (`moderation_priority`),
  KEY `episodes_total_plays_index` (`total_plays`),
  KEY `episodes_total_favorites_index` (`total_favorites`),
  KEY `episodes_avg_rating_index` (`avg_rating`),
  KEY `episodes_unique_listeners_index` (`unique_listeners`),
  KEY `episodes_completion_rate_index` (`completion_rate`),
  KEY `episodes_last_played_at_index` (`last_played_at`),
  KEY `episodes_trending_since_index` (`trending_since`),
  KEY `episodes_narrator_id_index` (`narrator_id`),
  CONSTRAINT `episodes_moderator_id_foreign` FOREIGN KEY (`moderator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `episodes_narrator_id_foreign` FOREIGN KEY (`narrator_id`) REFERENCES `people` (`id`) ON DELETE SET NULL,
  CONSTRAINT `episodes_story_id_foreign` FOREIGN KEY (`story_id`) REFERENCES `stories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `episodes_chk_1` CHECK (json_valid(`image_urls`)),
  CONSTRAINT `episodes_chk_2` CHECK (json_valid(`analytics_data`)),
  CONSTRAINT `episodes_chk_3` CHECK (json_valid(`tags`)),
  CONSTRAINT `episodes_chk_4` CHECK (json_valid(`content_warnings`)),
  CONSTRAINT `episodes_chk_5` CHECK (json_valid(`moderation_history`))
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `episodes`
--

LOCK TABLES `episodes` WRITE;
/*!40000 ALTER TABLE `episodes` DISABLE KEYS */;
INSERT INTO `episodes` VALUES (2,3,6,'کل داستان پشمالو',NULL,'audio/episodes/audio_4MY5UD9s0g2Whdrx3QZNiCyzpqwvABFe-2025-10-06_16-47-11.mp3',NULL,409,1,0,NULL,31,0,0,0,0.00,0,0,0,0.00,0,0,NULL,NULL,NULL,0.00,NULL,'published','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'medium',NULL,NULL,NULL,'2025-10-06 16:47:11','2025-12-18 10:16:54',0,0,0),(3,7,8,'کل داستان مداد رنگی ها',NULL,'audio/episodes/audio_iH3J5SVoYdCyNP8OhfMsZRzGAuLw9Ipv-2025-10-06_16-51-34.mp3',NULL,429,1,0,NULL,29,0,0,0,0.00,0,0,0,0.00,0,0,NULL,NULL,NULL,0.00,NULL,'published','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'medium',NULL,NULL,NULL,'2025-10-06 16:51:34','2025-12-18 13:25:16',0,0,0),(4,4,5,'کل داستان گاوی',NULL,'audio/episodes/audio_xA58lhWbTQ9H1iFIKaB6vkVqCRDoecjd-2025-10-06_16-54-25.mp3',NULL,401,1,0,NULL,48,0,0,0,0.00,0,0,0,0.00,0,0,NULL,NULL,NULL,0.00,NULL,'published','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'medium',NULL,NULL,NULL,'2025-10-06 16:54:26','2025-12-18 13:32:37',0,0,0),(5,6,3,'کل داستان مورچه شجاع',NULL,'audio/episodes/audio_jIAFUnwL72WgsqitZ1Bm4uXGYOvKx3QJ-2025-10-06_17-00-38.mp3',NULL,505,1,0,NULL,20,0,0,0,0.00,0,0,0,0.00,0,0,NULL,NULL,NULL,0.00,NULL,'published','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'medium',NULL,NULL,NULL,'2025-10-06 17:00:39','2025-12-18 13:25:16',0,0,0),(6,5,4,'کل داستان هیولای غمگین',NULL,'audio/episodes/audio_16hN2mZX3G5JjoF7wDisHY8bPWnLxSAV-2025-10-06_17-02-09.mp3',NULL,502,1,1,NULL,28,0,0,0,0.00,0,0,0,0.00,0,0,NULL,NULL,NULL,0.00,NULL,'published','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'medium',NULL,NULL,NULL,'2025-10-06 17:02:10','2025-12-18 13:32:25',0,0,0),(9,10,5,'اژدهای نگهبان کتابخانه','سارای ده‌ساله، دختر کتاب‌دوست، در کتابخانه قدیمی شهر با اژدهای کوچکی به نام دراکو آشنا می‌شود که نگهبان جادویی کتاب‌هاست. با هم متوجه می‌شوند که «ملکه بی‌حوصله» کلمات و داستان‌ها را می‌دزدد، و مجبورند به چهار دنیای کتاب (جنگل شعرها، شهر ریاضی، دریاچه تاریخ و قصر آینده) سفر کنند تا خیال و قصه‌ها را نجات دهند. در پایان، حتی ملکه بی‌حوصله هم با خواندن کتاب و دوستی، قلبش نرم می‌شود و کتابخانه و دنیای تخیل نجات پیدا می‌کند.','audio/episodes/audio_OrD3ybUN2v9BVAQi7lwz8Jcmph5GWxTR-2025-12-18_13-10-28.mp3',NULL,432,1,1,NULL,0,0,0,0,0.00,0,0,0,0.00,0,0,NULL,NULL,NULL,0.00,NULL,'published','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'medium',NULL,NULL,NULL,'2025-12-18 13:10:29','2025-12-18 13:10:29',0,0,0);
/*!40000 ALTER TABLE `episodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `error_logs`
--

DROP TABLE IF EXISTS `error_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `error_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `level` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `stack_trace` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `file` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `line` int DEFAULT NULL,
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `context` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `resolved` tinyint(1) NOT NULL DEFAULT '0',
  `resolved_at` timestamp NULL DEFAULT NULL,
  `occurred_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `error_logs_level_occurred_at_index` (`level`,`occurred_at`),
  KEY `error_logs_type_occurred_at_index` (`type`,`occurred_at`),
  KEY `error_logs_resolved_occurred_at_index` (`resolved`,`occurred_at`),
  KEY `error_logs_occurred_at_index` (`occurred_at`),
  CONSTRAINT `error_logs_chk_1` CHECK (json_valid(`context`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `error_logs`
--

LOCK TABLES `error_logs` WRITE;
/*!40000 ALTER TABLE `error_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `error_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favorites`
--

DROP TABLE IF EXISTS `favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `favorites` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `story_id` bigint unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `favorites_user_id_story_id_unique` (`user_id`,`story_id`),
  KEY `favorites_story_id_foreign` (`story_id`),
  KEY `favorites_user_id_index` (`user_id`),
  CONSTRAINT `favorites_story_id_foreign` FOREIGN KEY (`story_id`) REFERENCES `stories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `favorites_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favorites`
--

LOCK TABLES `favorites` WRITE;
/*!40000 ALTER TABLE `favorites` DISABLE KEYS */;
INSERT INTO `favorites` VALUES (10,7,6,'2025-10-17 23:26:13'),(11,3,3,'2025-11-01 16:27:59'),(12,2,6,'2025-11-04 11:27:03'),(14,5,4,'2025-11-10 17:50:02'),(17,16,5,'2025-12-16 22:51:43');
/*!40000 ALTER TABLE `favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gamification_analytics`
--

DROP TABLE IF EXISTS `gamification_analytics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gamification_analytics` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `metric_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_id` bigint unsigned DEFAULT NULL,
  `metric_date` date NOT NULL,
  `metric_value` int NOT NULL DEFAULT '0',
  `metric_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `calculated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `gamification_analytics_unique` (`metric_type`,`target_type`,`target_id`,`metric_date`),
  KEY `gamification_analytics_metric_type_metric_date_index` (`metric_type`,`metric_date`),
  KEY `gamification_analytics_target_type_target_id_index` (`target_type`,`target_id`),
  KEY `gamification_analytics_metric_date_metric_value_index` (`metric_date`,`metric_value`),
  CONSTRAINT `gamification_analytics_chk_1` CHECK (json_valid(`metric_data`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gamification_analytics`
--

LOCK TABLES `gamification_analytics` WRITE;
/*!40000 ALTER TABLE `gamification_analytics` DISABLE KEYS */;
/*!40000 ALTER TABLE `gamification_analytics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gamification_settings`
--

DROP TABLE IF EXISTS `gamification_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gamification_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `setting_value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `setting_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'string',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `gamification_settings_setting_key_unique` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gamification_settings`
--

LOCK TABLES `gamification_settings` WRITE;
/*!40000 ALTER TABLE `gamification_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `gamification_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `image_timelines`
--

DROP TABLE IF EXISTS `image_timelines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `image_timelines` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `story_id` bigint unsigned NOT NULL,
  `episode_id` bigint unsigned NOT NULL,
  `start_time` int NOT NULL COMMENT 'Start time in seconds',
  `end_time` int NOT NULL COMMENT 'End time in seconds',
  `image_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Image URL for this time period',
  `scene_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'Description of the scene',
  `transition_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fade' COMMENT 'Transition type: fade, slide, cut, etc.',
  `is_key_frame` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Whether this is a key frame',
  `image_order` int NOT NULL COMMENT 'Order of image in timeline',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `voice_actor_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_episode_order` (`episode_id`,`image_order`),
  KEY `image_timelines_voice_actor_id_index` (`voice_actor_id`),
  KEY `image_timelines_story_id_foreign` (`story_id`),
  CONSTRAINT `image_timelines_episode_id_foreign` FOREIGN KEY (`episode_id`) REFERENCES `episodes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `image_timelines_story_id_foreign` FOREIGN KEY (`story_id`) REFERENCES `stories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `image_timelines_voice_actor_id_foreign` FOREIGN KEY (`voice_actor_id`) REFERENCES `episode_voice_actors` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=196 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `image_timelines`
--

LOCK TABLES `image_timelines` WRITE;
/*!40000 ALTER TABLE `image_timelines` DISABLE KEYS */;
INSERT INTO `image_timelines` VALUES (5,3,2,0,103,'images/episodes/timeline/timeline_Z5tDyI2BNAmiuw9HkacfXPjJoQWVqCMd-2025-10-06_17-45-18.webp','','fade',0,1,'2025-10-06 17:45:18','2025-10-06 17:45:18',NULL),(6,3,2,103,135,'images/episodes/timeline/timeline_tszalQPv93U1JiMGRYdAhZoIDurHfpTL-2025-10-06_17-45-18.webp','','fade',0,2,'2025-10-06 17:45:18','2025-10-06 17:45:18',NULL),(7,3,2,135,160,'images/episodes/timeline/timeline_neiFIZqgDsBkP4MStvATWxNJh29G3X6L-2025-10-06_17-45-18.webp','','fade',0,3,'2025-10-06 17:45:18','2025-10-06 17:45:18',NULL),(8,3,2,160,194,'images/episodes/timeline/timeline_NCi8EQe6LwlrqbdP9nSyo0vWD7Is1JVH-2025-10-06_17-45-18.webp','','fade',0,4,'2025-10-06 17:45:18','2025-10-06 17:45:18',NULL),(9,3,2,194,212,'images/episodes/timeline/timeline_PCunBW96aglGjeXKUSsZMTyRbh485F7N-2025-10-06_17-45-18.webp','','fade',0,5,'2025-10-06 17:45:18','2025-10-06 17:45:18',NULL),(10,3,2,212,232,'images/episodes/timeline/timeline_weR6oyfidI2qEMjHQp7TLvDYVlbuAJ1O-2025-10-06_17-45-18.webp','','fade',0,6,'2025-10-06 17:45:18','2025-10-06 17:45:18',NULL),(11,3,2,232,281,'images/episodes/timeline/timeline_rnjxoADpFXKPUisqIdauBC9WbhSGLk5m-2025-10-06_17-45-18.webp','','fade',0,7,'2025-10-06 17:45:18','2025-10-06 17:45:18',NULL),(12,3,2,281,301,'images/episodes/timeline/timeline_tBUlc4LYyM9xpiuqFV3JI80OvZDnhzeg-2025-10-06_17-45-18.webp','','fade',0,8,'2025-10-06 17:45:18','2025-10-06 17:45:18',NULL),(13,3,2,301,315,'images/episodes/timeline/timeline_oJGEVje1WpCUX9yRB0sarwi6h8YzKLON-2025-10-06_17-45-18.webp','','fade',0,9,'2025-10-06 17:45:18','2025-10-06 17:45:18',NULL),(14,3,2,315,326,'images/episodes/timeline/timeline_NbDSPocF0V23xaMKEneRB4jGgC9wOizX-2025-10-06_17-45-18.webp','','fade',0,10,'2025-10-06 17:45:18','2025-10-06 17:45:18',NULL),(15,3,2,326,338,'images/episodes/timeline/timeline_0w8HGZ72W19BniFgRbMqlVmIYPsecuQz-2025-10-06_17-45-18.webp','','fade',0,11,'2025-10-06 17:45:18','2025-10-06 17:45:18',NULL),(16,3,2,338,341,'images/episodes/timeline/timeline_Sp1RNznIxTZQaDViAoPKmr7qcsvtCJLO-2025-10-06_17-45-18.webp','','fade',0,12,'2025-10-06 17:45:18','2025-10-06 17:45:18',NULL),(17,3,2,341,354,'images/episodes/timeline/timeline_nRD4XyaTZ9W3FjEN6I7wdoJxKe18hpBr-2025-10-06_17-45-18.webp','','fade',0,13,'2025-10-06 17:45:18','2025-10-06 17:45:18',NULL),(18,3,2,354,409,'images/episodes/timeline/timeline_9PlgiVLpHXIshBS1wnfEu7yY8c5JUFRb-2025-10-06_17-45-18.webp','','fade',0,14,'2025-10-06 17:45:18','2025-10-06 17:45:18',NULL),(129,7,3,0,69,'images/episodes/timeline/timeline_kc9UyQRBv2FwjhH4egXdIibNWmoYxtPD-2025-10-11_09-28-45.webp','','fade',0,1,'2025-10-11 09:28:45','2025-10-11 09:28:45',NULL),(130,7,3,69,117,'images/episodes/timeline/timeline_cSGtbFj9nxoTwKkMe7v4356dRqpUQWVH-2025-10-11_09-28-45.webp','','fade',0,2,'2025-10-11 09:28:45','2025-10-11 09:28:45',NULL),(131,7,3,117,127,'images/episodes/timeline/timeline_DlZYf5H9VQ73gFpqzioJuahEOvrn8bsS-2025-10-11_09-28-45.webp','','fade',0,3,'2025-10-11 09:28:45','2025-10-11 09:28:45',NULL),(132,7,3,127,139,'images/episodes/timeline/timeline_bRVOBvsYpNmjdlL09Ef8MUFqxQona517-2025-10-11_09-28-45.webp','','fade',0,4,'2025-10-11 09:28:45','2025-10-11 09:28:45',NULL),(133,7,3,139,151,'images/episodes/timeline/timeline_ejAdyGfnaq6KgzZO7lEWcQ9t3BowHpUF-2025-10-11_09-28-45.webp','','fade',0,5,'2025-10-11 09:28:45','2025-10-11 09:28:45',NULL),(134,7,3,151,161,'images/episodes/timeline/timeline_NrLIRX1v8aGwbWCxmV9pHMJqY5FoShjB-2025-10-11_09-28-45.webp','','fade',0,6,'2025-10-11 09:28:45','2025-10-11 09:28:45',NULL),(135,7,3,161,188,'images/episodes/timeline/timeline_L5xEn2rAPjXTwDMmd7ivl4JHQC3U8sGW-2025-10-11_09-28-45.webp','','fade',0,7,'2025-10-11 09:28:45','2025-10-11 09:28:45',NULL),(136,7,3,188,198,'images/episodes/timeline/timeline_3qzxAKcYtjliJ7kUOQ6spLHC02VyfXW8-2025-10-11_09-28-45.webp','','fade',0,8,'2025-10-11 09:28:45','2025-10-11 09:28:45',NULL),(137,7,3,198,216,'images/episodes/timeline/timeline_kQsdfxX2PowV1HhlGcTu07pAENiIFj9a-2025-10-11_09-28-45.webp','','fade',0,9,'2025-10-11 09:28:45','2025-10-11 09:28:45',NULL),(138,7,3,216,222,'images/episodes/timeline/timeline_8KIYi3tcnb1AlGaSC5qy2HpzkRuUoFMN-2025-10-11_09-28-45.webp','','fade',0,10,'2025-10-11 09:28:45','2025-10-11 09:28:45',NULL),(139,7,3,222,231,'images/episodes/timeline/timeline_pTocV3qejaysbgKDAZYLBu51z6iPEWQI-2025-10-11_09-28-45.webp','','fade',0,11,'2025-10-11 09:28:45','2025-10-11 09:28:45',NULL),(140,7,3,231,238,'images/episodes/timeline/timeline_GT7AuvOFnzdIJ2DLx5QflCa168MgpNYR-2025-10-11_09-28-45.webp','','fade',0,12,'2025-10-11 09:28:45','2025-10-11 09:28:45',NULL),(141,7,3,238,242,'images/episodes/timeline/timeline_BFnyfGAKw0QodYpirs2Vzea6lEOvNcWX-2025-10-11_09-28-45.webp','','fade',0,13,'2025-10-11 09:28:45','2025-10-11 09:28:45',NULL),(142,7,3,242,249,'images/episodes/timeline/timeline_hYXgcu3ks1epiDHbaEFyKQG9ZltPJx7f-2025-10-11_09-28-45.webp','','fade',0,14,'2025-10-11 09:28:45','2025-10-11 09:28:45',NULL),(143,7,3,249,261,'images/episodes/timeline/timeline_hQw6RbzHa5CpgA8BsjDIiVoyuFxrvfYc-2025-10-11_09-28-45.webp','','fade',0,15,'2025-10-11 09:28:45','2025-10-11 09:28:45',NULL),(144,7,3,261,279,'images/episodes/timeline/timeline_E59iXT7pZauAYqKWBLgIbHmGMj6oJkwz-2025-10-11_09-28-45.webp','','fade',0,16,'2025-10-11 09:28:45','2025-10-11 09:28:45',NULL),(145,7,3,279,302,'images/episodes/timeline/timeline_tkRUrfZVE6Snd5yM2FeYBc1TipWuvsOh-2025-10-11_09-28-45.webp','','fade',0,17,'2025-10-11 09:28:45','2025-10-11 09:28:45',NULL),(146,7,3,302,323,'images/episodes/timeline/timeline_HJl3SiC1yRpnUe2qfrQgG0PMkFuBZ9c5-2025-10-11_09-28-45.webp','','fade',0,18,'2025-10-11 09:28:45','2025-10-11 09:28:45',NULL),(147,7,3,323,429,'images/episodes/timeline/timeline_9ijt3QmxPacpDUCf6X4ORndkY81eBq0r-2025-10-11_09-28-45.webp','','fade',0,19,'2025-10-11 09:28:45','2025-10-11 09:28:45',NULL),(148,4,4,4,83,'images/episodes/timeline/timeline_Hz8iYw7mder4LpoVy6REkNu1sBJWlUDt-2025-10-11_09-33-29.webp','','fade',0,1,'2025-10-11 09:33:29','2025-10-11 09:33:29',NULL),(149,4,4,83,119,'images/episodes/timeline/timeline_yIG6xo4iAQVEf0UZznDR1FteYT7bcjJB-2025-10-11_09-33-29.webp','','fade',0,2,'2025-10-11 09:33:29','2025-10-11 09:33:29',NULL),(150,4,4,119,138,'images/episodes/timeline/timeline_nuXYHtirgUz1oKEfqRTQWwBcG3JxeN5a-2025-10-11_09-33-29.webp','','fade',0,3,'2025-10-11 09:33:29','2025-10-11 09:33:29',NULL),(151,4,4,138,153,'images/episodes/timeline/timeline_BP4jSn18eT0QRGmNrI7OLW5H23plu9wF-2025-10-11_09-33-29.webp','','fade',0,4,'2025-10-11 09:33:29','2025-10-11 09:33:29',NULL),(152,4,4,153,184,'images/episodes/timeline/timeline_JoitIxDz29Lh3pTWGqZNygCdKPaSAlcj-2025-10-11_09-33-29.webp','','fade',0,5,'2025-10-11 09:33:29','2025-10-11 09:33:29',NULL),(153,4,4,184,214,'images/episodes/timeline/timeline_Ew0bh3oIO9PWn7aMrDuZN1m4g6TfpHjC-2025-10-11_09-33-29.webp','','fade',0,6,'2025-10-11 09:33:29','2025-10-11 09:33:29',NULL),(154,4,4,214,236,'images/episodes/timeline/timeline_YZnsBPtcxkEJiDTpQu8R7qA4C5Iv2jlf-2025-10-11_09-33-29.webp','','fade',0,7,'2025-10-11 09:33:29','2025-10-11 09:33:29',NULL),(155,4,4,236,271,'images/episodes/timeline/timeline_yA5M3z8nKu9miT427tWE1klejZ6owFGx-2025-10-11_09-33-29.webp','','fade',0,8,'2025-10-11 09:33:29','2025-10-11 09:33:29',NULL),(156,4,4,271,289,'images/episodes/timeline/timeline_B0GEJeWY6uLnVXizCRUcMolQZsg9fHbT-2025-10-11_09-33-29.webp','','fade',0,9,'2025-10-11 09:33:29','2025-10-11 09:33:29',NULL),(157,4,4,289,310,'images/episodes/timeline/timeline_NnYtmkVAuW2v6JzMySZxFUiapT3hgdcs-2025-10-11_09-33-29.webp','','fade',0,10,'2025-10-11 09:33:29','2025-10-11 09:33:29',NULL),(158,4,4,310,327,'images/episodes/timeline/timeline_kcrf4X1gQIxFNUYCZwJqWR7p02TdiKbj-2025-10-11_09-33-29.webp','','fade',0,11,'2025-10-11 09:33:29','2025-10-11 09:33:29',NULL),(159,4,4,327,338,'images/episodes/timeline/timeline_aOsItHBWRckg6XzorZyG97v5bSdqCEeM-2025-10-11_09-33-29.webp','','fade',0,12,'2025-10-11 09:33:29','2025-10-11 09:33:29',NULL),(160,4,4,338,347,'images/episodes/timeline/timeline_tFscgnwkUrXBxj4DNzC8ZiYvSEOyapoH-2025-10-11_09-33-29.webp','','fade',0,13,'2025-10-11 09:33:29','2025-10-11 09:33:29',NULL),(161,4,4,347,401,'images/episodes/timeline/timeline_MXbqJ529faCp6IxPjW3tYRouNszT7dEv-2025-10-11_09-33-29.webp','','fade',0,14,'2025-10-11 09:33:29','2025-10-11 09:33:29',NULL),(162,6,5,0,99,'images/episodes/timeline/timeline_8WQOj6fPq52tKzwI74evhlbsLVYZ1BcD-2025-10-11_09-43-21.webp','','fade',0,1,'2025-10-11 09:43:21','2025-10-11 09:43:21',NULL),(163,6,5,99,137,'images/episodes/timeline/timeline_21mus8TVbrwdhxLRBijC6qvGntaUDk5P-2025-10-11_09-43-21.webp','','fade',0,2,'2025-10-11 09:43:21','2025-10-11 09:43:21',NULL),(164,6,5,137,151,'images/episodes/timeline/timeline_mni5g6OQXtbIEf834x1LTA2qBwo9JWu7-2025-10-11_09-43-21.webp','','fade',0,3,'2025-10-11 09:43:21','2025-10-11 09:43:21',NULL),(165,6,5,151,170,'images/episodes/timeline/timeline_bcxM7Sen6oCNUR1fKOJrysVGjBZg3Fmw-2025-10-11_09-43-21.webp','','fade',0,4,'2025-10-11 09:43:21','2025-10-11 09:43:21',NULL),(166,6,5,170,187,'images/episodes/timeline/timeline_hkUfo3tNV6ip10ExHCYFLr9eb7qMZsJa-2025-10-11_09-43-21.webp','','fade',0,5,'2025-10-11 09:43:21','2025-10-11 09:43:21',NULL),(167,6,5,187,233,'images/episodes/timeline/timeline_GLzYH8u1mWkyNSi2stReFKTC6bEwAdBJ-2025-10-11_09-43-21.webp','','fade',0,6,'2025-10-11 09:43:21','2025-10-11 09:43:21',NULL),(168,6,5,233,248,'images/episodes/timeline/timeline_BIzhXH0KM6cGrLA74Vsjb9kPv3Roula1-2025-10-11_09-43-21.webp','','fade',0,7,'2025-10-11 09:43:21','2025-10-11 09:43:21',NULL),(169,6,5,248,265,'images/episodes/timeline/timeline_veaV0fzdBXkqDPZohiON8TbHtIU7A2CF-2025-10-11_09-43-21.webp','','fade',0,8,'2025-10-11 09:43:21','2025-10-11 09:43:21',NULL),(170,6,5,265,283,'images/episodes/timeline/timeline_lUdcTAeXWxosKy7SpHvJmFirGE5Pj39N-2025-10-11_09-43-21.webp','','fade',0,9,'2025-10-11 09:43:21','2025-10-11 09:43:21',NULL),(171,6,5,283,311,'images/episodes/timeline/timeline_JK9bjGMS81hdmNrxs3uXoe7REqvfkZLi-2025-10-11_09-43-21.webp','','fade',0,10,'2025-10-11 09:43:21','2025-10-11 09:43:21',NULL),(172,6,5,311,328,'images/episodes/timeline/timeline_V5fv7drPYzkJx2Cp6FctnhwjelX8Dsmq-2025-10-11_09-43-21.webp','','fade',0,11,'2025-10-11 09:43:21','2025-10-11 09:43:21',NULL),(173,6,5,328,341,'images/episodes/timeline/timeline_1UncYqTuOpkQob0Xga5Vwl4RfySAvLHd-2025-10-11_09-43-21.webp','','fade',0,12,'2025-10-11 09:43:21','2025-10-11 09:43:21',NULL),(174,6,5,341,360,'images/episodes/timeline/timeline_TZvpGcS0WY84UIOForxiJ9yRjC7LbEwK-2025-10-11_09-43-21.webp','','fade',0,13,'2025-10-11 09:43:21','2025-10-11 09:43:21',NULL),(175,6,5,360,371,'images/episodes/timeline/timeline_EerGtl3z1QLMCaJvsxof8jPO4p27qUig-2025-10-11_09-43-21.webp','','fade',0,14,'2025-10-11 09:43:21','2025-10-11 09:43:21',NULL),(176,6,5,371,386,'images/episodes/timeline/timeline_Mn7Rz6wGACTtaWN1cepUiZqPrgmHvJ0X-2025-10-11_09-43-21.webp','','fade',0,15,'2025-10-11 09:43:21','2025-10-11 09:43:21',NULL),(177,6,5,386,410,'images/episodes/timeline/timeline_g15hfVLDnpBeG0XsWiQj6b89dFazZ7tq-2025-10-11_09-43-21.webp','','fade',0,16,'2025-10-11 09:43:21','2025-10-11 09:43:21',NULL),(178,6,5,410,505,'images/episodes/timeline/timeline_cb71fSx2aGDrunsk3gQCAyw4EdRWe0zv-2025-10-11_09-43-21.webp','','fade',0,17,'2025-10-11 09:43:21','2025-10-11 09:43:21',NULL),(179,5,6,0,108,'images/episodes/timeline/timeline_9OSHJ0nm1XbC2RhoVu5KWa8UeAqMwTtk-2025-10-12_10-07-11.webp','','fade',0,1,'2025-10-12 10:07:11','2025-10-12 10:07:11',NULL),(180,5,6,108,118,'images/episodes/timeline/timeline_3zVsy2nQwZr9mgbuEaxqF1oXCAkDhI4R-2025-10-12_10-07-11.webp','','fade',0,2,'2025-10-12 10:07:11','2025-10-12 10:07:11',NULL),(181,5,6,118,138,'images/episodes/timeline/timeline_cQqLrbUvJBIHOluE12zDxGdiPfmoZK8s-2025-10-12_10-07-11.webp','','fade',0,3,'2025-10-12 10:07:11','2025-10-12 10:07:11',NULL),(182,5,6,138,155,'images/episodes/timeline/timeline_grwDltiM8b4vHWXYoj25musJ3LS916CK-2025-10-12_10-07-11.webp','','fade',0,4,'2025-10-12 10:07:11','2025-10-12 10:07:11',NULL),(183,5,6,155,181,'images/episodes/timeline/timeline_c4fuD5OBsCPpt3ikWjl1TMvZYrhyUHx9-2025-10-12_10-07-11.webp','','fade',0,5,'2025-10-12 10:07:11','2025-10-12 10:07:11',NULL),(184,5,6,181,195,'images/episodes/timeline/timeline_OQu8lP2BU63MyJ1TNpZ9civKHsREbCFA-2025-10-12_10-07-11.webp','','fade',0,6,'2025-10-12 10:07:11','2025-10-12 10:07:11',NULL),(185,5,6,195,237,'images/episodes/timeline/timeline_OIR5EmzVsxiL3reDAwgjolt69Q1vh42B-2025-10-12_10-07-11.webp','','fade',0,7,'2025-10-12 10:07:11','2025-10-12 10:07:11',NULL),(186,5,6,237,246,'images/episodes/timeline/timeline_5HgZvy3VmpYQXKeRFi7t1EshlnGDMBOa-2025-10-12_10-07-11.webp','','fade',0,8,'2025-10-12 10:07:11','2025-10-12 10:07:11',NULL),(187,5,6,246,268,'images/episodes/timeline/timeline_FG0wA2ecnIjQEsBdPCqht8uYylaZKzR5-2025-10-12_10-07-11.webp','','fade',0,9,'2025-10-12 10:07:11','2025-10-12 10:07:11',NULL),(188,5,6,268,311,'images/episodes/timeline/timeline_0SAP3yEWHw52tDgpbZB6Oos9RrGKnhYv-2025-10-12_10-07-11.webp','','fade',0,10,'2025-10-12 10:07:11','2025-10-12 10:07:11',NULL),(189,5,6,311,329,'images/episodes/timeline/timeline_9ZQarAsFEDUpefxWG1qS3BgnVJvTjLM2-2025-10-12_10-07-11.webp','','fade',0,11,'2025-10-12 10:07:11','2025-10-12 10:07:11',NULL),(190,5,6,329,357,'images/episodes/timeline/timeline_uji9N1bxS8nH20Vtkc4rIdfo3BTesvDC-2025-10-12_10-07-11.webp','','fade',0,12,'2025-10-12 10:07:11','2025-10-12 10:07:11',NULL),(191,5,6,357,378,'images/episodes/timeline/timeline_ET4Ac0wpKlIVNP2rtzD7kqgJGexCYO36-2025-10-12_10-07-11.webp','','fade',0,13,'2025-10-12 10:07:11','2025-10-12 10:07:11',NULL),(192,5,6,378,395,'images/episodes/timeline/timeline_6Tg8wsLN3bPqEUCBOiW1VArDdFKH4Mjn-2025-10-12_10-07-11.webp','','fade',0,14,'2025-10-12 10:07:11','2025-10-12 10:07:11',NULL),(193,5,6,395,416,'images/episodes/timeline/timeline_zJROAusBvpfU4Wqe1NPS2Hdw9yMnlIx6-2025-10-12_10-07-11.webp','','fade',0,15,'2025-10-12 10:07:11','2025-10-12 10:07:11',NULL),(194,5,6,416,433,'images/episodes/timeline/timeline_UDy4PXwnj2KIbpZmd7h9Osf5RuiTBQYq-2025-10-12_10-07-11.webp','','fade',0,16,'2025-10-12 10:07:11','2025-10-12 10:07:11',NULL),(195,5,6,433,502,'images/episodes/timeline/timeline_Jb6LaEci5Wgp0HOfzoSFIhMUk782ARjv-2025-10-12_10-07-11.webp','','fade',0,17,'2025-10-12 10:07:11','2025-10-12 10:07:11',NULL);
/*!40000 ALTER TABLE `image_timelines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `influencer_campaigns`
--

DROP TABLE IF EXISTS `influencer_campaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `influencer_campaigns` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `affiliate_partner_id` bigint unsigned NOT NULL,
  `campaign_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaign_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaign_type` enum('story_review','educational_content','cultural_preservation','brand_partnership') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_type` enum('post','story','reel','video','live') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `required_posts` int NOT NULL DEFAULT '1',
  `required_stories` int NOT NULL DEFAULT '0',
  `compensation_per_post` decimal(10,2) NOT NULL,
  `commission_rate` decimal(5,2) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` enum('draft','active','paused','completed','cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `content_guidelines` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `hashtags` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `target_audience` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `requires_approval` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `influencer_campaigns_affiliate_partner_id_foreign` (`affiliate_partner_id`),
  KEY `influencer_campaigns_status_start_date_end_date_index` (`status`,`start_date`,`end_date`),
  KEY `influencer_campaigns_campaign_type_index` (`campaign_type`),
  CONSTRAINT `influencer_campaigns_affiliate_partner_id_foreign` FOREIGN KEY (`affiliate_partner_id`) REFERENCES `affiliate_partners` (`id`) ON DELETE CASCADE,
  CONSTRAINT `influencer_campaigns_chk_1` CHECK (json_valid(`content_guidelines`)),
  CONSTRAINT `influencer_campaigns_chk_2` CHECK (json_valid(`hashtags`)),
  CONSTRAINT `influencer_campaigns_chk_3` CHECK (json_valid(`target_audience`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `influencer_campaigns`
--

LOCK TABLES `influencer_campaigns` WRITE;
/*!40000 ALTER TABLE `influencer_campaigns` DISABLE KEYS */;
/*!40000 ALTER TABLE `influencer_campaigns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `influencer_content`
--

DROP TABLE IF EXISTS `influencer_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `influencer_content` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `campaign_id` bigint unsigned NOT NULL,
  `affiliate_partner_id` bigint unsigned NOT NULL,
  `content_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `platform` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `media_urls` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `hashtags` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `views` int NOT NULL DEFAULT '0',
  `likes` int NOT NULL DEFAULT '0',
  `comments` int NOT NULL DEFAULT '0',
  `shares` int NOT NULL DEFAULT '0',
  `clicks` int NOT NULL DEFAULT '0',
  `conversions` int NOT NULL DEFAULT '0',
  `engagement_rate` decimal(5,2) NOT NULL DEFAULT '0.00',
  `status` enum('pending','approved','rejected','published') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `rejection_reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `published_at` timestamp NULL DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `influencer_content_campaign_id_status_index` (`campaign_id`,`status`),
  KEY `influencer_content_affiliate_partner_id_published_at_index` (`affiliate_partner_id`,`published_at`),
  CONSTRAINT `influencer_content_affiliate_partner_id_foreign` FOREIGN KEY (`affiliate_partner_id`) REFERENCES `affiliate_partners` (`id`) ON DELETE CASCADE,
  CONSTRAINT `influencer_content_campaign_id_foreign` FOREIGN KEY (`campaign_id`) REFERENCES `influencer_campaigns` (`id`) ON DELETE CASCADE,
  CONSTRAINT `influencer_content_chk_1` CHECK (json_valid(`media_urls`)),
  CONSTRAINT `influencer_content_chk_2` CHECK (json_valid(`hashtags`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `influencer_content`
--

LOCK TABLES `influencer_content` WRITE;
/*!40000 ALTER TABLE `influencer_content` DISABLE KEYS */;
/*!40000 ALTER TABLE `influencer_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
INSERT INTO `jobs` VALUES (1,'default','{\"uuid\":\"14e9f465-b018-4ecb-a942-687b50a14e0b\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:1;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1759694244,\"delay\":null}',0,NULL,1759694244,1759694244),(2,'default','{\"uuid\":\"0b030c39-0e49-4b35-a763-606e7493a2ac\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:1;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1759694244,\"delay\":null}',0,NULL,1759694244,1759694244),(3,'default','{\"uuid\":\"0f102d0c-266c-4956-a9eb-5407f5ef2f8b\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:2;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1759694244,\"delay\":null}',0,NULL,1759694244,1759694244),(4,'default','{\"uuid\":\"f4146092-40ee-4644-b561-e7b8c3657c33\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:2;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1759694244,\"delay\":null}',0,NULL,1759694244,1759694244),(5,'default','{\"uuid\":\"00d7d3b4-6a95-4351-b3b4-c87fea52d30d\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:3;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1759694244,\"delay\":null}',0,NULL,1759694244,1759694244),(6,'default','{\"uuid\":\"ba4c4e5f-83cd-490b-bcf7-7212768639ac\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:3;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1759694244,\"delay\":null}',0,NULL,1759694244,1759694244),(7,'default','{\"uuid\":\"9d43cd14-2971-4d5c-b009-98150ff31554\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:4;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1759694244,\"delay\":null}',0,NULL,1759694244,1759694244),(8,'default','{\"uuid\":\"94c6709c-c9a8-40f7-8618-8943dfad4796\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:4;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1759694244,\"delay\":null}',0,NULL,1759694244,1759694244),(9,'default','{\"uuid\":\"78cf931a-9c87-4295-8116-249ea8726f25\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:5;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1759694244,\"delay\":null}',0,NULL,1759694244,1759694244),(10,'default','{\"uuid\":\"25c413b0-be78-40db-a2b2-25b12980d901\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:5;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1759694244,\"delay\":null}',0,NULL,1759694244,1759694244),(11,'default','{\"uuid\":\"28c9abb5-33a7-4faa-9fe4-41d088eec6ed\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:6;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1759757567,\"delay\":null}',0,NULL,1759757567,1759757567),(12,'default','{\"uuid\":\"b4f7a704-a943-4a6d-8c4c-79f717715dab\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:6;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1759757567,\"delay\":null}',0,NULL,1759757567,1759757567),(13,'default','{\"uuid\":\"c905e3b1-26ec-4aee-90c4-9ea7aa45d727\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:7;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1760310368,\"delay\":null}',0,NULL,1760310368,1760310368),(14,'default','{\"uuid\":\"ac68f605-e49c-42f5-882c-d29e1c6febb8\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:7;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1760310368,\"delay\":null}',0,NULL,1760310368,1760310368),(15,'default','{\"uuid\":\"60335d8a-beae-4104-b0ab-ac6a104de8fe\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:8;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1760770832,\"delay\":null}',0,NULL,1760770832,1760770832),(16,'default','{\"uuid\":\"1c703e48-4c7d-40d9-bb2a-7db85cb70598\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:8;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1760770832,\"delay\":null}',0,NULL,1760770832,1760770832),(17,'default','{\"uuid\":\"9101097d-c2c4-463f-a456-fbfcf84042a6\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:9;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1760772006,\"delay\":null}',0,NULL,1760772006,1760772006),(18,'default','{\"uuid\":\"c23d1008-ad45-45ef-a074-3b77af7beb5f\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:9;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1760772006,\"delay\":null}',0,NULL,1760772006,1760772006),(19,'default','{\"uuid\":\"e0426305-b432-473a-b7cb-e854865502a9\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:10;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1761746156,\"delay\":null}',0,NULL,1761746156,1761746156),(20,'default','{\"uuid\":\"bc79a247-f291-4c8b-8de6-b7623bd46cd6\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:10;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1761746156,\"delay\":null}',0,NULL,1761746156,1761746156),(21,'default','{\"uuid\":\"5a1ccb5c-c185-4fef-9a38-2dbff3479f4f\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:11;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1761858845,\"delay\":null}',0,NULL,1761858845,1761858845),(22,'default','{\"uuid\":\"85b502a5-816e-4b03-9f93-92ddcd167d02\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:11;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1761858845,\"delay\":null}',0,NULL,1761858845,1761858845),(23,'default','{\"uuid\":\"82a32468-46a3-48d3-8833-cae455572a1f\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:12;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1762084093,\"delay\":null}',0,NULL,1762084093,1762084093),(24,'default','{\"uuid\":\"6e52e545-9792-46ee-b14e-8ba8e783187d\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:12;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1762084093,\"delay\":null}',0,NULL,1762084093,1762084093),(25,'default','{\"uuid\":\"3c59147a-3927-49d3-bcc8-2bfc8980e422\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:13;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1762187922,\"delay\":null}',0,NULL,1762187922,1762187922),(26,'default','{\"uuid\":\"8980e303-f0d6-4b4b-b502-9a5709333bf0\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:13;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1762187922,\"delay\":null}',0,NULL,1762187922,1762187922),(27,'default','{\"uuid\":\"1ea32cef-5df3-4ead-b792-70c196f47fb3\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:14;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1763314429,\"delay\":null}',0,NULL,1763314429,1763314429),(28,'default','{\"uuid\":\"78e0e325-e267-4b63-83cc-79096dedfcb1\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:14;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1763314429,\"delay\":null}',0,NULL,1763314429,1763314429),(29,'default','{\"uuid\":\"cebeb7f1-02c6-499f-9f01-5d13259afcb6\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:15;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1763393704,\"delay\":null}',0,NULL,1763393704,1763393704),(30,'default','{\"uuid\":\"ebbed880-6ed1-4095-8e7d-17ccbd5ce831\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:15;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1763393704,\"delay\":null}',0,NULL,1763393704,1763393704),(31,'default','{\"uuid\":\"ad000f4b-2364-4636-844a-5e36ad44e927\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:16;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1765912745,\"delay\":null}',0,NULL,1765912745,1765912745),(32,'default','{\"uuid\":\"c251c52f-6baf-470c-8f19-322550f0bd65\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:16;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1765912745,\"delay\":null}',0,NULL,1765912745,1765912745),(33,'default','{\"uuid\":\"d8bd54bb-63fe-4092-8f0c-a68018c9db5f\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:17;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1766002794,\"delay\":null}',0,NULL,1766002794,1766002794),(34,'default','{\"uuid\":\"df3d8a42-948e-41a3-abe7-7da8366ae566\",\"displayName\":\"App\\\\Listeners\\\\SendTelegramNewUserNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Events\\\\CallQueuedListener\",\"command\":\"O:36:\\\"Illuminate\\\\Events\\\\CallQueuedListener\\\":21:{s:5:\\\"class\\\";s:45:\\\"App\\\\Listeners\\\\SendTelegramNewUserNotification\\\";s:6:\\\"method\\\";s:6:\\\"handle\\\";s:4:\\\"data\\\";a:1:{i:0;O:35:\\\"App\\\\Events\\\\NewUserRegistrationEvent\\\":1:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:17;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}}}s:5:\\\"tries\\\";N;s:13:\\\"maxExceptions\\\";N;s:7:\\\"backoff\\\";N;s:10:\\\"retryUntil\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"failOnTimeout\\\";b:0;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\"},\"createdAt\":1766002794,\"delay\":null}',0,NULL,1766002794,1766002794);
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leaderboard_entries`
--

DROP TABLE IF EXISTS `leaderboard_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leaderboard_entries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `leaderboard_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `rank` int NOT NULL,
  `score` decimal(15,2) NOT NULL,
  `score_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `period_date` date NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `leaderboard_entries_leaderboard_id_user_id_period_date_unique` (`leaderboard_id`,`user_id`,`period_date`),
  KEY `leaderboard_entries_leaderboard_id_rank_period_date_index` (`leaderboard_id`,`rank`,`period_date`),
  KEY `leaderboard_entries_user_id_period_date_index` (`user_id`,`period_date`),
  KEY `leaderboard_entries_score_period_date_index` (`score`,`period_date`),
  CONSTRAINT `leaderboard_entries_leaderboard_id_foreign` FOREIGN KEY (`leaderboard_id`) REFERENCES `leaderboards` (`id`) ON DELETE CASCADE,
  CONSTRAINT `leaderboard_entries_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `leaderboard_entries_chk_1` CHECK (json_valid(`score_data`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leaderboard_entries`
--

LOCK TABLES `leaderboard_entries` WRITE;
/*!40000 ALTER TABLE `leaderboard_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `leaderboard_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leaderboards`
--

DROP TABLE IF EXISTS `leaderboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leaderboards` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `period` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `scope` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `criteria` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `max_entries` int NOT NULL DEFAULT '100',
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `leaderboards_slug_unique` (`slug`),
  KEY `leaderboards_type_period_is_active_index` (`type`,`period`,`is_active`),
  KEY `leaderboards_scope_is_active_index` (`scope`,`is_active`),
  CONSTRAINT `leaderboards_chk_1` CHECK (json_valid(`criteria`)),
  CONSTRAINT `leaderboards_chk_2` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leaderboards`
--

LOCK TABLES `leaderboards` WRITE;
/*!40000 ALTER TABLE `leaderboards` DISABLE KEYS */;
/*!40000 ALTER TABLE `leaderboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000001_create_cache_table',1),(2,'0001_01_01_000002_create_jobs_table',1),(3,'2025_09_14_184737_create_users_table',1),(4,'2025_09_14_184738_create_categories_table',1),(5,'2025_09_14_184738_create_user_profiles_table',1),(6,'2025_09_14_184739_create_people_table',1),(7,'2025_09_14_184739_create_stories_table',1),(8,'2025_09_14_184741_create_episodes_table',1),(9,'2025_09_14_184742_create_subscriptions_table',1),(10,'2025_09_14_184743_create_payments_table',1),(11,'2025_09_14_184743_create_play_histories_table',1),(12,'2025_09_14_184744_create_favorites_table',1),(13,'2025_09_14_184746_create_ratings_table',1),(14,'2025_09_14_184747_create_episode_people_table',1),(15,'2025_09_14_184747_create_story_people_table',1),(16,'2025_09_14_184750_create_episode_voice_actors_table',1),(17,'2025_09_14_184751_update_episodes_table_for_voice_actors',1),(18,'2025_09_14_184800_create_user_coins_table',1),(19,'2025_09_14_184801_create_coin_transactions_table',1),(20,'2025_09_14_184802_create_episode_questions_table',1),(21,'2025_09_14_184803_create_user_quiz_attempts_table',1),(22,'2025_09_14_184804_create_referral_codes_table',1),(23,'2025_09_14_184805_create_referrals_table',1),(24,'2025_09_14_184806_create_affiliate_partners_table',1),(25,'2025_09_14_184807_create_commissions_table',1),(26,'2025_09_14_184808_create_teacher_accounts_table',1),(27,'2025_09_14_184809_create_student_licenses_table',1),(28,'2025_09_14_184810_create_influencer_campaigns_table',1),(29,'2025_09_14_184811_create_influencer_content_table',1),(30,'2025_09_14_184812_create_school_partnerships_table',1),(31,'2025_09_14_184813_create_school_licenses_table',1),(32,'2025_09_14_184814_create_corporate_sponsorships_table',1),(33,'2025_09_14_184815_create_sponsored_content_table',1),(34,'2025_09_14_184816_create_sponsorship_analytics_table',1),(35,'2025_09_14_184817_create_coupon_codes_table',1),(36,'2025_09_14_184818_create_coupon_usages_table',1),(37,'2025_09_14_184819_create_commission_payments_table',1),(38,'2025_09_14_190135_create_personal_access_tokens_table',1),(39,'2025_09_15_202113_create_sms_logs_table',1),(40,'2025_09_15_202246_create_notifications_table',1),(41,'2025_09_15_204358_create_reports_table',1),(42,'2025_09_15_204534_add_moderation_fields_to_stories_table',1),(43,'2025_09_15_204559_add_moderation_fields_to_episodes_table',1),(44,'2025_09_15_205021_add_analytics_fields_to_users_table',1),(45,'2025_09_15_205657_add_analytics_fields_to_content_tables',1),(46,'2025_09_15_210921_add_revenue_analytics_fields_to_payments_subscriptions',1),(47,'2025_09_15_212534_create_system_monitoring_tables',1),(48,'2025_09_15_213551_create_recommendation_tracking_tables',1),(49,'2025_09_15_220748_create_social_features_tables',1),(50,'2025_09_15_223244_create_gamification_tables',1),(51,'2025_09_15_234038_create_image_timelines_table',1),(52,'2025_09_15_234039_update_image_timelines_table_for_voice_actors',1),(53,'2025_09_15_234833_create_story_comments_table',1),(54,'2025_09_16_000325_add_use_image_timeline_to_episodes_table',1),(55,'2025_09_16_051635_create_performance_metrics_table',1),(56,'2025_09_16_065635_create_sessions_table',1),(57,'2025_09_16_072256_add_password_to_users_table',1),(58,'2025_09_16_135633_add_updated_at_to_story_people_table',1),(59,'2025_09_16_135637_add_updated_at_to_episode_people_table',1),(60,'2025_09_19_125746_create_roles_table',1),(61,'2025_09_19_125748_create_permissions_table',1),(62,'2025_09_19_125751_create_role_permission_table',1),(63,'2025_09_19_125753_create_user_role_table',1),(64,'2025_09_19_184305_create_user_permissions_table',1),(65,'2025_09_19_185108_create_subscription_plans_table',1),(66,'2025_09_19_190037_update_subscription_plans_currency_to_irt',1),(67,'2025_09_19_190231_create_otp_attempts_table',1),(68,'2025_09_19_190809_add_requires_2fa_to_users_table',1),(69,'2025_09_20_084413_create_backups_table',1),(70,'2025_09_20_091208_create_app_versions_table',1),(71,'2025_09_20_092506_add_commission_fields_to_teacher_accounts_table',1),(72,'2025_09_20_092519_add_teacher_assignment_to_school_partnerships_table',1),(73,'2025_09_20_100851_add_narrator_id_to_episodes_table',1),(74,'2025_09_20_101604_add_comment_features_to_story_comments_table',1),(75,'2025_09_20_101621_create_story_comment_likes_table',1),(76,'2025_09_20_150124_enable_2fa_for_admin_users',1),(77,'2025_09_20_152306_add_basic_role_to_users_table',1),(78,'2025_09_20_152525_make_email_nullable_in_users_table',1),(79,'2025_09_21_035030_remove_email_from_users_table',1),(80,'2025_09_26_123600_fix_stories_duration_field',1),(81,'2025_09_26_172216_add_slug_to_categories_table',1),(82,'2025_09_26_185932_create_story_ratings_table',1),(83,'2025_09_27_102926_add_effective_and_expiry_dates_to_app_versions_table',1),(84,'2025_10_06_004710_change_image_timelines_to_story_relationship',2),(85,'2025_01_15_000000_optimize_play_histories_indexes',3),(86,'2025_01_20_000001_add_billing_platform_support',4),(87,'2025_12_07_163822_create_myket_plans_table',4),(88,'2025_12_07_163830_create_myket_subscriptions_table',4),(89,'2025_12_07_163832_create_myket_user_subscriptions_table',4),(90,'2025_12_11_095335_add_flavor_support_to_subscription_plans_table',4),(91,'2025_12_11_125230_add_flavor_links_to_app_versions_table',5);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `myket_plans`
--

DROP TABLE IF EXISTS `myket_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `myket_plans` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `duration_days` int NOT NULL,
  `features` json DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `myket_plans_is_active_index` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `myket_plans`
--

LOCK TABLES `myket_plans` WRITE;
/*!40000 ALTER TABLE `myket_plans` DISABLE KEYS */;
/*!40000 ALTER TABLE `myket_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `myket_subscriptions`
--

DROP TABLE IF EXISTS `myket_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `myket_subscriptions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `plan_id` bigint unsigned NOT NULL,
  `status` enum('active','expired','cancelled','pending','trial') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `start_date` timestamp NULL DEFAULT NULL,
  `end_date` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `myket_subscriptions_user_id_index` (`user_id`),
  KEY `myket_subscriptions_plan_id_index` (`plan_id`),
  KEY `myket_subscriptions_status_index` (`status`),
  KEY `myket_subscriptions_end_date_index` (`end_date`),
  CONSTRAINT `myket_subscriptions_plan_id_foreign` FOREIGN KEY (`plan_id`) REFERENCES `myket_plans` (`id`) ON DELETE CASCADE,
  CONSTRAINT `myket_subscriptions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `myket_subscriptions`
--

LOCK TABLES `myket_subscriptions` WRITE;
/*!40000 ALTER TABLE `myket_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `myket_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `myket_user_subscriptions`
--

DROP TABLE IF EXISTS `myket_user_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `myket_user_subscriptions` (
  `user_id` bigint unsigned NOT NULL,
  `subscription_id` bigint unsigned NOT NULL,
  `status` enum('active','expired','cancelled','pending','trial') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`,`subscription_id`),
  KEY `myket_user_subscriptions_user_id_index` (`user_id`),
  KEY `myket_user_subscriptions_subscription_id_index` (`subscription_id`),
  KEY `myket_user_subscriptions_status_index` (`status`),
  CONSTRAINT `myket_user_subscriptions_subscription_id_foreign` FOREIGN KEY (`subscription_id`) REFERENCES `myket_subscriptions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `myket_user_subscriptions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `myket_user_subscriptions`
--

LOCK TABLES `myket_user_subscriptions` WRITE;
/*!40000 ALTER TABLE `myket_user_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `myket_user_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `action_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action_text` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `is_important` tinyint(1) NOT NULL DEFAULT '0',
  `read_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `priority` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal',
  `category` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_user_id_index` (`user_id`),
  KEY `notifications_type_index` (`type`),
  KEY `notifications_is_read_index` (`is_read`),
  KEY `notifications_is_important_index` (`is_important`),
  KEY `notifications_priority_index` (`priority`),
  KEY `notifications_category_index` (`category`),
  KEY `notifications_expires_at_index` (`expires_at`),
  KEY `notifications_created_at_index` (`created_at`),
  CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `notifications_chk_1` CHECK (json_valid(`data`)),
  CONSTRAINT `notifications_chk_2` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (1,1,'content','قسمت جدید منتشر شد','قسمت جدید \"کل داستان پشمالو\" از داستان \"پشمالو\" منتشر شد.','{\"story_title\":\"\\u067e\\u0634\\u0645\\u0627\\u0644\\u0648\",\"episode_title\":\"\\u06a9\\u0644 \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u067e\\u0634\\u0645\\u0627\\u0644\\u0648\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-05 20:26:00','2025-10-05 20:26:00'),(2,2,'content','قسمت جدید منتشر شد','قسمت جدید \"کل داستان پشمالو\" از داستان \"پشمالو\" منتشر شد.','{\"story_title\":\"\\u067e\\u0634\\u0645\\u0627\\u0644\\u0648\",\"episode_title\":\"\\u06a9\\u0644 \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u067e\\u0634\\u0645\\u0627\\u0644\\u0648\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-05 20:26:00','2025-10-05 20:26:00'),(3,3,'content','قسمت جدید منتشر شد','قسمت جدید \"کل داستان پشمالو\" از داستان \"پشمالو\" منتشر شد.','{\"story_title\":\"\\u067e\\u0634\\u0645\\u0627\\u0644\\u0648\",\"episode_title\":\"\\u06a9\\u0644 \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u067e\\u0634\\u0645\\u0627\\u0644\\u0648\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-05 20:26:00','2025-10-05 20:26:00'),(4,4,'content','قسمت جدید منتشر شد','قسمت جدید \"کل داستان پشمالو\" از داستان \"پشمالو\" منتشر شد.','{\"story_title\":\"\\u067e\\u0634\\u0645\\u0627\\u0644\\u0648\",\"episode_title\":\"\\u06a9\\u0644 \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u067e\\u0634\\u0645\\u0627\\u0644\\u0648\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-05 20:26:00','2025-10-05 20:26:00'),(5,5,'content','قسمت جدید منتشر شد','قسمت جدید \"کل داستان پشمالو\" از داستان \"پشمالو\" منتشر شد.','{\"story_title\":\"\\u067e\\u0634\\u0645\\u0627\\u0644\\u0648\",\"episode_title\":\"\\u06a9\\u0644 \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u067e\\u0634\\u0645\\u0627\\u0644\\u0648\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-05 20:26:00','2025-10-05 20:26:00'),(6,1,'content','قسمت جدید منتشر شد','قسمت جدید \"کل داستان پشمالو\" از داستان \"پشمالو شیر کوچولو\" منتشر شد.','{\"story_title\":\"\\u067e\\u0634\\u0645\\u0627\\u0644\\u0648 \\u0634\\u06cc\\u0631 \\u06a9\\u0648\\u0686\\u0648\\u0644\\u0648\",\"episode_title\":\"\\u06a9\\u0644 \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u067e\\u0634\\u0645\\u0627\\u0644\\u0648\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-06 16:47:11','2025-10-06 16:47:11'),(7,2,'content','قسمت جدید منتشر شد','قسمت جدید \"کل داستان پشمالو\" از داستان \"پشمالو شیر کوچولو\" منتشر شد.','{\"story_title\":\"\\u067e\\u0634\\u0645\\u0627\\u0644\\u0648 \\u0634\\u06cc\\u0631 \\u06a9\\u0648\\u0686\\u0648\\u0644\\u0648\",\"episode_title\":\"\\u06a9\\u0644 \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u067e\\u0634\\u0645\\u0627\\u0644\\u0648\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-06 16:47:11','2025-10-06 16:47:11'),(8,3,'content','قسمت جدید منتشر شد','قسمت جدید \"کل داستان پشمالو\" از داستان \"پشمالو شیر کوچولو\" منتشر شد.','{\"story_title\":\"\\u067e\\u0634\\u0645\\u0627\\u0644\\u0648 \\u0634\\u06cc\\u0631 \\u06a9\\u0648\\u0686\\u0648\\u0644\\u0648\",\"episode_title\":\"\\u06a9\\u0644 \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u067e\\u0634\\u0645\\u0627\\u0644\\u0648\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-06 16:47:11','2025-10-06 16:47:11'),(9,4,'content','قسمت جدید منتشر شد','قسمت جدید \"کل داستان پشمالو\" از داستان \"پشمالو شیر کوچولو\" منتشر شد.','{\"story_title\":\"\\u067e\\u0634\\u0645\\u0627\\u0644\\u0648 \\u0634\\u06cc\\u0631 \\u06a9\\u0648\\u0686\\u0648\\u0644\\u0648\",\"episode_title\":\"\\u06a9\\u0644 \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u067e\\u0634\\u0645\\u0627\\u0644\\u0648\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-06 16:47:11','2025-10-06 16:47:11'),(10,5,'content','قسمت جدید منتشر شد','قسمت جدید \"کل داستان پشمالو\" از داستان \"پشمالو شیر کوچولو\" منتشر شد.','{\"story_title\":\"\\u067e\\u0634\\u0645\\u0627\\u0644\\u0648 \\u0634\\u06cc\\u0631 \\u06a9\\u0648\\u0686\\u0648\\u0644\\u0648\",\"episode_title\":\"\\u06a9\\u0644 \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u067e\\u0634\\u0645\\u0627\\u0644\\u0648\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-06 16:47:11','2025-10-06 16:47:11'),(11,1,'content','قسمت جدید منتشر شد','قسمت جدید \"کل داستان مداد رنگی ها\" از داستان \"مداد رنگی‌های جادویی\" منتشر شد.','{\"story_title\":\"\\u0645\\u062f\\u0627\\u062f \\u0631\\u0646\\u06af\\u06cc\\u200c\\u0647\\u0627\\u06cc \\u062c\\u0627\\u062f\\u0648\\u06cc\\u06cc\",\"episode_title\":\"\\u06a9\\u0644 \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u0645\\u062f\\u0627\\u062f \\u0631\\u0646\\u06af\\u06cc \\u0647\\u0627\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-06 16:51:34','2025-10-06 16:51:34'),(12,2,'content','قسمت جدید منتشر شد','قسمت جدید \"کل داستان مداد رنگی ها\" از داستان \"مداد رنگی‌های جادویی\" منتشر شد.','{\"story_title\":\"\\u0645\\u062f\\u0627\\u062f \\u0631\\u0646\\u06af\\u06cc\\u200c\\u0647\\u0627\\u06cc \\u062c\\u0627\\u062f\\u0648\\u06cc\\u06cc\",\"episode_title\":\"\\u06a9\\u0644 \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u0645\\u062f\\u0627\\u062f \\u0631\\u0646\\u06af\\u06cc \\u0647\\u0627\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-06 16:51:34','2025-10-06 16:51:34'),(13,3,'content','قسمت جدید منتشر شد','قسمت جدید \"کل داستان مداد رنگی ها\" از داستان \"مداد رنگی‌های جادویی\" منتشر شد.','{\"story_title\":\"\\u0645\\u062f\\u0627\\u062f \\u0631\\u0646\\u06af\\u06cc\\u200c\\u0647\\u0627\\u06cc \\u062c\\u0627\\u062f\\u0648\\u06cc\\u06cc\",\"episode_title\":\"\\u06a9\\u0644 \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u0645\\u062f\\u0627\\u062f \\u0631\\u0646\\u06af\\u06cc \\u0647\\u0627\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-06 16:51:34','2025-10-06 16:51:34'),(14,4,'content','قسمت جدید منتشر شد','قسمت جدید \"کل داستان مداد رنگی ها\" از داستان \"مداد رنگی‌های جادویی\" منتشر شد.','{\"story_title\":\"\\u0645\\u062f\\u0627\\u062f \\u0631\\u0646\\u06af\\u06cc\\u200c\\u0647\\u0627\\u06cc \\u062c\\u0627\\u062f\\u0648\\u06cc\\u06cc\",\"episode_title\":\"\\u06a9\\u0644 \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u0645\\u062f\\u0627\\u062f \\u0631\\u0646\\u06af\\u06cc \\u0647\\u0627\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-06 16:51:34','2025-10-06 16:51:34'),(15,5,'content','قسمت جدید منتشر شد','قسمت جدید \"کل داستان مداد رنگی ها\" از داستان \"مداد رنگی‌های جادویی\" منتشر شد.','{\"story_title\":\"\\u0645\\u062f\\u0627\\u062f \\u0631\\u0646\\u06af\\u06cc\\u200c\\u0647\\u0627\\u06cc \\u062c\\u0627\\u062f\\u0648\\u06cc\\u06cc\",\"episode_title\":\"\\u06a9\\u0644 \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u0645\\u062f\\u0627\\u062f \\u0631\\u0646\\u06af\\u06cc \\u0647\\u0627\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-06 16:51:34','2025-10-06 16:51:34'),(16,1,'content','قسمت جدید منتشر شد','قسمت جدید \"کل داستان گاوی\" از داستان \"گاو و گنجشک\" منتشر شد.','{\"story_title\":\"\\u06af\\u0627\\u0648 \\u0648 \\u06af\\u0646\\u062c\\u0634\\u06a9\",\"episode_title\":\"\\u06a9\\u0644 \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u06af\\u0627\\u0648\\u06cc\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-06 16:54:51','2025-10-06 16:54:51'),(17,2,'content','قسمت جدید منتشر شد','قسمت جدید \"کل داستان گاوی\" از داستان \"گاو و گنجشک\" منتشر شد.','{\"story_title\":\"\\u06af\\u0627\\u0648 \\u0648 \\u06af\\u0646\\u062c\\u0634\\u06a9\",\"episode_title\":\"\\u06a9\\u0644 \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u06af\\u0627\\u0648\\u06cc\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-06 16:54:51','2025-10-06 16:54:51'),(18,3,'content','قسمت جدید منتشر شد','قسمت جدید \"کل داستان گاوی\" از داستان \"گاو و گنجشک\" منتشر شد.','{\"story_title\":\"\\u06af\\u0627\\u0648 \\u0648 \\u06af\\u0646\\u062c\\u0634\\u06a9\",\"episode_title\":\"\\u06a9\\u0644 \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u06af\\u0627\\u0648\\u06cc\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-06 16:54:51','2025-10-06 16:54:51'),(19,4,'content','قسمت جدید منتشر شد','قسمت جدید \"کل داستان گاوی\" از داستان \"گاو و گنجشک\" منتشر شد.','{\"story_title\":\"\\u06af\\u0627\\u0648 \\u0648 \\u06af\\u0646\\u062c\\u0634\\u06a9\",\"episode_title\":\"\\u06a9\\u0644 \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u06af\\u0627\\u0648\\u06cc\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-06 16:54:51','2025-10-06 16:54:51'),(20,5,'content','قسمت جدید منتشر شد','قسمت جدید \"کل داستان گاوی\" از داستان \"گاو و گنجشک\" منتشر شد.','{\"story_title\":\"\\u06af\\u0627\\u0648 \\u0648 \\u06af\\u0646\\u062c\\u0634\\u06a9\",\"episode_title\":\"\\u06a9\\u0644 \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u06af\\u0627\\u0648\\u06cc\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-06 16:54:51','2025-10-06 16:54:51'),(21,1,'content','قسمت جدید منتشر شد','قسمت جدید \"کل داستان مورچه شجاع\" از داستان \"مورچه‌های شجاع\" منتشر شد.','{\"story_title\":\"\\u0645\\u0648\\u0631\\u0686\\u0647\\u200c\\u0647\\u0627\\u06cc \\u0634\\u062c\\u0627\\u0639\",\"episode_title\":\"\\u06a9\\u0644 \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u0645\\u0648\\u0631\\u0686\\u0647 \\u0634\\u062c\\u0627\\u0639\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-06 17:00:39','2025-10-06 17:00:39'),(22,2,'content','قسمت جدید منتشر شد','قسمت جدید \"کل داستان مورچه شجاع\" از داستان \"مورچه‌های شجاع\" منتشر شد.','{\"story_title\":\"\\u0645\\u0648\\u0631\\u0686\\u0647\\u200c\\u0647\\u0627\\u06cc \\u0634\\u062c\\u0627\\u0639\",\"episode_title\":\"\\u06a9\\u0644 \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u0645\\u0648\\u0631\\u0686\\u0647 \\u0634\\u062c\\u0627\\u0639\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-06 17:00:39','2025-10-06 17:00:39'),(23,3,'content','قسمت جدید منتشر شد','قسمت جدید \"کل داستان مورچه شجاع\" از داستان \"مورچه‌های شجاع\" منتشر شد.','{\"story_title\":\"\\u0645\\u0648\\u0631\\u0686\\u0647\\u200c\\u0647\\u0627\\u06cc \\u0634\\u062c\\u0627\\u0639\",\"episode_title\":\"\\u06a9\\u0644 \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u0645\\u0648\\u0631\\u0686\\u0647 \\u0634\\u062c\\u0627\\u0639\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-06 17:00:39','2025-10-06 17:00:39'),(24,4,'content','قسمت جدید منتشر شد','قسمت جدید \"کل داستان مورچه شجاع\" از داستان \"مورچه‌های شجاع\" منتشر شد.','{\"story_title\":\"\\u0645\\u0648\\u0631\\u0686\\u0647\\u200c\\u0647\\u0627\\u06cc \\u0634\\u062c\\u0627\\u0639\",\"episode_title\":\"\\u06a9\\u0644 \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u0645\\u0648\\u0631\\u0686\\u0647 \\u0634\\u062c\\u0627\\u0639\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-06 17:00:39','2025-10-06 17:00:39'),(25,5,'content','قسمت جدید منتشر شد','قسمت جدید \"کل داستان مورچه شجاع\" از داستان \"مورچه‌های شجاع\" منتشر شد.','{\"story_title\":\"\\u0645\\u0648\\u0631\\u0686\\u0647\\u200c\\u0647\\u0627\\u06cc \\u0634\\u062c\\u0627\\u0639\",\"episode_title\":\"\\u06a9\\u0644 \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u0645\\u0648\\u0631\\u0686\\u0647 \\u0634\\u062c\\u0627\\u0639\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-06 17:00:39','2025-10-06 17:00:39'),(26,1,'content','قسمت جدید منتشر شد','قسمت جدید \"کل داستان هیولای غمگین\" از داستان \"هیولای غمگین\" منتشر شد.','{\"story_title\":\"\\u0647\\u06cc\\u0648\\u0644\\u0627\\u06cc \\u063a\\u0645\\u06af\\u06cc\\u0646\",\"episode_title\":\"\\u06a9\\u0644 \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u0647\\u06cc\\u0648\\u0644\\u0627\\u06cc \\u063a\\u0645\\u06af\\u06cc\\u0646\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-06 17:02:10','2025-10-06 17:02:10'),(27,2,'content','قسمت جدید منتشر شد','قسمت جدید \"کل داستان هیولای غمگین\" از داستان \"هیولای غمگین\" منتشر شد.','{\"story_title\":\"\\u0647\\u06cc\\u0648\\u0644\\u0627\\u06cc \\u063a\\u0645\\u06af\\u06cc\\u0646\",\"episode_title\":\"\\u06a9\\u0644 \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u0647\\u06cc\\u0648\\u0644\\u0627\\u06cc \\u063a\\u0645\\u06af\\u06cc\\u0646\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-06 17:02:10','2025-10-06 17:02:10'),(28,3,'content','قسمت جدید منتشر شد','قسمت جدید \"کل داستان هیولای غمگین\" از داستان \"هیولای غمگین\" منتشر شد.','{\"story_title\":\"\\u0647\\u06cc\\u0648\\u0644\\u0627\\u06cc \\u063a\\u0645\\u06af\\u06cc\\u0646\",\"episode_title\":\"\\u06a9\\u0644 \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u0647\\u06cc\\u0648\\u0644\\u0627\\u06cc \\u063a\\u0645\\u06af\\u06cc\\u0646\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-06 17:02:10','2025-10-06 17:02:10'),(29,4,'content','قسمت جدید منتشر شد','قسمت جدید \"کل داستان هیولای غمگین\" از داستان \"هیولای غمگین\" منتشر شد.','{\"story_title\":\"\\u0647\\u06cc\\u0648\\u0644\\u0627\\u06cc \\u063a\\u0645\\u06af\\u06cc\\u0646\",\"episode_title\":\"\\u06a9\\u0644 \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u0647\\u06cc\\u0648\\u0644\\u0627\\u06cc \\u063a\\u0645\\u06af\\u06cc\\u0646\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-06 17:02:10','2025-10-06 17:02:10'),(30,5,'content','قسمت جدید منتشر شد','قسمت جدید \"کل داستان هیولای غمگین\" از داستان \"هیولای غمگین\" منتشر شد.','{\"story_title\":\"\\u0647\\u06cc\\u0648\\u0644\\u0627\\u06cc \\u063a\\u0645\\u06af\\u06cc\\u0646\",\"episode_title\":\"\\u06a9\\u0644 \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u0647\\u06cc\\u0648\\u0644\\u0627\\u06cc \\u063a\\u0645\\u06af\\u06cc\\u0646\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-06 17:02:10','2025-10-06 17:02:10'),(31,1,'content','قسمت جدید منتشر شد','قسمت جدید \"تالل\" از داستان \"مهدی\" منتشر شد.','{\"story_title\":\"\\u0645\\u0647\\u062f\\u06cc\",\"episode_title\":\"\\u062a\\u0627\\u0644\\u0644\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-17 23:33:34','2025-10-17 23:33:34'),(32,2,'content','قسمت جدید منتشر شد','قسمت جدید \"تالل\" از داستان \"مهدی\" منتشر شد.','{\"story_title\":\"\\u0645\\u0647\\u062f\\u06cc\",\"episode_title\":\"\\u062a\\u0627\\u0644\\u0644\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-17 23:33:34','2025-10-17 23:33:34'),(33,3,'content','قسمت جدید منتشر شد','قسمت جدید \"تالل\" از داستان \"مهدی\" منتشر شد.','{\"story_title\":\"\\u0645\\u0647\\u062f\\u06cc\",\"episode_title\":\"\\u062a\\u0627\\u0644\\u0644\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-17 23:33:34','2025-10-17 23:33:34'),(34,4,'content','قسمت جدید منتشر شد','قسمت جدید \"تالل\" از داستان \"مهدی\" منتشر شد.','{\"story_title\":\"\\u0645\\u0647\\u062f\\u06cc\",\"episode_title\":\"\\u062a\\u0627\\u0644\\u0644\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-17 23:33:34','2025-10-17 23:33:34'),(35,5,'content','قسمت جدید منتشر شد','قسمت جدید \"تالل\" از داستان \"مهدی\" منتشر شد.','{\"story_title\":\"\\u0645\\u0647\\u062f\\u06cc\",\"episode_title\":\"\\u062a\\u0627\\u0644\\u0644\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-17 23:33:34','2025-10-17 23:33:34'),(37,7,'content','قسمت جدید منتشر شد','قسمت جدید \"تالل\" از داستان \"مهدی\" منتشر شد.','{\"story_title\":\"\\u0645\\u0647\\u062f\\u06cc\",\"episode_title\":\"\\u062a\\u0627\\u0644\\u0644\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-10-17 23:33:34','2025-10-17 23:33:34'),(38,1,'content','قسمت جدید منتشر شد','قسمت جدید \"اژدهای نگهبان کتابخانه\" از داستان \"اژدهای نگهبان کتابخانه\" منتشر شد.','{\"story_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\",\"episode_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-12-18 13:10:29','2025-12-18 13:10:29'),(39,2,'content','قسمت جدید منتشر شد','قسمت جدید \"اژدهای نگهبان کتابخانه\" از داستان \"اژدهای نگهبان کتابخانه\" منتشر شد.','{\"story_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\",\"episode_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-12-18 13:10:29','2025-12-18 13:10:29'),(40,3,'content','قسمت جدید منتشر شد','قسمت جدید \"اژدهای نگهبان کتابخانه\" از داستان \"اژدهای نگهبان کتابخانه\" منتشر شد.','{\"story_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\",\"episode_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-12-18 13:10:29','2025-12-18 13:10:29'),(41,4,'content','قسمت جدید منتشر شد','قسمت جدید \"اژدهای نگهبان کتابخانه\" از داستان \"اژدهای نگهبان کتابخانه\" منتشر شد.','{\"story_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\",\"episode_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-12-18 13:10:29','2025-12-18 13:10:29'),(42,5,'content','قسمت جدید منتشر شد','قسمت جدید \"اژدهای نگهبان کتابخانه\" از داستان \"اژدهای نگهبان کتابخانه\" منتشر شد.','{\"story_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\",\"episode_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-12-18 13:10:29','2025-12-18 13:10:29'),(43,7,'content','قسمت جدید منتشر شد','قسمت جدید \"اژدهای نگهبان کتابخانه\" از داستان \"اژدهای نگهبان کتابخانه\" منتشر شد.','{\"story_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\",\"episode_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-12-18 13:10:29','2025-12-18 13:10:29'),(44,8,'content','قسمت جدید منتشر شد','قسمت جدید \"اژدهای نگهبان کتابخانه\" از داستان \"اژدهای نگهبان کتابخانه\" منتشر شد.','{\"story_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\",\"episode_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-12-18 13:10:29','2025-12-18 13:10:29'),(45,9,'content','قسمت جدید منتشر شد','قسمت جدید \"اژدهای نگهبان کتابخانه\" از داستان \"اژدهای نگهبان کتابخانه\" منتشر شد.','{\"story_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\",\"episode_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-12-18 13:10:29','2025-12-18 13:10:29'),(46,10,'content','قسمت جدید منتشر شد','قسمت جدید \"اژدهای نگهبان کتابخانه\" از داستان \"اژدهای نگهبان کتابخانه\" منتشر شد.','{\"story_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\",\"episode_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-12-18 13:10:29','2025-12-18 13:10:29'),(47,11,'content','قسمت جدید منتشر شد','قسمت جدید \"اژدهای نگهبان کتابخانه\" از داستان \"اژدهای نگهبان کتابخانه\" منتشر شد.','{\"story_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\",\"episode_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-12-18 13:10:29','2025-12-18 13:10:29'),(48,12,'content','قسمت جدید منتشر شد','قسمت جدید \"اژدهای نگهبان کتابخانه\" از داستان \"اژدهای نگهبان کتابخانه\" منتشر شد.','{\"story_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\",\"episode_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-12-18 13:10:29','2025-12-18 13:10:29'),(49,13,'content','قسمت جدید منتشر شد','قسمت جدید \"اژدهای نگهبان کتابخانه\" از داستان \"اژدهای نگهبان کتابخانه\" منتشر شد.','{\"story_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\",\"episode_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-12-18 13:10:29','2025-12-18 13:10:29'),(50,14,'content','قسمت جدید منتشر شد','قسمت جدید \"اژدهای نگهبان کتابخانه\" از داستان \"اژدهای نگهبان کتابخانه\" منتشر شد.','{\"story_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\",\"episode_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-12-18 13:10:29','2025-12-18 13:10:29'),(51,15,'content','قسمت جدید منتشر شد','قسمت جدید \"اژدهای نگهبان کتابخانه\" از داستان \"اژدهای نگهبان کتابخانه\" منتشر شد.','{\"story_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\",\"episode_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-12-18 13:10:29','2025-12-18 13:10:29'),(52,16,'content','قسمت جدید منتشر شد','قسمت جدید \"اژدهای نگهبان کتابخانه\" از داستان \"اژدهای نگهبان کتابخانه\" منتشر شد.','{\"story_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\",\"episode_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-12-18 13:10:29','2025-12-18 13:10:29'),(53,17,'content','قسمت جدید منتشر شد','قسمت جدید \"اژدهای نگهبان کتابخانه\" از داستان \"اژدهای نگهبان کتابخانه\" منتشر شد.','{\"story_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\",\"episode_title\":\"\\u0627\\u0698\\u062f\\u0647\\u0627\\u06cc \\u0646\\u06af\\u0647\\u0628\\u0627\\u0646 \\u06a9\\u062a\\u0627\\u0628\\u062e\\u0627\\u0646\\u0647\"}','button','/episodes/latest','شنیدن قسمت',0,1,NULL,NULL,'normal',NULL,NULL,'2025-12-18 13:10:29','2025-12-18 13:10:29');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `otp_attempts`
--

DROP TABLE IF EXISTS `otp_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `otp_attempts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `phone_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `purpose` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'verification',
  `verified` tinyint(1) NOT NULL DEFAULT '0',
  `expires_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `otp_attempts_phone_number_purpose_index` (`phone_number`,`purpose`),
  KEY `otp_attempts_expires_at_index` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `otp_attempts`
--

LOCK TABLES `otp_attempts` WRITE;
/*!40000 ALTER TABLE `otp_attempts` DISABLE KEYS */;
INSERT INTO `otp_attempts` VALUES (1,'09131397003','123456','login',0,'2025-10-06 17:04:46','2025-10-06 16:59:46','2025-10-06 16:59:46'),(2,'09339487801','123456','login',1,'2025-10-06 13:32:47','2025-10-06 17:02:08','2025-10-06 17:02:47'),(3,'09131397003','123456','login',0,'2025-10-06 17:57:46','2025-10-06 17:52:46','2025-10-06 17:52:46'),(4,'09138333903','123456','login',0,'2025-10-06 18:32:10','2025-10-06 18:27:10','2025-10-06 18:27:10'),(5,'09138333903','123456','login',0,'2025-10-10 19:41:54','2025-10-10 19:36:54','2025-10-10 19:36:54'),(6,'09339487801','123456','login',0,'2025-10-12 10:17:18','2025-10-12 10:12:18','2025-10-12 10:12:18'),(7,'09339487801','123456','login',0,'2025-10-12 10:24:18','2025-10-12 10:19:18','2025-10-12 10:19:18'),(8,'09339487801','123456','login',0,'2025-10-12 10:37:28','2025-10-12 10:32:28','2025-10-12 10:32:28'),(9,'09339487801','123456','login',1,'2025-10-12 07:10:37','2025-10-12 10:40:26','2025-10-12 10:40:37'),(10,'09136708883','123456','login',1,'2025-10-12 07:11:22','2025-10-12 10:41:17','2025-10-12 10:41:22'),(11,'09131397003','123456','login',0,'2025-10-13 01:54:26','2025-10-13 01:49:26','2025-10-13 01:49:26'),(12,'09339487801','123456','login',1,'2025-10-12 22:20:14','2025-10-13 01:49:58','2025-10-13 01:50:14'),(13,'09339487801','123456','login',0,'2025-10-13 02:12:25','2025-10-13 02:07:25','2025-10-13 02:07:25'),(14,'09339487801','123456','login',0,'2025-10-13 02:27:05','2025-10-13 02:22:05','2025-10-13 02:22:05'),(15,'09339487801','123456','login',0,'2025-10-13 02:30:17','2025-10-13 02:25:17','2025-10-13 02:25:17'),(16,'09339487801','745775','login',0,'2025-10-13 02:32:58','2025-10-13 02:27:58','2025-10-13 02:27:58'),(17,'09136708883','272542','login',1,'2025-10-12 23:03:22','2025-10-13 02:33:00','2025-10-13 02:33:22'),(18,'09135740095','585456','login',1,'2025-10-12 23:06:08','2025-10-13 02:35:33','2025-10-13 02:36:08'),(19,'09136708883','549803','login',1,'2025-10-12 23:07:11','2025-10-13 02:36:48','2025-10-13 02:37:11'),(20,'09131397003','277070','login',0,'2025-10-13 09:09:38','2025-10-13 09:04:38','2025-10-13 09:04:38'),(21,'09138333903','140648','login',0,'2025-10-13 09:10:42','2025-10-13 09:05:42','2025-10-13 09:05:42'),(22,'09339487801','836240','login',1,'2025-10-13 17:02:10','2025-10-13 20:31:55','2025-10-13 20:32:10'),(23,'09135740095','785582','login',1,'2025-10-13 18:45:49','2025-10-13 22:15:33','2025-10-13 22:15:49'),(24,'09131397003','121298','login',0,'2025-10-17 15:33:55','2025-10-17 15:28:55','2025-10-17 15:28:55'),(25,'09966190559','158736','login',1,'2025-10-18 07:00:32','2025-10-18 10:30:12','2025-10-18 10:30:32'),(26,'09966190559','481188','login',0,'2025-10-18 10:37:45','2025-10-18 10:32:45','2025-10-18 10:32:45'),(27,'09966190559','668133','login',1,'2025-10-18 07:04:31','2025-10-18 10:33:31','2025-10-18 10:34:31'),(28,'09929767361','608857','login',1,'2025-10-18 07:20:06','2025-10-18 10:48:16','2025-10-18 10:50:06'),(29,'09339487801','706254','login',0,'2025-10-25 00:36:34','2025-10-25 00:31:34','2025-10-25 00:31:34'),(30,'09339487801','317780','login',0,'2025-10-25 00:41:24','2025-10-25 00:36:24','2025-10-25 00:36:24'),(31,'09339487801','662147','login',0,'2025-10-25 00:41:59','2025-10-25 00:36:59','2025-10-25 00:36:59'),(32,'09339487801','804107','login',0,'2025-10-25 00:56:18','2025-10-25 00:51:18','2025-10-25 00:51:18'),(33,'09339487801','517111','login',0,'2025-10-25 01:00:52','2025-10-25 00:55:52','2025-10-25 00:55:52'),(34,'09136708883','403241','login',0,'2025-10-25 01:03:19','2025-10-25 00:58:19','2025-10-25 00:58:19'),(35,'09136708883','252132','login',0,'2025-10-25 01:06:56','2025-10-25 01:01:56','2025-10-25 01:01:56'),(36,'09136708883','387363','login',0,'2025-10-25 14:48:16','2025-10-25 14:43:16','2025-10-25 14:43:16'),(37,'09136708883','368326','login',0,'2025-10-25 14:52:12','2025-10-25 14:47:12','2025-10-25 14:47:12'),(38,'09136708883','180503','login',0,'2025-10-25 14:59:16','2025-10-25 14:54:16','2025-10-25 14:54:16'),(39,'09136708883','717544','login',0,'2025-10-25 15:07:38','2025-10-25 15:02:38','2025-10-25 15:02:38'),(40,'09136708883','363390','login',1,'2025-10-28 19:29:18','2025-10-28 22:58:56','2025-10-28 22:59:18'),(41,'09136708883','827015','login',0,'2025-10-28 23:05:38','2025-10-28 23:00:38','2025-10-28 23:00:38'),(42,'09136708883','487677','login',0,'2025-10-28 23:11:16','2025-10-28 23:06:16','2025-10-28 23:06:16'),(43,'09339487801','292372','login',0,'2025-10-28 23:22:58','2025-10-28 23:17:58','2025-10-28 23:17:58'),(44,'09339487801','857386','login',1,'2025-10-28 19:50:50','2025-10-28 23:20:48','2025-10-28 23:20:50'),(45,'09136708883','657084','login',1,'2025-10-28 19:51:09','2025-10-28 23:21:05','2025-10-28 23:21:09'),(46,'09136708883','966988','login',0,'2025-10-29 13:36:29','2025-10-29 13:31:29','2025-10-29 13:31:29'),(47,'09339487801','315260','login',1,'2025-10-29 10:06:38','2025-10-29 13:36:24','2025-10-29 13:36:38'),(48,'09339487801','482363','login',1,'2025-10-29 10:38:40','2025-10-29 14:08:26','2025-10-29 14:08:40'),(49,'09389264688','200411','login',1,'2025-10-29 13:55:56','2025-10-29 17:25:25','2025-10-29 17:25:56'),(50,'09389264688','286932','login',1,'2025-10-29 13:59:22','2025-10-29 17:29:03','2025-10-29 17:29:22'),(51,'09389264688','180349','login',1,'2025-10-29 14:14:34','2025-10-29 17:44:00','2025-10-29 17:44:34'),(52,'09136708883','606359','login',1,'2025-10-29 14:42:53','2025-10-29 18:12:37','2025-10-29 18:12:53'),(53,'09339487801','798960','login',1,'2025-10-29 14:45:34','2025-10-29 18:15:20','2025-10-29 18:15:34'),(54,'09136708883','996688','login',1,'2025-10-30 08:01:24','2025-10-30 11:31:19','2025-10-30 11:31:24'),(55,'09166252484','176821','login',1,'2025-10-30 21:14:05','2025-10-31 00:43:34','2025-10-31 00:44:05'),(56,'09139487801','422631','login',0,'2025-11-01 16:31:44','2025-11-01 16:26:44','2025-11-01 16:26:44'),(57,'09136708883','779225','login',1,'2025-11-01 12:57:27','2025-11-01 16:27:25','2025-11-01 16:27:27'),(58,'09166252484','442401','login',1,'2025-11-01 12:58:43','2025-11-01 16:28:28','2025-11-01 16:28:43'),(59,'09966397911','194168','login',1,'2025-11-02 11:48:13','2025-11-02 15:17:02','2025-11-02 15:18:13'),(60,'09339487801','238629','login',1,'2025-11-03 07:02:29','2025-11-03 10:32:26','2025-11-03 10:32:29'),(61,'09131397003','291360','login',0,'2025-11-03 19:46:07','2025-11-03 19:41:07','2025-11-03 19:41:07'),(62,'09025472668','895907','login',1,'2025-11-03 16:16:32','2025-11-03 19:46:10','2025-11-03 19:46:32'),(63,'09339487801','558038','login',1,'2025-11-03 16:33:53','2025-11-03 20:03:51','2025-11-03 20:03:53'),(64,'09388052829','733831','login',1,'2025-11-03 16:38:42','2025-11-03 20:08:19','2025-11-03 20:08:42'),(65,'09138333293','209280','login',1,'2025-11-03 17:02:44','2025-11-03 20:32:29','2025-11-03 20:32:44'),(66,'09131397003','642507','login',1,'2025-11-05 15:35:09','2025-11-05 19:04:30','2025-11-05 19:05:09'),(67,'09123793284','568455','login',1,'2025-11-16 17:33:49','2025-11-16 21:03:09','2025-11-16 21:03:49'),(68,'09926418233','917782','login',1,'2025-11-17 15:35:04','2025-11-17 19:04:42','2025-11-17 19:05:04'),(69,'09339487801','671161','login',1,'2025-11-25 20:17:42','2025-11-25 23:47:40','2025-11-25 23:47:42'),(70,'09339487801','688981','login',0,'2025-11-26 00:07:41','2025-11-26 00:02:41','2025-11-26 00:02:41'),(71,'09339487801','305737','login',1,'2025-11-26 05:20:04','2025-11-26 08:49:48','2025-11-26 08:50:04'),(72,'09339487801','685803','login',1,'2025-11-26 07:10:36','2025-11-26 10:40:15','2025-11-26 10:40:36'),(73,'09339487801','318003','login',1,'2025-11-26 07:17:10','2025-11-26 10:46:55','2025-11-26 10:47:10'),(74,'09136708883','200912','login',0,'2025-11-26 11:02:19','2025-11-26 10:57:19','2025-11-26 10:57:19'),(75,'09339487801','706640','login',1,'2025-11-26 07:56:26','2025-11-26 11:26:09','2025-11-26 11:26:26'),(76,'09339487801','430292','login',1,'2025-11-26 08:37:09','2025-11-26 12:06:55','2025-11-26 12:07:09'),(77,'09339487801','731805','login',1,'2025-11-26 09:28:19','2025-11-26 12:57:48','2025-11-26 12:58:19'),(78,'09339487801','762641','login',1,'2025-11-26 09:54:21','2025-11-26 13:24:04','2025-11-26 13:24:21'),(79,'09339487801','545026','login',1,'2025-11-26 10:09:10','2025-11-26 13:38:54','2025-11-26 13:39:10'),(80,'09339487801','400446','login',1,'2025-11-26 10:51:44','2025-11-26 14:21:28','2025-11-26 14:21:44'),(81,'09339487801','467151','login',1,'2025-11-26 10:58:07','2025-11-26 14:27:55','2025-11-26 14:28:07'),(82,'09339487801','875235','login',1,'2025-11-26 13:44:58','2025-11-26 17:14:40','2025-11-26 17:14:58'),(83,'09966160559','119078','login',0,'2025-11-29 12:13:04','2025-11-29 12:08:04','2025-11-29 12:08:04'),(84,'09966190559','498695','login',1,'2025-11-29 08:38:43','2025-11-29 12:08:40','2025-11-29 12:08:43'),(85,'09136708883','574857','login',1,'2025-12-07 12:45:50','2025-12-07 16:15:35','2025-12-07 16:15:50'),(86,'09339487801','198957','login',0,'2025-12-11 15:43:13','2025-12-11 15:38:13','2025-12-11 15:38:13'),(87,'09339487801','397430','login',1,'2025-12-16 18:33:47','2025-12-16 22:03:36','2025-12-16 22:03:47'),(88,'09339487801','636594','login',1,'2025-12-16 19:08:20','2025-12-16 22:38:06','2025-12-16 22:38:20'),(89,'09339487801','304913','login',1,'2025-12-16 19:09:14','2025-12-16 22:38:55','2025-12-16 22:39:14'),(90,'09339487801','418998','login',1,'2025-12-16 19:19:05','2025-12-16 22:48:42','2025-12-16 22:49:05'),(91,'09339487801','211367','login',1,'2025-12-16 19:20:00','2025-12-16 22:49:46','2025-12-16 22:50:00'),(92,'09339487801','491791','login',1,'2025-12-16 21:41:56','2025-12-17 01:11:39','2025-12-17 01:11:56'),(93,'09387925245','824429','login',0,'2025-12-17 23:51:38','2025-12-17 23:46:38','2025-12-17 23:46:38'),(94,'09387925245','713642','login',1,'2025-12-17 20:19:54','2025-12-17 23:46:46','2025-12-17 23:49:54'),(95,'09387925245','231183','login',1,'2025-12-17 20:20:50','2025-12-17 23:50:27','2025-12-17 23:50:50'),(96,'09339487801','398929','login',1,'2025-12-17 22:13:10','2025-12-18 01:42:46','2025-12-18 01:43:10'),(97,'09339487801','210401','login',0,'2025-12-18 12:34:04','2025-12-18 12:29:04','2025-12-18 12:29:04'),(98,'09339487801','140998','login',0,'2025-12-18 12:34:31','2025-12-18 12:29:31','2025-12-18 12:29:31'),(99,'09135740095','325539','login',1,'2025-12-18 09:00:28','2025-12-18 12:29:52','2025-12-18 12:30:28'),(100,'09135740095','443326','login',1,'2025-12-18 09:04:58','2025-12-18 12:34:37','2025-12-18 12:34:58');
/*!40000 ALTER TABLE `otp_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `subscription_id` bigint unsigned DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'IRR',
  `payment_method` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_gateway` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_platform` enum('website','cafebazaar','myket') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'website',
  `purchase_token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `package_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purchase_state` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purchase_time` timestamp NULL DEFAULT NULL,
  `store_response` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `is_acknowledged` tinyint(1) NOT NULL DEFAULT '0',
  `acknowledged_at` timestamp NULL DEFAULT NULL,
  `gateway_fee` decimal(10,2) NOT NULL DEFAULT '0.00',
  `net_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `exchange_rate` decimal(10,4) NOT NULL DEFAULT '1.0000',
  `payment_metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `refunded_at` timestamp NULL DEFAULT NULL,
  `refund_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refund_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `gateway_response` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `status` enum('pending','completed','failed','cancelled','refunded') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `processed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payments_transaction_id_unique` (`transaction_id`),
  KEY `payments_subscription_id_foreign` (`subscription_id`),
  KEY `payments_user_id_index` (`user_id`),
  KEY `payments_transaction_id_index` (`transaction_id`),
  KEY `payments_status_index` (`status`),
  KEY `payments_payment_gateway_index` (`payment_gateway`),
  KEY `payments_refunded_at_index` (`refunded_at`),
  KEY `payments_billing_platform_index` (`billing_platform`),
  KEY `payments_purchase_token_index` (`purchase_token`),
  KEY `payments_order_id_index` (`order_id`),
  KEY `payments_product_id_index` (`product_id`),
  CONSTRAINT `payments_subscription_id_foreign` FOREIGN KEY (`subscription_id`) REFERENCES `subscriptions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `payments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payments_chk_1` CHECK (json_valid(`store_response`)),
  CONSTRAINT `payments_chk_2` CHECK (json_valid(`payment_metadata`)),
  CONSTRAINT `payments_chk_3` CHECK (json_valid(`gateway_response`))
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (10,16,41,10000.00,'IRR','zarinpal','A0000000000000000000000000003n6q513g','zarinpal','website',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,1200.00,8800.00,1.0000,'{\"source\":\"app\",\"return_scheme\":\"sarvcast\",\"price_info\":{\"type\":\"1month\",\"name\":\"\\u0627\\u0634\\u062a\\u0631\\u0627\\u06a9 \\u06cc\\u06a9 \\u0645\\u0627\\u0647\\u0647\",\"base_price\":\"160000.00\",\"discount_percentage\":0,\"discounted_price\":160000,\"savings\":0,\"currency\":\"IRR\",\"duration_days\":30,\"description\":\"1 \\u0645\\u0627\\u0647 \\u062f\\u0633\\u062a\\u0631\\u0633\\u06cc \\u0646\\u0627\\u0645\\u062d\\u062f\\u0648\\u062f \\u0628\\u0647 \\u062a\\u0645\\u0627\\u0645\\u06cc \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u0647\\u0627\",\"plan_id\":1,\"original_price\":160000,\"coupon_discount\":159000,\"final_price\":1000,\"coupon_code\":\"ABOLFAZLTESTING\",\"coupon_info\":{\"id\":4,\"code\":\"ABOLFAZLTESTING\",\"name\":\"ABOLFAZLTESTING\",\"description\":null,\"type\":\"fixed_amount\",\"discount_value\":\"159000.00\",\"minimum_amount\":null,\"maximum_discount\":null,\"partner_type\":\"promotional\",\"partner_name\":null,\"usage_limit\":null,\"usage_count\":0,\"user_limit\":null,\"starts_at\":null,\"expires_at\":\"2027-10-27T08:42:00.000000Z\",\"is_active\":1,\"applicable_plans\":null,\"is_valid\":true,\"usage_percentage\":0,\"days_until_expiry\":679,\"created_at\":\"2025-10-29T14:17:55.000000Z\",\"updated_at\":\"2025-10-29T14:17:55.000000Z\"},\"original_amount\":1000,\"original_currency\":\"IRT\",\"amount\":10000,\"conversion_rate\":10,\"conversion_note\":\"\\u0645\\u0628\\u0644\\u063a \\u0627\\u0632 \\u062a\\u0648\\u0645\\u0627\\u0646 \\u0628\\u0647 \\u0631\\u06cc\\u0627\\u0644 \\u0628\\u0631\\u0627\\u06cc \\u062f\\u0631\\u06af\\u0627\\u0647 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u062a\\u0628\\u062f\\u06cc\\u0644 \\u0634\\u062f\"},\"episode_id\":null,\"ref_id\":80329394601,\"card_pan\":\"603799******9865\",\"verification_time\":\"2025-12-16T19:21:13.453586Z\"}',NULL,NULL,0.00,NULL,'completed','2025-12-16 22:51:13','2025-12-16 22:50:19','2025-12-16 22:51:13'),(11,17,42,1600000.00,'IRR','zarinpal','A0000000000000000000000000001ngzrx7e','zarinpal','website',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.00,0.00,1.0000,'{\"source\":\"app\",\"return_scheme\":\"sarvcast\",\"price_info\":{\"type\":\"1month\",\"name\":\"\\u0627\\u0634\\u062a\\u0631\\u0627\\u06a9 \\u06cc\\u06a9 \\u0645\\u0627\\u0647\\u0647\",\"base_price\":\"160000.00\",\"discount_percentage\":0,\"discounted_price\":160000,\"savings\":0,\"currency\":\"IRR\",\"duration_days\":30,\"description\":\"1 \\u0645\\u0627\\u0647 \\u062f\\u0633\\u062a\\u0631\\u0633\\u06cc \\u0646\\u0627\\u0645\\u062d\\u062f\\u0648\\u062f \\u0628\\u0647 \\u062a\\u0645\\u0627\\u0645\\u06cc \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u0647\\u0627\",\"plan_id\":1,\"final_price\":160000,\"original_amount\":160000,\"original_currency\":\"IRT\",\"amount\":1600000,\"conversion_rate\":10,\"conversion_note\":\"\\u0645\\u0628\\u0644\\u063a \\u0627\\u0632 \\u062a\\u0648\\u0645\\u0627\\u0646 \\u0628\\u0647 \\u0631\\u06cc\\u0627\\u0644 \\u0628\\u0631\\u0627\\u06cc \\u062f\\u0631\\u06af\\u0627\\u0647 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u062a\\u0628\\u062f\\u06cc\\u0644 \\u0634\\u062f\"},\"episode_id\":null}',NULL,NULL,0.00,NULL,'pending',NULL,'2025-12-17 23:51:11','2025-12-17 23:51:11'),(12,17,43,9600000.00,'IRR','zarinpal','A000000000000000000000000000mgqzlpyp','zarinpal','website',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.00,0.00,1.0000,'{\"source\":\"app\",\"return_scheme\":\"sarvcast\",\"price_info\":{\"type\":\"1year\",\"name\":\"\\u0627\\u0634\\u062a\\u0631\\u0627\\u06a9 \\u06cc\\u06a9\\u0633\\u0627\\u0644\\u0647\",\"base_price\":\"1920000.00\",\"discount_percentage\":50,\"discounted_price\":960000,\"savings\":960000,\"currency\":\"IRR\",\"duration_days\":365,\"description\":\"1 \\u0633\\u0627\\u0644 \\u062f\\u0633\\u062a\\u0631\\u0633\\u06cc \\u0646\\u0627\\u0645\\u062d\\u062f\\u0648\\u062f \\u0628\\u0647 \\u062a\\u0645\\u0627\\u0645\\u06cc \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u0647\\u0627\",\"plan_id\":4,\"final_price\":960000,\"original_amount\":960000,\"original_currency\":\"IRT\",\"amount\":9600000,\"conversion_rate\":10,\"conversion_note\":\"\\u0645\\u0628\\u0644\\u063a \\u0627\\u0632 \\u062a\\u0648\\u0645\\u0627\\u0646 \\u0628\\u0647 \\u0631\\u06cc\\u0627\\u0644 \\u0628\\u0631\\u0627\\u06cc \\u062f\\u0631\\u06af\\u0627\\u0647 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u062a\\u0628\\u062f\\u06cc\\u0644 \\u0634\\u062f\"},\"episode_id\":null}',NULL,NULL,0.00,NULL,'pending',NULL,'2025-12-17 23:52:31','2025-12-17 23:52:32'),(13,17,44,10000.00,'IRR','zarinpal','A000000000000000000000000000z7mqo2mv','zarinpal','website',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,1200.00,8800.00,1.0000,'{\"source\":\"app\",\"return_scheme\":\"sarvcast\",\"price_info\":{\"type\":\"1month\",\"name\":\"\\u0627\\u0634\\u062a\\u0631\\u0627\\u06a9 \\u06cc\\u06a9 \\u0645\\u0627\\u0647\\u0647\",\"base_price\":\"160000.00\",\"discount_percentage\":0,\"discounted_price\":160000,\"savings\":0,\"currency\":\"IRR\",\"duration_days\":30,\"description\":\"1 \\u0645\\u0627\\u0647 \\u062f\\u0633\\u062a\\u0631\\u0633\\u06cc \\u0646\\u0627\\u0645\\u062d\\u062f\\u0648\\u062f \\u0628\\u0647 \\u062a\\u0645\\u0627\\u0645\\u06cc \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u0647\\u0627\",\"plan_id\":1,\"original_price\":160000,\"coupon_discount\":159000,\"final_price\":1000,\"coupon_code\":\"ABOLFAZLTESTING\",\"coupon_info\":{\"id\":4,\"code\":\"ABOLFAZLTESTING\",\"name\":\"ABOLFAZLTESTING\",\"description\":null,\"type\":\"fixed_amount\",\"discount_value\":\"159000.00\",\"minimum_amount\":null,\"maximum_discount\":null,\"partner_type\":\"promotional\",\"partner_name\":null,\"usage_limit\":null,\"usage_count\":0,\"user_limit\":null,\"starts_at\":null,\"expires_at\":\"2027-10-27T08:42:00.000000Z\",\"is_active\":1,\"applicable_plans\":null,\"is_valid\":true,\"usage_percentage\":0,\"days_until_expiry\":678,\"created_at\":\"2025-10-29T14:17:55.000000Z\",\"updated_at\":\"2025-10-29T14:17:55.000000Z\"},\"original_amount\":1000,\"original_currency\":\"IRT\",\"amount\":10000,\"conversion_rate\":10,\"conversion_note\":\"\\u0645\\u0628\\u0644\\u063a \\u0627\\u0632 \\u062a\\u0648\\u0645\\u0627\\u0646 \\u0628\\u0647 \\u0631\\u06cc\\u0627\\u0644 \\u0628\\u0631\\u0627\\u06cc \\u062f\\u0631\\u06af\\u0627\\u0647 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u062a\\u0628\\u062f\\u06cc\\u0644 \\u0634\\u062f\"},\"episode_id\":null,\"ref_id\":80383951501,\"card_pan\":\"628023******1539\",\"verification_time\":\"2025-12-17T20:26:29.698722Z\"}',NULL,NULL,0.00,NULL,'completed','2025-12-17 23:56:29','2025-12-17 23:55:34','2025-12-17 23:56:29'),(14,16,45,10000.00,'IRR','zarinpal','A000000000000000000000000000wqmyz18p','zarinpal','website',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,1200.00,8800.00,1.0000,'{\"source\":\"app\",\"return_scheme\":\"sarvcast\",\"price_info\":{\"type\":\"1month\",\"name\":\"\\u0627\\u0634\\u062a\\u0631\\u0627\\u06a9 \\u06cc\\u06a9 \\u0645\\u0627\\u0647\\u0647\",\"base_price\":\"160000.00\",\"discount_percentage\":0,\"discounted_price\":160000,\"savings\":0,\"currency\":\"IRR\",\"duration_days\":30,\"description\":\"1 \\u0645\\u0627\\u0647 \\u062f\\u0633\\u062a\\u0631\\u0633\\u06cc \\u0646\\u0627\\u0645\\u062d\\u062f\\u0648\\u062f \\u0628\\u0647 \\u062a\\u0645\\u0627\\u0645\\u06cc \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u0647\\u0627\",\"plan_id\":1,\"original_price\":160000,\"coupon_discount\":159000,\"final_price\":1000,\"coupon_code\":\"ABOLFAZLTESTING\",\"coupon_info\":{\"id\":4,\"code\":\"ABOLFAZLTESTING\",\"name\":\"ABOLFAZLTESTING\",\"description\":null,\"type\":\"fixed_amount\",\"discount_value\":\"159000.00\",\"minimum_amount\":null,\"maximum_discount\":null,\"partner_type\":\"promotional\",\"partner_name\":null,\"usage_limit\":null,\"usage_count\":0,\"user_limit\":null,\"starts_at\":null,\"expires_at\":\"2027-10-27T08:42:00.000000Z\",\"is_active\":1,\"applicable_plans\":null,\"is_valid\":true,\"usage_percentage\":0,\"days_until_expiry\":678,\"created_at\":\"2025-10-29T14:17:55.000000Z\",\"updated_at\":\"2025-10-29T14:17:55.000000Z\"},\"original_amount\":1000,\"original_currency\":\"IRT\",\"amount\":10000,\"conversion_rate\":10,\"conversion_note\":\"\\u0645\\u0628\\u0644\\u063a \\u0627\\u0632 \\u062a\\u0648\\u0645\\u0627\\u0646 \\u0628\\u0647 \\u0631\\u06cc\\u0627\\u0644 \\u0628\\u0631\\u0627\\u06cc \\u062f\\u0631\\u06af\\u0627\\u0647 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u062a\\u0628\\u062f\\u06cc\\u0644 \\u0634\\u062f\"},\"episode_id\":null,\"ref_id\":80386973701,\"card_pan\":\"603799******9865\",\"verification_time\":\"2025-12-17T22:14:05.838382Z\"}',NULL,NULL,0.00,NULL,'completed','2025-12-18 01:44:05','2025-12-18 01:43:22','2025-12-18 01:44:05'),(15,7,46,2304000.00,'IRR','zarinpal','A000000000000000000000000000dj2qmllz','zarinpal','website',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.00,0.00,1.0000,'{\"source\":\"app\",\"return_scheme\":\"sarvcast\",\"price_info\":{\"type\":\"3month\",\"name\":\"\\u0627\\u0634\\u062a\\u0631\\u0627\\u06a9 3 \\u0645\\u0627\\u0647\\u0647\",\"base_price\":\"480000.00\",\"discount_percentage\":20,\"discounted_price\":384000,\"savings\":96000,\"currency\":\"IRR\",\"duration_days\":90,\"description\":\"3 \\u0645\\u0627\\u0647 \\u062f\\u0633\\u062a\\u0631\\u0633\\u06cc \\u0646\\u0627\\u0645\\u062d\\u062f\\u0648\\u062f\",\"plan_id\":2,\"original_price\":384000,\"coupon_discount\":153600,\"final_price\":230400,\"coupon_code\":\"Sarv40\",\"coupon_info\":{\"id\":6,\"code\":\"SARV40\",\"name\":\"Sarv40\",\"description\":null,\"type\":\"percentage\",\"discount_value\":\"40.00\",\"minimum_amount\":null,\"maximum_discount\":null,\"partner_type\":\"promotional\",\"partner_name\":null,\"usage_limit\":null,\"usage_count\":0,\"user_limit\":null,\"starts_at\":null,\"expires_at\":\"2027-09-12T07:32:00.000000Z\",\"is_active\":1,\"applicable_plans\":null,\"is_valid\":true,\"usage_percentage\":0,\"days_until_expiry\":632,\"created_at\":\"2025-12-18T09:02:51.000000Z\",\"updated_at\":\"2025-12-18T09:02:51.000000Z\"},\"original_amount\":230400,\"original_currency\":\"IRT\",\"amount\":2304000,\"conversion_rate\":10,\"conversion_note\":\"\\u0645\\u0628\\u0644\\u063a \\u0627\\u0632 \\u062a\\u0648\\u0645\\u0627\\u0646 \\u0628\\u0647 \\u0631\\u06cc\\u0627\\u0644 \\u0628\\u0631\\u0627\\u06cc \\u062f\\u0631\\u06af\\u0627\\u0647 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u062a\\u0628\\u062f\\u06cc\\u0644 \\u0634\\u062f\"},\"episode_id\":null}',NULL,NULL,0.00,NULL,'pending',NULL,'2025-12-18 12:35:13','2025-12-18 12:35:14');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `people`
--

DROP TABLE IF EXISTS `people`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `people` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bio` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `image_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `roles` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `total_stories` int NOT NULL DEFAULT '0',
  `total_episodes` int NOT NULL DEFAULT '0',
  `average_rating` decimal(3,2) NOT NULL DEFAULT '0.00',
  `is_verified` tinyint(1) NOT NULL DEFAULT '0',
  `last_active_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `people_name_index` (`name`),
  KEY `people_is_verified_index` (`is_verified`),
  FULLTEXT KEY `people_name_bio_fulltext` (`name`,`bio`),
  CONSTRAINT `people_chk_1` CHECK (json_valid(`roles`))
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `people`
--

LOCK TABLES `people` WRITE;
/*!40000 ALTER TABLE `people` DISABLE KEYS */;
INSERT INTO `people` VALUES (2,'امیر مسعود عابدینی',NULL,NULL,'[\"voice_actor\",\"director\",\"producer\",\"narrator\"]',0,0,0.00,1,NULL,'2025-10-06 16:30:01','2025-10-06 16:30:14'),(3,'نجمه موسوی فرد',NULL,NULL,'[\"voice_actor\",\"director\",\"writer\",\"producer\",\"author\",\"narrator\"]',0,0,0.00,1,NULL,'2025-10-06 16:30:30','2025-10-06 16:30:30'),(4,'سوگند محمود شاهی',NULL,NULL,'[\"voice_actor\",\"director\",\"writer\",\"producer\",\"author\",\"narrator\"]',0,0,0.00,1,NULL,'2025-10-06 16:30:41','2025-10-06 16:34:32'),(5,'نجمه گندم کار',NULL,NULL,'[\"voice_actor\",\"narrator\"]',0,0,0.00,1,NULL,'2025-10-06 16:31:28','2025-10-06 16:34:38'),(6,'لیلا عزیزی',NULL,NULL,'[\"voice_actor\",\"narrator\"]',0,0,0.00,1,NULL,'2025-10-06 16:31:44','2025-10-06 16:31:44'),(7,'محمدکاظم بوستانی',NULL,NULL,'[\"voice_actor\",\"narrator\"]',0,0,0.00,1,NULL,'2025-10-06 16:32:01','2025-10-06 16:34:34'),(8,'سمانه اصغری',NULL,NULL,'[\"voice_actor\",\"narrator\"]',0,0,0.00,1,NULL,'2025-10-06 16:32:20','2025-10-06 16:34:29'),(9,'ارشیا ابراهیمی',NULL,NULL,'[\"voice_actor\",\"narrator\"]',0,0,0.00,1,NULL,'2025-10-06 16:33:06','2025-10-06 16:33:06'),(10,'ابوالفضل نجفی',NULL,NULL,'[\"writer\",\"author\"]',0,0,0.00,1,NULL,'2025-10-06 16:38:29','2025-10-06 16:38:29');
/*!40000 ALTER TABLE `people` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `performance_benchmarks`
--

DROP TABLE IF EXISTS `performance_benchmarks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `performance_benchmarks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `benchmark_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `component` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` decimal(10,4) NOT NULL,
  `unit` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `measured_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `performance_benchmarks_benchmark_name_measured_at_index` (`benchmark_name`,`measured_at`),
  KEY `performance_benchmarks_component_measured_at_index` (`component`,`measured_at`),
  KEY `performance_benchmarks_measured_at_index` (`measured_at`),
  CONSTRAINT `performance_benchmarks_chk_1` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `performance_benchmarks`
--

LOCK TABLES `performance_benchmarks` WRITE;
/*!40000 ALTER TABLE `performance_benchmarks` DISABLE KEYS */;
/*!40000 ALTER TABLE `performance_benchmarks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `performance_metrics`
--

DROP TABLE IF EXISTS `performance_metrics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `performance_metrics` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `feature` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Feature being monitored (timeline, comment, etc.)',
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'Performance data in JSON format',
  `response_time` decimal(10,2) NOT NULL COMMENT 'Response time in milliseconds',
  `memory_usage` bigint NOT NULL COMMENT 'Memory usage in bytes',
  `database_queries` int NOT NULL COMMENT 'Number of database queries',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `performance_metrics_feature_created_at_index` (`feature`,`created_at`),
  KEY `performance_metrics_response_time_created_at_index` (`response_time`,`created_at`),
  KEY `performance_metrics_created_at_index` (`created_at`),
  CONSTRAINT `performance_metrics_chk_1` CHECK (json_valid(`data`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `performance_metrics`
--

LOCK TABLES `performance_metrics` WRITE;
/*!40000 ALTER TABLE `performance_metrics` DISABLE KEYS */;
/*!40000 ALTER TABLE `performance_metrics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `group` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`),
  KEY `personal_access_tokens_expires_at_index` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
INSERT INTO `personal_access_tokens` VALUES (1,'App\\Models\\User',6,'auth-token','792d9a56656fc3f1ae8a811b5623298b47fbe694f688688aa88cc83c95bf5c4f','[\"*\"]','2025-10-13 20:32:40',NULL,'2025-10-06 17:02:47','2025-10-13 20:32:40'),(2,'App\\Models\\User',6,'auth-token','00732ea9e5e854bfb88a9e903d65e4e66cd3a75c56d9dd3bc5101fe9bd592cbe','[\"*\"]','2025-10-13 02:38:47',NULL,'2025-10-12 10:40:37','2025-10-13 02:38:47'),(3,'App\\Models\\User',3,'auth-token','b19e6d9f71455a9018a959fced3fc8800f489506da6082eaa379ff31a2e9c9d4','[\"*\"]','2025-10-13 01:49:37',NULL,'2025-10-12 10:41:22','2025-10-13 01:49:37'),(4,'App\\Models\\User',6,'auth-token','0a6e05312bc2f4f742aae21cbaeb24c018309dcd16baba4fc97078f87ce04120','[\"*\"]','2025-10-13 01:50:32',NULL,'2025-10-13 01:50:14','2025-10-13 01:50:32'),(5,'App\\Models\\User',3,'auth-token','eea99231fe29f5b7921398aed521273c02daf82eeee9bc388417493a2a41cc5c','[\"*\"]',NULL,NULL,'2025-10-13 02:33:22','2025-10-13 02:33:22'),(6,'App\\Models\\User',7,'auth-token','34fbb67d9a5ca8ae63d0d485ef7d72d1eb15571e1d1097417f7189ccf9f21d9f','[\"*\"]','2025-10-13 02:47:50',NULL,'2025-10-13 02:36:08','2025-10-13 02:47:50'),(7,'App\\Models\\User',3,'auth-token','3ab76a495bb75a68593739430acf159b8a1e830bfe8b1817caf96a2210e0dbde','[\"*\"]','2025-10-13 02:37:35',NULL,'2025-10-13 02:37:11','2025-10-13 02:37:35'),(8,'App\\Models\\User',6,'auth-token','25f4d03ab96919f093833eb46224f7f3601f06fd1dd125891efa269a99f6ab63','[\"*\"]','2025-10-13 22:15:56',NULL,'2025-10-13 20:32:10','2025-10-13 22:15:56'),(9,'App\\Models\\User',7,'auth-token','025e20c3d41fc543a35fbd58411fe995f019aca525a8ef47687bd8ae7e6b5ebb','[\"*\"]','2025-10-30 11:31:08',NULL,'2025-10-13 22:15:49','2025-10-30 11:31:08'),(10,'App\\Models\\User',8,'auth-token','2db82889ee78767deecdcbd60a6b93eea755ef344bce469050adaaad8ee5d269','[\"*\"]',NULL,NULL,'2025-10-18 10:30:32','2025-10-18 10:30:32'),(11,'App\\Models\\User',8,'auth-token','0f32860db265094054bf47de95c30840b607a00dea99725f7383a531c50091df','[\"*\"]',NULL,NULL,'2025-10-18 10:34:31','2025-10-18 10:34:31'),(12,'App\\Models\\User',9,'auth-token','d42cb2b24f0087bf3a0a566860fdf3c169aa8310f951e8205b33c2f401361dd0','[\"*\"]',NULL,NULL,'2025-10-18 10:50:06','2025-10-18 10:50:06'),(13,'App\\Models\\User',3,'auth-token','142f749fb7e5690fda5685fc77a224b439ee2fa92688944978ae3366b0b8cd10','[\"*\"]',NULL,NULL,'2025-10-28 22:59:18','2025-10-28 22:59:18'),(14,'App\\Models\\User',6,'auth-token','35d030b60ca8d42aa8d654793762d182ab2859909263eab9f3291d559056d8a0','[\"*\"]',NULL,NULL,'2025-10-28 23:20:50','2025-10-28 23:20:50'),(15,'App\\Models\\User',3,'auth-token','e98ed8d4b53c2baf12b326aa0bf1e70f6911f90b7bd86ad9145dc3d08c680d45','[\"*\"]','2025-10-29 00:23:01',NULL,'2025-10-28 23:21:09','2025-10-29 00:23:01'),(16,'App\\Models\\User',6,'auth-token','f968d1f32d24f7c99a940819fcf08bf3288ced0b379df080b79f2a47a3913ece','[\"*\"]','2025-10-29 14:04:13',NULL,'2025-10-29 13:36:38','2025-10-29 14:04:13'),(17,'App\\Models\\User',6,'auth-token','c3386bfa3ca1e15f994a334d6814779539d01465f767727c6e3591c19f88c102','[\"*\"]','2025-10-29 14:14:12',NULL,'2025-10-29 14:08:40','2025-10-29 14:14:12'),(18,'App\\Models\\User',10,'auth-token','4f5a10fac7aa15b7bb96c65664f132d5950bdeb5a4fa409d9c03280513795b73','[\"*\"]',NULL,NULL,'2025-10-29 17:25:56','2025-10-29 17:25:56'),(19,'App\\Models\\User',10,'auth-token','7af9d4593290df8b53cf413dc9ad9e496228d7fc3cc2ef2499678b21bdce9322','[\"*\"]',NULL,NULL,'2025-10-29 17:29:22','2025-10-29 17:29:22'),(20,'App\\Models\\User',10,'auth-token','d715ef1b7731dbf1dedccabe244a33cb47ecb36f44cdb3851250888a3618df04','[\"*\"]','2025-10-29 18:06:47',NULL,'2025-10-29 17:44:34','2025-10-29 18:06:47'),(21,'App\\Models\\User',3,'auth-token','cf6e080f8db43e6eb0b499a6201f045602a01a384415e531424f2f1d70043192','[\"*\"]','2025-10-29 18:13:15',NULL,'2025-10-29 18:12:53','2025-10-29 18:13:15'),(22,'App\\Models\\User',6,'auth-token','6844b70acdd4da9ca8020dd4f71cca18dcb1793e2226729c23ea4f91f5c194fe','[\"*\"]','2025-11-05 17:26:10',NULL,'2025-10-29 18:15:34','2025-11-05 17:26:10'),(23,'App\\Models\\User',3,'auth-token','cec122809e48c43584b1bd9b08ab5a59c5b7d97c01c340a930c4ad799c567dbc','[\"*\"]','2025-11-01 16:27:15',NULL,'2025-10-30 11:31:24','2025-11-01 16:27:15'),(24,'App\\Models\\User',11,'auth-token','3543c8e4882fa7e02626a42d28297d50900fbf0227cff70cfbd28256360a6613','[\"*\"]',NULL,NULL,'2025-10-31 00:44:05','2025-10-31 00:44:05'),(25,'App\\Models\\User',3,'auth-token','67127ee695579fb8acc98ba75308503526e45b423d299bc6365bd73067fe6302','[\"*\"]','2025-11-01 16:28:16',NULL,'2025-11-01 16:27:27','2025-11-01 16:28:16'),(26,'App\\Models\\User',11,'auth-token','27c1e4b773f70c6bb5d7291bf1c344a89f25167bc701e2db7dc9c5a2d1d431a8','[\"*\"]','2025-11-03 10:32:15',NULL,'2025-11-01 16:28:43','2025-11-03 10:32:15'),(27,'App\\Models\\User',12,'auth-token','8d7bfc079d43479cb7bfb2a2e1527b55cc40173af03beb3275c545a2af0f5337','[\"*\"]','2025-11-02 15:26:19',NULL,'2025-11-02 15:18:13','2025-11-02 15:26:19'),(28,'App\\Models\\User',6,'auth-token','4fa785544df96d7fb0e2c43e07f85965e3e5dad1d64f6f198b33470d6d014695','[\"*\"]','2025-11-03 20:03:35',NULL,'2025-11-03 10:32:29','2025-11-03 20:03:35'),(29,'App\\Models\\User',2,'auth-token','9f0d410a5c99297d2e8a8df524226904f88574da64a7f4d080eda0a2c3a8abca','[\"*\"]','2025-11-04 11:29:23',NULL,'2025-11-03 19:46:32','2025-11-04 11:29:23'),(30,'App\\Models\\User',6,'auth-token','dcbd2f2003d05368e174c81f8905f7ff87e8343e428ae72e13d86b395bb588de','[\"*\"]','2025-11-25 23:47:29',NULL,'2025-11-03 20:03:53','2025-11-25 23:47:29'),(31,'App\\Models\\User',13,'auth-token','609893226c1d600646191060b70be3e6fc58150aac7b4d45489ec31dcbc598bb','[\"*\"]','2025-12-13 16:07:11',NULL,'2025-11-03 20:08:42','2025-12-13 16:07:11'),(32,'App\\Models\\User',1,'auth-token','4a5987794387e8b09023cf82383bcbc071fae136d294590ff3531c68c16a2fb2','[\"*\"]','2025-12-11 13:24:30',NULL,'2025-11-03 20:32:44','2025-12-11 13:24:30'),(33,'App\\Models\\User',5,'auth-token','3992fe279c19562e263be721ba78fe06c9f9df76500e2ad54c8c29e658ddc4ee','[\"*\"]','2025-12-03 10:52:21',NULL,'2025-11-05 19:05:09','2025-12-03 10:52:21'),(34,'App\\Models\\User',14,'auth-token','30e7d29f0a07a62633b7deac0b987646234e3b4b53f85f58200d0e421d13ec66','[\"*\"]','2025-11-16 21:45:29',NULL,'2025-11-16 21:03:49','2025-11-16 21:45:29'),(35,'App\\Models\\User',15,'auth-token','5418f3efd95afed4e7623a351b4fed43fe093f56cebe45ce0adde739e2f78498','[\"*\"]','2025-11-18 23:53:36',NULL,'2025-11-17 19:05:04','2025-11-18 23:53:36'),(36,'App\\Models\\User',6,'auth-token','e3c6405dee7277e2f5afc7a0a677a6c97b1635862481f168e89dc080f3b31255','[\"*\"]','2025-12-16 15:02:20',NULL,'2025-11-25 23:47:42','2025-12-16 15:02:20'),(37,'App\\Models\\User',6,'auth-token','697611e531015b4eb2a5de213f49b0905e0802b3adc46c3df5f045054427f2f0','[\"*\"]','2025-11-26 17:15:55',NULL,'2025-11-26 08:50:04','2025-11-26 17:15:55'),(38,'App\\Models\\User',6,'auth-token','2bd46c9dbd0ed876998b66631dc8276f476e8c589a3bf40923c94afcd3d17209','[\"*\"]','2025-11-26 13:23:39',NULL,'2025-11-26 12:58:19','2025-11-26 13:23:39'),(39,'App\\Models\\User',8,'auth-token','34042167c5201e2a8b24381710e1a8260c1a81e47aacebe253a49640fa1e73d3','[\"*\"]','2025-11-29 12:27:14',NULL,'2025-11-29 12:08:43','2025-11-29 12:27:14'),(40,'App\\Models\\User',3,'auth-token','7782d54056b5fb44fc6c609b1b1f345afd3ba729ecab6ff49d7a9cdd6f517e96','[\"*\"]','2025-12-16 22:26:44',NULL,'2025-12-07 16:15:50','2025-12-16 22:26:44'),(41,'App\\Models\\User',6,'auth-token','0ee31ef22ac5fa534f027358a224db39f135cadfd849778a13c5c93e147dafc3','[\"*\"]','2025-12-16 22:34:03',NULL,'2025-12-16 22:03:47','2025-12-16 22:34:03'),(42,'App\\Models\\User',6,'auth-token','917e3eaefd32103629cbb57c10f7cb9fff59077d10f412d98922a89951c548b6','[\"*\"]','2025-12-16 22:38:40',NULL,'2025-12-16 22:38:20','2025-12-16 22:38:40'),(43,'App\\Models\\User',16,'auth-token','3a39f24686b9259376be024ed1ab849c6051422737817ccc5b9b6026b7962774','[\"*\"]','2025-12-18 13:32:37',NULL,'2025-12-16 22:49:05','2025-12-18 13:32:37'),(44,'App\\Models\\User',16,'auth-token','b6a60a9cd217e28bcb82495eaa59b6fa24dff45dd32025d6b044bbe61e6c2fee','[\"*\"]','2025-12-17 01:54:21',NULL,'2025-12-17 01:11:56','2025-12-17 01:54:21'),(45,'App\\Models\\User',17,'auth-token','26e646ae0d8f737aa15696119f7f9c4c9a3b2691321b2176fb57c482c8e177a2','[\"*\"]','2025-12-18 13:25:16',NULL,'2025-12-17 23:49:54','2025-12-18 13:25:16'),(46,'App\\Models\\User',7,'auth-token','3b32fa2e86a9720c43af00d10bf91ceb4b1d2553ad70207d04fdd8c3c59d65b6','[\"*\"]','2025-12-18 13:25:16',NULL,'2025-12-18 12:30:28','2025-12-18 13:25:16');
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `play_histories`
--

DROP TABLE IF EXISTS `play_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `play_histories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `episode_id` bigint unsigned NOT NULL,
  `story_id` bigint unsigned NOT NULL,
  `played_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `duration_played` int NOT NULL,
  `total_duration` int NOT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  `device_info` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  PRIMARY KEY (`id`),
  KEY `play_histories_story_id_foreign` (`story_id`),
  KEY `play_histories_user_id_index` (`user_id`),
  KEY `play_histories_episode_id_index` (`episode_id`),
  KEY `play_histories_played_at_index` (`played_at`),
  KEY `idx_user_played_at` (`user_id`,`played_at`),
  KEY `idx_episode_played_at` (`episode_id`,`played_at`),
  KEY `idx_story_played_at` (`story_id`,`played_at`),
  KEY `idx_user_completed_played_at` (`user_id`,`completed`,`played_at`),
  KEY `idx_user_incomplete_played_at` (`user_id`,`completed`,`played_at`),
  KEY `idx_played_at_completed` (`played_at`,`completed`),
  KEY `idx_played_at_desc` (`played_at`),
  KEY `idx_user_episode` (`user_id`,`episode_id`),
  KEY `idx_user_story` (`user_id`,`story_id`),
  KEY `idx_duration_played` (`duration_played`),
  KEY `idx_total_duration` (`total_duration`),
  CONSTRAINT `play_histories_episode_id_foreign` FOREIGN KEY (`episode_id`) REFERENCES `episodes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `play_histories_story_id_foreign` FOREIGN KEY (`story_id`) REFERENCES `stories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `play_histories_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `play_histories_chk_1` CHECK (json_valid(`device_info`))
) ENGINE=InnoDB AUTO_INCREMENT=157 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `play_histories`
--

LOCK TABLES `play_histories` WRITE;
/*!40000 ALTER TABLE `play_histories` DISABLE KEYS */;
INSERT INTO `play_histories` VALUES (39,7,2,3,'2025-10-14 09:50:15',0,409,0,NULL),(40,7,5,6,'2025-10-14 09:50:58',0,505,0,NULL),(41,7,2,3,'2025-10-15 12:38:18',0,409,0,NULL),(42,7,2,3,'2025-10-16 20:43:48',0,409,0,NULL),(43,7,5,6,'2025-10-16 20:43:55',0,505,0,NULL),(44,7,4,4,'2025-10-16 20:44:21',0,401,0,NULL),(45,7,2,3,'2025-10-17 19:56:48',0,409,0,NULL),(46,7,3,7,'2025-10-17 23:25:46',0,429,0,NULL),(47,7,5,6,'2025-10-17 23:25:54',0,505,0,NULL),(48,7,4,4,'2025-10-17 23:26:38',0,401,0,NULL),(49,7,2,3,'2025-10-17 23:27:07',0,409,0,NULL),(50,7,3,7,'2025-10-17 23:27:52',0,429,0,NULL),(51,7,5,6,'2025-10-21 14:42:45',0,505,0,NULL),(52,7,4,4,'2025-10-21 14:43:13',0,401,0,NULL),(53,3,2,3,'2025-10-28 23:36:19',0,409,0,NULL),(54,3,2,3,'2025-10-28 23:36:38',0,409,0,NULL),(57,10,4,4,'2025-10-29 17:44:47',0,401,0,NULL),(60,7,3,7,'2025-10-29 18:43:47',0,429,0,NULL),(61,7,3,7,'2025-10-30 11:31:02',0,429,0,NULL),(62,3,6,5,'2025-10-30 11:33:40',0,502,0,NULL),(63,3,3,7,'2025-10-30 12:55:23',0,429,0,NULL),(64,3,4,4,'2025-10-30 12:55:43',0,401,0,NULL),(65,3,5,6,'2025-10-30 12:56:00',0,505,0,NULL),(66,3,4,4,'2025-10-30 16:08:45',0,401,0,NULL),(67,3,4,4,'2025-10-31 00:00:14',0,401,0,NULL),(68,3,5,6,'2025-10-31 00:02:40',0,505,0,NULL),(69,3,2,3,'2025-11-01 16:27:38',0,409,0,NULL),(70,3,6,5,'2025-11-01 16:28:12',0,502,0,NULL),(71,11,3,7,'2025-11-01 16:31:27',0,429,0,NULL),(72,11,3,7,'2025-11-01 16:32:06',0,429,0,NULL),(73,12,3,7,'2025-11-02 15:18:48',0,429,0,NULL),(74,12,4,4,'2025-11-02 15:25:08',0,401,0,NULL),(75,11,2,3,'2025-11-03 10:31:57',0,409,0,NULL),(76,11,2,3,'2025-11-03 10:32:10',0,409,0,NULL),(80,1,4,4,'2025-11-03 20:32:55',0,401,0,NULL),(81,13,4,4,'2025-11-04 00:30:19',0,401,0,NULL),(82,2,5,6,'2025-11-04 11:21:32',0,505,0,NULL),(83,2,4,4,'2025-11-04 11:29:23',0,401,0,NULL),(88,13,3,7,'2025-11-06 19:38:31',0,429,0,NULL),(89,13,5,6,'2025-11-06 19:40:17',0,505,0,NULL),(90,13,4,4,'2025-11-06 19:42:08',0,401,0,NULL),(95,5,3,7,'2025-11-10 17:48:37',0,429,0,NULL),(96,5,4,4,'2025-11-10 17:49:29',0,401,0,NULL),(98,5,5,6,'2025-11-12 18:44:57',0,505,0,NULL),(102,14,3,7,'2025-11-16 21:37:25',0,429,0,NULL),(103,14,3,7,'2025-11-16 21:42:19',0,429,0,NULL),(104,14,5,6,'2025-11-16 21:45:29',0,505,0,NULL),(105,15,3,7,'2025-11-17 21:13:42',0,429,0,NULL),(106,15,3,7,'2025-11-17 23:57:57',0,429,0,NULL),(107,15,2,3,'2025-11-18 23:53:17',0,409,0,NULL),(108,15,4,4,'2025-11-18 23:53:36',0,401,0,NULL),(125,1,2,3,'2025-11-26 17:51:12',0,409,0,NULL),(127,1,2,3,'2025-11-28 12:50:26',0,409,0,NULL),(128,1,4,4,'2025-11-28 12:51:17',0,401,0,NULL),(129,8,3,7,'2025-11-29 12:13:37',0,429,0,NULL),(131,1,4,4,'2025-12-01 15:23:13',0,401,0,NULL),(133,5,4,4,'2025-12-03 10:52:21',0,401,0,NULL),(138,16,3,7,'2025-12-18 02:07:42',0,429,0,NULL),(139,16,4,4,'2025-12-18 02:08:06',0,401,0,NULL),(140,16,3,7,'2025-12-18 10:09:24',0,429,0,NULL),(141,16,5,6,'2025-12-18 10:12:25',0,505,0,NULL),(142,16,5,6,'2025-12-18 10:13:03',0,505,0,NULL),(143,16,2,3,'2025-12-18 10:15:56',0,409,0,NULL),(144,16,5,6,'2025-12-18 10:16:24',0,505,0,NULL),(145,16,2,3,'2025-12-18 10:16:54',0,409,0,NULL),(146,16,6,5,'2025-12-18 10:17:09',0,502,0,NULL),(147,7,3,7,'2025-12-18 13:24:32',0,429,0,NULL),(148,7,4,4,'2025-12-18 13:24:39',0,401,0,NULL),(149,7,4,4,'2025-12-18 13:24:54',0,401,0,NULL),(150,17,6,5,'2025-12-18 13:24:59',0,502,0,NULL),(151,17,6,5,'2025-12-18 13:25:08',0,502,0,NULL),(152,17,3,7,'2025-12-18 13:25:16',0,429,0,NULL),(153,7,5,6,'2025-12-18 13:25:16',0,505,0,NULL),(154,16,4,4,'2025-12-18 13:28:57',0,401,0,NULL),(155,16,6,5,'2025-12-18 13:32:25',0,502,0,NULL),(156,16,4,4,'2025-12-18 13:32:37',0,401,0,NULL);
/*!40000 ALTER TABLE `play_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `playlist_items`
--

DROP TABLE IF EXISTS `playlist_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `playlist_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `playlist_id` bigint unsigned NOT NULL,
  `item_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_id` bigint unsigned NOT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `added_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `playlist_items_playlist_id_item_type_item_id_unique` (`playlist_id`,`item_type`,`item_id`),
  KEY `playlist_items_playlist_id_sort_order_index` (`playlist_id`,`sort_order`),
  KEY `playlist_items_item_type_item_id_index` (`item_type`,`item_id`),
  CONSTRAINT `playlist_items_playlist_id_foreign` FOREIGN KEY (`playlist_id`) REFERENCES `user_playlists` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `playlist_items`
--

LOCK TABLES `playlist_items` WRITE;
/*!40000 ALTER TABLE `playlist_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `playlist_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `point_transactions`
--

DROP TABLE IF EXISTS `point_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `point_transactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `transaction_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `points` int NOT NULL,
  `source_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_id` bigint unsigned DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `transacted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `point_transactions_user_id_transacted_at_index` (`user_id`,`transacted_at`),
  KEY `point_transactions_transaction_type_transacted_at_index` (`transaction_type`,`transacted_at`),
  KEY `point_transactions_source_type_source_id_index` (`source_type`,`source_id`),
  CONSTRAINT `point_transactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `point_transactions_chk_1` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `point_transactions`
--

LOCK TABLES `point_transactions` WRITE;
/*!40000 ALTER TABLE `point_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `point_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ratings`
--

DROP TABLE IF EXISTS `ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ratings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `story_id` bigint unsigned DEFAULT NULL,
  `episode_id` bigint unsigned DEFAULT NULL,
  `rating` tinyint NOT NULL,
  `review` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ratings_user_id_story_id_unique` (`user_id`,`story_id`),
  UNIQUE KEY `ratings_user_id_episode_id_unique` (`user_id`,`episode_id`),
  KEY `ratings_user_id_index` (`user_id`),
  KEY `ratings_story_id_index` (`story_id`),
  KEY `ratings_episode_id_index` (`episode_id`),
  CONSTRAINT `ratings_episode_id_foreign` FOREIGN KEY (`episode_id`) REFERENCES `episodes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ratings_story_id_foreign` FOREIGN KEY (`story_id`) REFERENCES `stories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ratings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ratings`
--

LOCK TABLES `ratings` WRITE;
/*!40000 ALTER TABLE `ratings` DISABLE KEYS */;
/*!40000 ALTER TABLE `ratings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recommendation_feedback`
--

DROP TABLE IF EXISTS `recommendation_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recommendation_feedback` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `story_id` bigint unsigned NOT NULL,
  `recommendation_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `feedback_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `feedback_text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `feedback_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rec_feedback_user_idx` (`user_id`,`feedback_at`),
  KEY `rec_feedback_story_idx` (`story_id`,`feedback_at`),
  KEY `rec_feedback_type_idx` (`recommendation_type`,`feedback_type`),
  CONSTRAINT `recommendation_feedback_story_id_foreign` FOREIGN KEY (`story_id`) REFERENCES `stories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `recommendation_feedback_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `recommendation_feedback_chk_1` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recommendation_feedback`
--

LOCK TABLES `recommendation_feedback` WRITE;
/*!40000 ALTER TABLE `recommendation_feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `recommendation_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recommendation_interactions`
--

DROP TABLE IF EXISTS `recommendation_interactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recommendation_interactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `story_id` bigint unsigned NOT NULL,
  `interaction_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `recommendation_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_id` bigint unsigned DEFAULT NULL,
  `context` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `interacted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recommendation_interactions_session_id_foreign` (`session_id`),
  KEY `rec_interactions_user_idx` (`user_id`,`interacted_at`),
  KEY `rec_interactions_story_idx` (`story_id`,`interacted_at`),
  KEY `rec_interactions_type_idx` (`interaction_type`,`interacted_at`),
  KEY `rec_interactions_rec_type_idx` (`recommendation_type`,`interacted_at`),
  CONSTRAINT `recommendation_interactions_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `recommendation_sessions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `recommendation_interactions_story_id_foreign` FOREIGN KEY (`story_id`) REFERENCES `stories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `recommendation_interactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `recommendation_interactions_chk_1` CHECK (json_valid(`context`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recommendation_interactions`
--

LOCK TABLES `recommendation_interactions` WRITE;
/*!40000 ALTER TABLE `recommendation_interactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `recommendation_interactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recommendation_metrics`
--

DROP TABLE IF EXISTS `recommendation_metrics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recommendation_metrics` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `metric_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `recommendation_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `metric_value` decimal(10,4) NOT NULL,
  `metric_date` date NOT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `calculated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rec_metrics_unique` (`metric_type`,`recommendation_type`,`metric_date`),
  KEY `rec_metrics_type_idx` (`metric_type`,`metric_date`),
  KEY `rec_metrics_rec_type_idx` (`recommendation_type`,`metric_date`),
  CONSTRAINT `recommendation_metrics_chk_1` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recommendation_metrics`
--

LOCK TABLES `recommendation_metrics` WRITE;
/*!40000 ALTER TABLE `recommendation_metrics` DISABLE KEYS */;
/*!40000 ALTER TABLE `recommendation_metrics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recommendation_sessions`
--

DROP TABLE IF EXISTS `recommendation_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recommendation_sessions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `session_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `recommendations` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rec_sessions_user_idx` (`user_id`,`created_at`),
  KEY `rec_sessions_type_idx` (`session_type`,`created_at`),
  CONSTRAINT `recommendation_sessions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `recommendation_sessions_chk_1` CHECK (json_valid(`recommendations`)),
  CONSTRAINT `recommendation_sessions_chk_2` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recommendation_sessions`
--

LOCK TABLES `recommendation_sessions` WRITE;
/*!40000 ALTER TABLE `recommendation_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `recommendation_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `referral_codes`
--

DROP TABLE IF EXISTS `referral_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `referral_codes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `successful_referrals` int NOT NULL DEFAULT '0',
  `total_coins_earned` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `referral_codes_code_unique` (`code`),
  KEY `referral_codes_code_is_active_index` (`code`,`is_active`),
  KEY `referral_codes_user_id_successful_referrals_index` (`user_id`,`successful_referrals`),
  CONSTRAINT `referral_codes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `referral_codes`
--

LOCK TABLES `referral_codes` WRITE;
/*!40000 ALTER TABLE `referral_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `referral_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `referrals`
--

DROP TABLE IF EXISTS `referrals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `referrals` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `referrer_id` bigint unsigned NOT NULL,
  `referred_id` bigint unsigned NOT NULL,
  `referral_code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('pending','completed','expired','cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `coins_awarded` int NOT NULL DEFAULT '0',
  `completed_at` timestamp NULL DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `referrals_referred_id_unique` (`referred_id`),
  KEY `referrals_referrer_id_status_index` (`referrer_id`,`status`),
  KEY `referrals_referral_code_status_index` (`referral_code`,`status`),
  CONSTRAINT `referrals_referred_id_foreign` FOREIGN KEY (`referred_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `referrals_referrer_id_foreign` FOREIGN KEY (`referrer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `referrals_chk_1` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `referrals`
--

LOCK TABLES `referrals` WRITE;
/*!40000 ALTER TABLE `referrals` DISABLE KEYS */;
/*!40000 ALTER TABLE `referrals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reports`
--

DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reports` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `reporter_id` bigint unsigned NOT NULL,
  `content_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_id` bigint unsigned NOT NULL,
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `evidence` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `resolved_by` bigint unsigned DEFAULT NULL,
  `resolved_at` timestamp NULL DEFAULT NULL,
  `resolution` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `action_taken` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `priority` int NOT NULL DEFAULT '1',
  `is_anonymous` tinyint(1) NOT NULL DEFAULT '0',
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reports_reporter_id_foreign` (`reporter_id`),
  KEY `reports_resolved_by_foreign` (`resolved_by`),
  KEY `reports_content_type_index` (`content_type`),
  KEY `reports_content_id_index` (`content_id`),
  KEY `reports_type_index` (`type`),
  KEY `reports_status_index` (`status`),
  KEY `reports_priority_index` (`priority`),
  KEY `reports_created_at_index` (`created_at`),
  CONSTRAINT `reports_reporter_id_foreign` FOREIGN KEY (`reporter_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reports_resolved_by_foreign` FOREIGN KEY (`resolved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `reports_chk_1` CHECK (json_valid(`evidence`)),
  CONSTRAINT `reports_chk_2` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports`
--

LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permission`
--

DROP TABLE IF EXISTS `role_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_permission` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint unsigned NOT NULL,
  `permission_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_permission_role_id_permission_id_unique` (`role_id`,`permission_id`),
  KEY `role_permission_permission_id_foreign` (`permission_id`),
  CONSTRAINT `role_permission_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_permission_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permission`
--

LOCK TABLES `role_permission` WRITE;
/*!40000 ALTER TABLE `role_permission` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `school_licenses`
--

DROP TABLE IF EXISTS `school_licenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `school_licenses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `school_partnership_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `license_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_role` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_price` decimal(10,2) NOT NULL,
  `discounted_price` decimal(10,2) NOT NULL,
  `discount_amount` decimal(10,2) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` enum('active','expired','cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `is_activated` tinyint(1) NOT NULL DEFAULT '0',
  `activated_at` timestamp NULL DEFAULT NULL,
  `expired_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `school_licenses_school_partnership_id_user_id_unique` (`school_partnership_id`,`user_id`),
  KEY `school_licenses_user_id_foreign` (`user_id`),
  KEY `school_licenses_status_end_date_index` (`status`,`end_date`),
  KEY `school_licenses_license_type_index` (`license_type`),
  CONSTRAINT `school_licenses_school_partnership_id_foreign` FOREIGN KEY (`school_partnership_id`) REFERENCES `school_partnerships` (`id`) ON DELETE CASCADE,
  CONSTRAINT `school_licenses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `school_licenses`
--

LOCK TABLES `school_licenses` WRITE;
/*!40000 ALTER TABLE `school_licenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `school_licenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `school_partnerships`
--

DROP TABLE IF EXISTS `school_partnerships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `school_partnerships` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `affiliate_partner_id` bigint unsigned NOT NULL,
  `assigned_teacher_id` bigint unsigned DEFAULT NULL,
  `teacher_assigned_at` timestamp NULL DEFAULT NULL,
  `teacher_assignment_notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `school_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `school_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `school_level` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_person` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `student_count` int NOT NULL,
  `teacher_count` int NOT NULL,
  `partnership_model` enum('revenue_sharing','licensing','pilot') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `discount_rate` decimal(5,2) NOT NULL DEFAULT '60.00',
  `revenue_share_rate` decimal(5,2) DEFAULT NULL,
  `annual_license_fee` decimal(10,2) DEFAULT NULL,
  `max_student_capacity` int NOT NULL DEFAULT '500',
  `partnership_start_date` date NOT NULL,
  `partnership_end_date` date NOT NULL,
  `status` enum('pending','active','suspended','expired','terminated') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `verification_documents` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `is_verified` tinyint(1) NOT NULL DEFAULT '0',
  `verified_at` timestamp NULL DEFAULT NULL,
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `school_partnerships_affiliate_partner_id_foreign` (`affiliate_partner_id`),
  KEY `school_partnerships_status_partnership_model_index` (`status`,`partnership_model`),
  KEY `school_partnerships_school_type_index` (`school_type`),
  KEY `school_partnerships_assigned_teacher_id_index` (`assigned_teacher_id`),
  CONSTRAINT `school_partnerships_affiliate_partner_id_foreign` FOREIGN KEY (`affiliate_partner_id`) REFERENCES `affiliate_partners` (`id`) ON DELETE CASCADE,
  CONSTRAINT `school_partnerships_assigned_teacher_id_foreign` FOREIGN KEY (`assigned_teacher_id`) REFERENCES `teacher_accounts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `school_partnerships_chk_1` CHECK (json_valid(`verification_documents`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `school_partnerships`
--

LOCK TABLES `school_partnerships` WRITE;
/*!40000 ALTER TABLE `school_partnerships` DISABLE KEYS */;
/*!40000 ALTER TABLE `school_partnerships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_events`
--

DROP TABLE IF EXISTS `security_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `security_events` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `event_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `severity` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `blocked` tinyint(1) NOT NULL DEFAULT '0',
  `blocked_at` timestamp NULL DEFAULT NULL,
  `occurred_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `security_events_event_type_occurred_at_index` (`event_type`,`occurred_at`),
  KEY `security_events_severity_occurred_at_index` (`severity`,`occurred_at`),
  KEY `security_events_ip_address_occurred_at_index` (`ip_address`,`occurred_at`),
  KEY `security_events_blocked_occurred_at_index` (`blocked`,`occurred_at`),
  KEY `security_events_occurred_at_index` (`occurred_at`),
  CONSTRAINT `security_events_chk_1` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_events`
--

LOCK TABLES `security_events` WRITE;
/*!40000 ALTER TABLE `security_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `security_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('0l09Wz1wdmRRcvQowUBfAEO6SCgMrhN47woYdwqP',NULL,'45.93.170.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiNVZNOEpIRHAwWHlDWHlXa1B0UEV3T1hEVlNnOGVIRkhvcFFzNVFHQiI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czo0ODoiaHR0cHM6Ly9teS5zYXJ2Y2FzdC5pci9hZG1pbi9zdG9yaWVzLzEwL3RpbWVsaW5lIjt9czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDg6Imh0dHBzOi8vbXkuc2FydmNhc3QuaXIvYWRtaW4vc3Rvcmllcy8xMC90aW1lbGluZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1766051006),('1YvGAZNIfSlkCHc6uRH64MzsF5AOSQpiYNu7YP8o',NULL,'35.183.105.245','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36 Assetnote/1.0.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiamNFc1NtS1lHZVNaRlpONnFHOVJMVUZ4MjZlekI5ejlYRTVDVVN5OSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjI6Imh0dHBzOi8vbXkuc2FydmNhc3QuaXIiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1766050249),('5FcXt29BtBi7NO1gDJ1qjjo8l9HNPDkHvygIvuZ1',NULL,'45.93.170.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoibjdSbnpJZlZLR2lJM2lKbXl2Ujh4d0dMWUZ5aWVlMWRER2JIVGFlUCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjg6Imh0dHBzOi8vbXkuc2FydmNhc3QuaXIvbG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1766051007),('8ouTVWkF4TfBGyQGasqwop6SbRbCdTRMdr9Z7VIE',NULL,'74.125.208.5','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)','YTo0OntzOjY6Il90b2tlbiI7czo0MDoibXoxenNnTFdLVVcxdk9FMFFVUElkMEx0aXphZ1FiMnJXamc4Y0pOaiI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoxMjM6Imh0dHBzOi8vbXkuc2FydmNhc3QuaXIvY2hlY2tvdXQ/cGxhbl9zbHVnPTNtb250aCZyZXR1cm5fc2NoZW1lPXNhcnZjYXN0JnNvdXJjZT1hcHAmdXRtX2NhbXBhaWduPXN1YnNjcmlwdGlvbiZ1dG1fc291cmNlPWFwcCI7fXM6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjEyMzoiaHR0cHM6Ly9teS5zYXJ2Y2FzdC5pci9jaGVja291dD9wbGFuX3NsdWc9M21vbnRoJnJldHVybl9zY2hlbWU9c2FydmNhc3Qmc291cmNlPWFwcCZ1dG1fY2FtcGFpZ249c3Vic2NyaXB0aW9uJnV0bV9zb3VyY2U9YXBwIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1766048701),('fGmJnu1PZnDe75cU3GCo7SxbpUWa3vt4k0Iy0CyS',NULL,'45.93.170.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiT2l0NUd0QVZvUmg2UHlQa0ZNcWllV3BhQlpHM2xEM3hrWVc0Slo0diI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjg6Imh0dHBzOi8vbXkuc2FydmNhc3QuaXIvbG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1766051007),('jkKdS8cJ6NINGDxcJqImzBJHmcHKowABpE0k1Wav',3,'184.174.96.91','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0','YTo1OntzOjY6Il90b2tlbiI7czo0MDoibGRQTmcxdHUyS1pZVGtKSGZnbWdqa0MzYTRsS2d4ajI0eENOb3R5YiI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czo0MzoiaHR0cHM6Ly9teS5zYXJ2Y2FzdC5pci9hZG1pbi9zdG9yaWVzL2NyZWF0ZSI7fXM6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjQ0OiJodHRwczovL215LnNhcnZjYXN0LmlyL2FkbWluL2VwaXNvZGVzL3N0cmVhbSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjM7fQ==',1766052478),('mHs2lhjXIxDc4da5PIahhObTzuCTXXaoYLrJ3Yqk',NULL,'74.125.208.5','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)','YTozOntzOjY6Il90b2tlbiI7czo0MDoickh3bWR4TGo1d0xJdHZwVXYxOXppWFI0OFVnQ2tobXJJc2VQQk96TyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjg6Imh0dHBzOi8vbXkuc2FydmNhc3QuaXIvbG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1766048701),('ObAcsM7HkV04clrmeKkrTxlTfncpZm2LroynM6NC',NULL,'184.174.96.91','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0','YToyOntzOjY6Il90b2tlbiI7czo0MDoiSWhUUFdVcE04eEV2WU45b2s2UVU2NHRWV1RhdjBDN3I1UnROanh0eSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1766052488),('pIXA78rqt7Vv8fxslSc0MBqAL4n0QX4BO9oQbLZL',NULL,'45.93.170.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiUWVlWnE0WjI3MGRraDc1VFZ6ejdVMUVQZHQxZVVRdE1qOFlIWWsxTCI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czozOToiaHR0cHM6Ly9teS5zYXJ2Y2FzdC5pci9hZG1pbi9lcGlzb2Rlcy85Ijt9czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzk6Imh0dHBzOi8vbXkuc2FydmNhc3QuaXIvYWRtaW4vZXBpc29kZXMvOSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1766051006),('QRk4s0pDI6N9uhu5IO6DM6IZ4yego9pG5dUrm3zz',7,'5.209.63.200','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36','YTo1OntzOjY6Il90b2tlbiI7czo0MDoidXNhN3JoaEdqRHJOdHpPZ3drOU13dEtaa2xTb0I1T1RtSnVXT1ZWZiI7czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjEyMzoiaHR0cHM6Ly9teS5zYXJ2Y2FzdC5pci9jaGVja291dD9wbGFuX3NsdWc9M21vbnRoJnJldHVybl9zY2hlbWU9c2FydmNhc3Qmc291cmNlPWFwcCZ1dG1fY2FtcGFpZ249c3Vic2NyaXB0aW9uJnV0bV9zb3VyY2U9YXBwIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6Nzt9',1766048714),('UNpZ97WJjMFOL5iWPCI0uL6TlfImscnO79Wcdrov',3,'45.93.170.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiNHFoZVcxZG5aU0Rnc1NOTUFpQ1RRZG52WU13MkJVMzY1SFgzOXJCZCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDM6Imh0dHBzOi8vbXkuc2FydmNhc3QuaXIvYWRtaW4vc3Rvcmllcy9jcmVhdGUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aTozO30=',1766051387);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_logs`
--

DROP TABLE IF EXISTS `sms_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `phone_number` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `template_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `variables` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `provider` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `message_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `error_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `error_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sent_at` timestamp NULL DEFAULT NULL,
  `delivered_at` timestamp NULL DEFAULT NULL,
  `response_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sms_logs_phone_number_index` (`phone_number`),
  KEY `sms_logs_provider_index` (`provider`),
  KEY `sms_logs_status_index` (`status`),
  KEY `sms_logs_sent_at_index` (`sent_at`),
  KEY `sms_logs_template_key_index` (`template_key`),
  CONSTRAINT `sms_logs_chk_1` CHECK (json_valid(`variables`)),
  CONSTRAINT `sms_logs_chk_2` CHECK (json_valid(`response_data`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_logs`
--

LOCK TABLES `sms_logs` WRITE;
/*!40000 ALTER TABLE `sms_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `social_analytics`
--

DROP TABLE IF EXISTS `social_analytics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `social_analytics` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `metric_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_id` bigint unsigned NOT NULL,
  `metric_date` date NOT NULL,
  `metric_value` int NOT NULL DEFAULT '0',
  `metric_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `calculated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `social_metrics_unique` (`metric_type`,`target_type`,`target_id`,`metric_date`),
  KEY `social_analytics_metric_type_metric_date_index` (`metric_type`,`metric_date`),
  KEY `social_analytics_target_type_target_id_index` (`target_type`,`target_id`),
  KEY `social_analytics_metric_date_metric_value_index` (`metric_date`,`metric_value`),
  CONSTRAINT `social_analytics_chk_1` CHECK (json_valid(`metric_data`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_analytics`
--

LOCK TABLES `social_analytics` WRITE;
/*!40000 ALTER TABLE `social_analytics` DISABLE KEYS */;
/*!40000 ALTER TABLE `social_analytics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `social_interactions`
--

DROP TABLE IF EXISTS `social_interactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `social_interactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `interaction_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_id` bigint unsigned NOT NULL,
  `interaction_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `interacted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `social_interactions_unique` (`user_id`,`interaction_type`,`target_type`,`target_id`),
  KEY `social_interactions_user_id_interacted_at_index` (`user_id`,`interacted_at`),
  KEY `social_interactions_interaction_type_interacted_at_index` (`interaction_type`,`interacted_at`),
  KEY `social_interactions_target_type_target_id_index` (`target_type`,`target_id`),
  CONSTRAINT `social_interactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `social_interactions_chk_1` CHECK (json_valid(`interaction_data`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_interactions`
--

LOCK TABLES `social_interactions` WRITE;
/*!40000 ALTER TABLE `social_interactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `social_interactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sponsored_content`
--

DROP TABLE IF EXISTS `sponsored_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sponsored_content` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `sponsorship_id` bigint unsigned NOT NULL,
  `story_id` bigint unsigned DEFAULT NULL,
  `episode_id` bigint unsigned DEFAULT NULL,
  `content_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sponsor_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `brand_logo_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brand_website_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_media` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `placement_type` enum('pre_roll','mid_roll','post_roll','banner','popup','notification','dedicated_content') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_duration` int DEFAULT NULL,
  `display_frequency` int NOT NULL DEFAULT '1',
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` enum('draft','pending_approval','approved','active','paused','completed','rejected') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `rejection_reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `approved_at` timestamp NULL DEFAULT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `impressions` int NOT NULL DEFAULT '0',
  `clicks` int NOT NULL DEFAULT '0',
  `conversions` int NOT NULL DEFAULT '0',
  `ctr` decimal(5,2) NOT NULL DEFAULT '0.00',
  `conversion_rate` decimal(5,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sponsored_content_sponsorship_id_foreign` (`sponsorship_id`),
  KEY `sponsored_content_story_id_foreign` (`story_id`),
  KEY `sponsored_content_episode_id_foreign` (`episode_id`),
  KEY `sponsored_content_status_start_date_end_date_index` (`status`,`start_date`,`end_date`),
  KEY `sponsored_content_content_type_index` (`content_type`),
  KEY `sponsored_content_placement_type_index` (`placement_type`),
  CONSTRAINT `sponsored_content_episode_id_foreign` FOREIGN KEY (`episode_id`) REFERENCES `episodes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sponsored_content_sponsorship_id_foreign` FOREIGN KEY (`sponsorship_id`) REFERENCES `corporate_sponsorships` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sponsored_content_story_id_foreign` FOREIGN KEY (`story_id`) REFERENCES `stories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sponsored_content_chk_1` CHECK (json_valid(`content_media`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sponsored_content`
--

LOCK TABLES `sponsored_content` WRITE;
/*!40000 ALTER TABLE `sponsored_content` DISABLE KEYS */;
/*!40000 ALTER TABLE `sponsored_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sponsorship_analytics`
--

DROP TABLE IF EXISTS `sponsorship_analytics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sponsorship_analytics` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `sponsored_content_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `event_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `platform` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sponsorship_analytics_content_event_idx` (`sponsored_content_id`,`event_type`,`event_timestamp`),
  KEY `sponsorship_analytics_user_event_idx` (`user_id`,`event_timestamp`),
  KEY `sponsorship_analytics_event_type_idx` (`event_type`),
  CONSTRAINT `sponsorship_analytics_sponsored_content_id_foreign` FOREIGN KEY (`sponsored_content_id`) REFERENCES `sponsored_content` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sponsorship_analytics_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sponsorship_analytics_chk_1` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sponsorship_analytics`
--

LOCK TABLES `sponsorship_analytics` WRITE;
/*!40000 ALTER TABLE `sponsorship_analytics` DISABLE KEYS */;
/*!40000 ALTER TABLE `sponsorship_analytics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stories`
--

DROP TABLE IF EXISTS `stories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `subtitle` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cover_image_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_id` bigint unsigned NOT NULL,
  `director_id` bigint unsigned DEFAULT NULL,
  `writer_id` bigint unsigned DEFAULT NULL,
  `author_id` bigint unsigned DEFAULT NULL,
  `narrator_id` bigint unsigned DEFAULT NULL,
  `age_group` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fa',
  `duration` int NOT NULL DEFAULT '0',
  `total_episodes` int NOT NULL DEFAULT '0',
  `free_episodes` int NOT NULL DEFAULT '0',
  `is_premium` tinyint(1) NOT NULL DEFAULT '0',
  `is_completely_free` tinyint(1) NOT NULL DEFAULT '0',
  `play_count` int NOT NULL DEFAULT '0',
  `total_plays` int NOT NULL DEFAULT '0',
  `total_favorites` int NOT NULL DEFAULT '0',
  `total_ratings` int NOT NULL DEFAULT '0',
  `avg_rating` decimal(3,2) NOT NULL DEFAULT '0.00',
  `total_duration_played` int NOT NULL DEFAULT '0',
  `unique_listeners` int NOT NULL DEFAULT '0',
  `completion_count` int NOT NULL DEFAULT '0',
  `completion_rate` decimal(5,2) NOT NULL DEFAULT '0.00',
  `share_count` int NOT NULL DEFAULT '0',
  `download_count` int NOT NULL DEFAULT '0',
  `last_played_at` timestamp NULL DEFAULT NULL,
  `trending_since` timestamp NULL DEFAULT NULL,
  `analytics_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `rating` decimal(3,2) NOT NULL DEFAULT '0.00',
  `tags` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `status` enum('draft','pending','approved','rejected','published') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `moderation_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `moderator_id` bigint unsigned DEFAULT NULL,
  `moderated_at` timestamp NULL DEFAULT NULL,
  `moderation_notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `moderation_rating` int DEFAULT NULL,
  `age_rating` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_warnings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `rejection_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rejection_suggestions` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `allow_resubmission` tinyint(1) NOT NULL DEFAULT '1',
  `moderation_priority` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'medium',
  `flag_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `moderation_history` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `published_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `use_image_timeline` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `stories_director_id_foreign` (`director_id`),
  KEY `stories_writer_id_foreign` (`writer_id`),
  KEY `stories_author_id_foreign` (`author_id`),
  KEY `stories_narrator_id_foreign` (`narrator_id`),
  KEY `stories_category_id_index` (`category_id`),
  KEY `stories_status_index` (`status`),
  KEY `stories_is_premium_index` (`is_premium`),
  KEY `stories_age_group_index` (`age_group`),
  KEY `stories_moderation_status_index` (`moderation_status`),
  KEY `stories_moderator_id_index` (`moderator_id`),
  KEY `stories_moderated_at_index` (`moderated_at`),
  KEY `stories_moderation_priority_index` (`moderation_priority`),
  KEY `stories_total_plays_index` (`total_plays`),
  KEY `stories_total_favorites_index` (`total_favorites`),
  KEY `stories_avg_rating_index` (`avg_rating`),
  KEY `stories_unique_listeners_index` (`unique_listeners`),
  KEY `stories_completion_rate_index` (`completion_rate`),
  KEY `stories_last_played_at_index` (`last_played_at`),
  KEY `stories_trending_since_index` (`trending_since`),
  FULLTEXT KEY `stories_title_subtitle_description_fulltext` (`title`,`subtitle`,`description`),
  CONSTRAINT `stories_author_id_foreign` FOREIGN KEY (`author_id`) REFERENCES `people` (`id`) ON DELETE SET NULL,
  CONSTRAINT `stories_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  CONSTRAINT `stories_director_id_foreign` FOREIGN KEY (`director_id`) REFERENCES `people` (`id`) ON DELETE SET NULL,
  CONSTRAINT `stories_moderator_id_foreign` FOREIGN KEY (`moderator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `stories_narrator_id_foreign` FOREIGN KEY (`narrator_id`) REFERENCES `people` (`id`) ON DELETE SET NULL,
  CONSTRAINT `stories_writer_id_foreign` FOREIGN KEY (`writer_id`) REFERENCES `people` (`id`) ON DELETE SET NULL,
  CONSTRAINT `stories_chk_1` CHECK (json_valid(`analytics_data`)),
  CONSTRAINT `stories_chk_2` CHECK (json_valid(`tags`)),
  CONSTRAINT `stories_chk_3` CHECK (json_valid(`content_warnings`)),
  CONSTRAINT `stories_chk_4` CHECK (json_valid(`moderation_history`))
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stories`
--

LOCK TABLES `stories` WRITE;
/*!40000 ALTER TABLE `stories` DISABLE KEYS */;
INSERT INTO `stories` VALUES (3,'پشمالو شیر کوچولو','سفری برای یافتن شجاعت واقعی','داستان شیر کوچولوی پشمالویی که نمی‌تواند مثل شیرهای دیگر غرش کند. او در سفری جادویی با دوستان جنگلی‌اش ملاقات می‌کند و می‌آموزد که شجاعت واقعی از درون می‌آید، نه از صدای بلند. این داستان زیبا کودکان را با مفاهیم شجاعت، دوستی و اعتماد به نفس آشنا می‌کند.','stories/1759756084_cover.webp','stories/1759756084_cover_cover.webp',2,2,3,3,6,'3-5','persian',409,1,1,0,1,0,0,0,0,0.00,0,0,0,0.00,0,0,NULL,NULL,NULL,0.00,'[\"\\u0645\\u0627\\u062c\\u0631\\u0627\\u062c\\u0648\\u06cc\\u06cc\"]','published','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'medium',NULL,NULL,NULL,'2025-10-06 16:38:04','2025-10-06 17:45:18',1),(4,'گاو و گنجشک','داستان دوستی و شادی در مزرعه','گاوی گاو قهوه‌ای بزرگ که از آفتاب گرم ناراضی است، با چی‌چی گنجشک کوچولوی شاد آشنا می‌شود. چی‌چی به او می‌آموزد که شادی از گذراندن وقت با دوستان در مزرعه می‌آید. این داستان شیرین کودکان را با ارزش دوستی و لذت زندگی در طبیعت آشنا می‌کند.','stories/1759756220_cover.webp','stories/1759756220_cover_cover.webp',5,2,10,10,5,'3-5','persian',401,1,1,0,1,0,0,0,0,0.00,0,0,0,0.00,0,0,NULL,NULL,NULL,0.00,'[\"\\u062f\\u0648\\u0633\\u062a\\u06cc\"]','published','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'medium',NULL,NULL,NULL,'2025-10-06 16:40:20','2025-10-11 09:33:29',1),(5,'هیولای غمگین','سفری برای درک احساسات و رنگ‌ها','رنگی هیولای کوچولوی پشمالویی که احساساتش را به صورت رنگ‌های مختلف تجربه می‌کند. او با کمک دوستان جنگلی‌اش می‌آموزد که همه احساسات طبیعی و زیبا هستند. این داستان آموزشی کودکان را با هوش هیجانی و مدیریت احساسات آشنا می‌کند.','stories/1759756340_cover.webp','stories/1759756340_cover_cover.webp',4,2,3,3,4,'3-5','persian',502,1,0,0,1,0,0,0,0,0.00,0,0,0,0.00,0,0,NULL,NULL,NULL,0.00,'[\"\\u0645\\u0627\\u062c\\u0631\\u0627\\u062c\\u0648\\u06cc\\u06cc\"]','published','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'medium',NULL,NULL,NULL,'2025-10-06 16:42:20','2025-10-12 10:07:11',1),(6,'مورچه‌های شجاع','قدرت کار تیمی و همکاری','گروهی از مورچه‌های شجاع و سختکوش دانه گندم طلایی بزرگی را کشف می‌کنند و باید با همکاری یکدیگر موانع را پشت سر بگذارند تا آن را به لانه‌شان ببرند. این داستان الهام‌بخش کودکان را با ارزش کار تیمی و همکاری آشنا می‌کند.','stories/1759756441_cover.webp','stories/1759756441_cover_cover.webp',5,2,10,10,3,'3-5','persian',505,1,1,0,1,0,0,0,0,0.00,0,0,0,0.00,0,0,NULL,NULL,NULL,0.00,'[\"\\u062f\\u0648\\u0633\\u062a\\u06cc\"]','published','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'medium',NULL,NULL,NULL,'2025-10-06 16:44:01','2025-10-11 09:43:21',1),(7,'مداد رنگی‌های جادویی','قدرت خلاقیت و هنر','سارا دختر نه ساله‌ای که جعبه‌ای از مدادهای رنگی جادویی را کشف می‌کند که می‌توانند هر چیزی که می‌کشند را زنده کنند. او از طریق ماجراهایش با این مدادهای جادویی درباره خلاقیت، همکاری و قدرت هنر می‌آموزد. این داستان جادویی کودکان را با دنیای بی‌نهایت خلاقیت آشنا می‌کند.','stories/1759756511_cover.webp','stories/1759756511_cover_cover.webp',4,NULL,NULL,NULL,NULL,'3-5','persian',429,1,1,0,1,0,0,0,0,0.00,0,0,0,0.00,0,0,NULL,NULL,NULL,0.00,'[\"\\u0647\\u0646\\u0631\"]','published','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'medium',NULL,NULL,NULL,'2025-10-06 16:45:11','2025-10-11 09:28:45',1),(10,'اژدهای نگهبان کتابخانه','اژدهای کتابخانه','سارای ده‌ساله، دختر کتاب‌دوست، در کتابخانه قدیمی شهر با اژدهای کوچکی به نام دراکو آشنا می‌شود که نگهبان جادویی کتاب‌هاست. با هم متوجه می‌شوند که «ملکه بی‌حوصله» کلمات و داستان‌ها را می‌دزدد، و مجبورند به چهار دنیای کتاب (جنگل شعرها، شهر ریاضی، دریاچه تاریخ و قصر آینده) سفر کنند تا خیال و قصه‌ها را نجات دهند. در پایان، حتی ملکه بی‌حوصله هم با خواندن کتاب و دوستی، قلبش نرم می‌شود و کتابخانه و دنیای تخیل نجات پیدا می‌کند.','stories/1766050458_cover.jpg','stories/1766050458_cover_cover.jpg',4,2,3,NULL,NULL,'6-8','persian',0,1,0,0,1,0,0,0,0,0.00,0,0,0,0.00,0,0,NULL,NULL,NULL,0.00,'[\"\\u0645\\u0627\\u062c\\u0631\\u0627\\u062c\\u0648\\u06cc\\u06cc\"]','published','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'medium',NULL,NULL,NULL,'2025-12-18 13:04:18','2025-12-18 13:14:55',0),(11,'دوستان از سرزمین‌های دور','داستان دوستی پان‌پان و کانگی','در یک جنگل جادویی، یک پاندای آرام و مهربان به نام پان‌پان از چین و یک کانگوروی پرانرژی به نام کانگی از استرالیا با هم آشنا می‌شوند. آن‌ها اول به خاطر تفاوت در سبک بازی و فرهنگ کمی دچار سوءتفاهم می‌شوند، اما بعد یاد می‌گیرند که می‌توانند از هم چیزهای جدید یاد بگیرند و تفاوت‌ها دوستی‌شان را قوی‌تر می‌کند. در پایان روز، آن‌ها با به اشتراک گذاشتن غذا، بازی‌ها و داستان‌های سرزمین‌هایشان، بهترین دوست‌های از سرزمین‌های دور می‌شوند.','stories/1766051249_cover.jpg','stories/1766051249_cover_cover.jpg',3,2,10,NULL,8,'3-5','persian',12,1,0,0,1,0,0,0,0,0.00,0,0,0,0.00,0,0,NULL,NULL,NULL,0.00,'[\"\\u0645\\u0627\\u062c\\u0631\\u0627\\u062c\\u0648\\u06cc\\u06cc\"]','published','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'medium',NULL,NULL,NULL,'2025-12-18 13:17:29','2025-12-18 13:17:29',0),(12,'آزمایشگاه جادویی','ماجرای کشف جاذبه با آرین','آرین، پسر کوچکی که عاشق یادگیری است، یک اتاق مخفی در خانه پیدا می‌کند که در آن آزمایشگاهی جادویی با وسایل زنده وجود دارد: یک لوله شیشه‌ای، یک توپ قرمز و یک پر سبک. آن‌ها با هم درباره جاذبه صحبت می‌کنند و با انداختن توپ و پر در هوا و در داخل لوله، به آرین نشان می‌دهند که چگونه جاذبه همه چیز را به سمت زمین می‌کشد و باد چطور روی اجسام سبک‌تر اثر می‌گذارد. آرین با دیدن این \"جادوی واقعی\" عاشق علم می‌شود و تصمیم می‌گیرد هر روز آزمایش کند.','stories/1766051577_cover.jpg','stories/1766051577_cover_cover.jpg',3,2,3,NULL,5,'6-8','persian',12,1,0,0,1,0,0,0,0,0.00,0,0,0,0.00,0,0,NULL,NULL,NULL,0.00,'[\"\\u0645\\u0627\\u062c\\u0631\\u0627\\u062c\\u0648\\u06cc\\u06cc\"]','published','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'medium',NULL,NULL,NULL,'2025-12-18 13:22:57','2025-12-18 13:22:57',0);
/*!40000 ALTER TABLE `stories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `story_comment_likes`
--

DROP TABLE IF EXISTS `story_comment_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `story_comment_likes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `story_comment_likes_comment_id_user_id_unique` (`comment_id`,`user_id`),
  KEY `story_comment_likes_comment_id_created_at_index` (`comment_id`,`created_at`),
  KEY `story_comment_likes_user_id_created_at_index` (`user_id`,`created_at`),
  CONSTRAINT `story_comment_likes_comment_id_foreign` FOREIGN KEY (`comment_id`) REFERENCES `story_comments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `story_comment_likes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `story_comment_likes`
--

LOCK TABLES `story_comment_likes` WRITE;
/*!40000 ALTER TABLE `story_comment_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `story_comment_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `story_comments`
--

DROP TABLE IF EXISTS `story_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `story_comments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `story_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `parent_id` bigint unsigned DEFAULT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_approved` tinyint(1) NOT NULL DEFAULT '0',
  `is_visible` tinyint(1) NOT NULL DEFAULT '1',
  `is_pinned` tinyint(1) NOT NULL DEFAULT '0',
  `likes_count` int NOT NULL DEFAULT '0',
  `replies_count` int NOT NULL DEFAULT '0',
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `approved_at` timestamp NULL DEFAULT NULL,
  `approved_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `story_comments_approved_by_foreign` (`approved_by`),
  KEY `story_comments_story_id_is_approved_is_visible_index` (`story_id`,`is_approved`,`is_visible`),
  KEY `story_comments_user_id_created_at_index` (`user_id`,`created_at`),
  KEY `story_comments_story_id_created_at_index` (`story_id`,`created_at`),
  KEY `story_comments_parent_id_created_at_index` (`parent_id`,`created_at`),
  KEY `story_comments_is_pinned_index` (`is_pinned`),
  CONSTRAINT `story_comments_approved_by_foreign` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `story_comments_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `story_comments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `story_comments_story_id_foreign` FOREIGN KEY (`story_id`) REFERENCES `stories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `story_comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `story_comments_chk_1` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `story_comments`
--

LOCK TABLES `story_comments` WRITE;
/*!40000 ALTER TABLE `story_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `story_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `story_people`
--

DROP TABLE IF EXISTS `story_people`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `story_people` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `story_id` bigint unsigned NOT NULL,
  `person_id` bigint unsigned NOT NULL,
  `role` enum('voice_actor','director','writer','producer') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `story_people_story_id_person_id_role_unique` (`story_id`,`person_id`,`role`),
  KEY `story_people_story_id_index` (`story_id`),
  KEY `story_people_person_id_index` (`person_id`),
  CONSTRAINT `story_people_person_id_foreign` FOREIGN KEY (`person_id`) REFERENCES `people` (`id`) ON DELETE CASCADE,
  CONSTRAINT `story_people_story_id_foreign` FOREIGN KEY (`story_id`) REFERENCES `stories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `story_people`
--

LOCK TABLES `story_people` WRITE;
/*!40000 ALTER TABLE `story_people` DISABLE KEYS */;
INSERT INTO `story_people` VALUES (3,10,6,'voice_actor','2025-12-18 13:04:18','2025-12-18 13:14:55'),(4,11,6,'voice_actor','2025-12-18 13:17:29','2025-12-18 13:17:29'),(5,12,2,'voice_actor','2025-12-18 13:22:57','2025-12-18 13:22:57');
/*!40000 ALTER TABLE `story_people` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `story_ratings`
--

DROP TABLE IF EXISTS `story_ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `story_ratings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `story_id` bigint unsigned NOT NULL,
  `rating` decimal(2,1) NOT NULL,
  `review` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `story_ratings_user_id_story_id_unique` (`user_id`,`story_id`),
  KEY `story_ratings_user_id_index` (`user_id`),
  KEY `story_ratings_story_id_index` (`story_id`),
  KEY `story_ratings_rating_index` (`rating`),
  KEY `story_ratings_created_at_index` (`created_at`),
  CONSTRAINT `story_ratings_story_id_foreign` FOREIGN KEY (`story_id`) REFERENCES `stories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `story_ratings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `story_ratings`
--

LOCK TABLES `story_ratings` WRITE;
/*!40000 ALTER TABLE `story_ratings` DISABLE KEYS */;
/*!40000 ALTER TABLE `story_ratings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_licenses`
--

DROP TABLE IF EXISTS `student_licenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_licenses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `teacher_account_id` bigint unsigned NOT NULL,
  `student_user_id` bigint unsigned NOT NULL,
  `license_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_price` decimal(10,2) NOT NULL,
  `discounted_price` decimal(10,2) NOT NULL,
  `discount_amount` decimal(10,2) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` enum('active','expired','cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `activated_at` timestamp NULL DEFAULT NULL,
  `expired_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `student_licenses_teacher_account_id_student_user_id_unique` (`teacher_account_id`,`student_user_id`),
  KEY `student_licenses_student_user_id_foreign` (`student_user_id`),
  KEY `student_licenses_status_end_date_index` (`status`,`end_date`),
  CONSTRAINT `student_licenses_student_user_id_foreign` FOREIGN KEY (`student_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `student_licenses_teacher_account_id_foreign` FOREIGN KEY (`teacher_account_id`) REFERENCES `teacher_accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_licenses`
--

LOCK TABLES `student_licenses` WRITE;
/*!40000 ALTER TABLE `student_licenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_licenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscription_plans`
--

DROP TABLE IF EXISTS `subscription_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscription_plans` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `duration_days` int NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `myket_price` decimal(10,2) DEFAULT NULL,
  `myket_product_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cafebazaar_price` decimal(10,2) DEFAULT NULL,
  `cafebazaar_product_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'IRT',
  `discount_percentage` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `sort_order` int NOT NULL DEFAULT '0',
  `features` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `subscription_plans_slug_unique` (`slug`),
  CONSTRAINT `subscription_plans_chk_1` CHECK (json_valid(`features`))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription_plans`
--

LOCK TABLES `subscription_plans` WRITE;
/*!40000 ALTER TABLE `subscription_plans` DISABLE KEYS */;
INSERT INTO `subscription_plans` VALUES (1,'اشتراک یک ماهه','1month','1 ماه دسترسی نامحدود به تمامی داستان ها',30,160000.00,NULL,NULL,210000.00,'1-month-sub','IRT',0,1,0,1,'[\"1 \\u0645\\u0627\\u0647 \\u062f\\u0633\\u062a\\u0631\\u0633\\u06cc \\u0646\\u0627\\u0645\\u062d\\u062f\\u0648\\u062f \\u0628\\u0647 \\u062a\\u0645\\u0627\\u0645\\u06cc \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u0647\\u0627\"]','2025-10-12 11:20:19','2025-12-11 15:23:02'),(2,'اشتراک 3 ماهه','3month','3 ماه دسترسی نامحدود',90,480000.00,NULL,NULL,NULL,NULL,'IRT',20,1,1,2,'[\"3 \\u0645\\u0627\\u0647 \\u062f\\u0633\\u062a\\u0631\\u0633\\u06cc \\u0646\\u0627\\u0645\\u062d\\u062f\\u0648\\u062f\"]','2025-10-12 11:21:00','2025-10-12 11:21:00'),(3,'اشتراک 6 ماهه','6month','6 ماه دسترسی نامحدود به تمامی داستان ها',180,960000.00,NULL,NULL,NULL,NULL,'IRT',30,1,0,3,'[\"6 \\u0645\\u0627\\u0647 \\u062f\\u0633\\u062a\\u0631\\u0633\\u06cc \\u0646\\u0627\\u0645\\u062d\\u062f\\u0648\\u062f \\u0628\\u0647 \\u062a\\u0645\\u0627\\u0645\\u06cc \\u062f\\u0627\\u0633\\u062a\\u0627\\u0646 \\u0647\\u0627\"]','2025-10-12 11:21:58','2025-10-12 11:22:07'),(4,'اشتراک یکساله','1year','1 سال دسترسی نامحدود به تمامی داستان ها',365,1920000.00,NULL,NULL,NULL,NULL,'IRT',50,1,0,4,'[\"1 \\u0633\\u0627\\u0644 \\u062f\\u0633\\u062a\\u0631\\u0633\\u06cc \\u0646\\u0627\\u0645\\u062d\\u062f\\u0648\\u062f\"]','2025-10-12 11:22:53','2025-10-12 11:23:07');
/*!40000 ALTER TABLE `subscription_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscriptions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `type` enum('1month','3months','6months','1year') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('active','expired','cancelled','pending','trial') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `start_date` timestamp NULL DEFAULT NULL,
  `end_date` timestamp NULL DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `monthly_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `yearly_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `trial_days` int NOT NULL DEFAULT '0',
  `cancellation_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `renewal_count` int NOT NULL DEFAULT '0',
  `total_revenue` decimal(10,2) NOT NULL DEFAULT '0.00',
  `avg_monthly_revenue` decimal(10,2) NOT NULL DEFAULT '0.00',
  `subscription_metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'IRR',
  `auto_renew` tinyint(1) NOT NULL DEFAULT '1',
  `auto_renew_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `payment_method` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_platform` enum('website','cafebazaar','myket') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'website',
  `store_subscription_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `store_expiry_time` timestamp NULL DEFAULT NULL,
  `store_metadata` json DEFAULT NULL,
  `transaction_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subscriptions_user_id_index` (`user_id`),
  KEY `subscriptions_status_index` (`status`),
  KEY `subscriptions_end_date_index` (`end_date`),
  KEY `subscriptions_monthly_price_index` (`monthly_price`),
  KEY `subscriptions_yearly_price_index` (`yearly_price`),
  KEY `subscriptions_trial_days_index` (`trial_days`),
  KEY `subscriptions_cancelled_at_index` (`cancelled_at`),
  KEY `subscriptions_renewal_count_index` (`renewal_count`),
  KEY `subscriptions_total_revenue_index` (`total_revenue`),
  KEY `subscriptions_billing_platform_index` (`billing_platform`),
  KEY `subscriptions_store_subscription_id_index` (`store_subscription_id`),
  CONSTRAINT `subscriptions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `subscriptions_chk_1` CHECK (json_valid(`subscription_metadata`))
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscriptions`
--

LOCK TABLES `subscriptions` WRITE;
/*!40000 ALTER TABLE `subscriptions` DISABLE KEYS */;
INSERT INTO `subscriptions` VALUES (2,3,'1month','pending',NULL,NULL,800000.00,0.00,0.00,0,NULL,NULL,0,0.00,0.00,NULL,'IRR',1,1,NULL,'website',NULL,NULL,NULL,NULL,'2025-10-12 14:16:36','2025-10-12 14:16:36'),(3,3,'1month','pending',NULL,NULL,800000.00,0.00,0.00,0,NULL,NULL,0,0.00,0.00,NULL,'IRR',1,1,NULL,'website',NULL,NULL,NULL,NULL,'2025-10-12 14:38:36','2025-10-12 14:38:36'),(4,3,'3months','pending',NULL,NULL,1920000.00,0.00,0.00,0,NULL,NULL,0,0.00,0.00,NULL,'IRR',1,1,NULL,'website',NULL,NULL,NULL,NULL,'2025-10-12 14:38:46','2025-10-12 14:38:46'),(5,3,'1year','pending',NULL,NULL,4800000.00,0.00,0.00,0,NULL,NULL,0,0.00,0.00,NULL,'IRR',1,1,NULL,'website',NULL,NULL,NULL,NULL,'2025-10-12 14:38:56','2025-10-12 14:38:56'),(10,7,'1month','pending',NULL,NULL,1600000.00,0.00,0.00,0,NULL,NULL,0,0.00,0.00,NULL,'IRR',1,1,NULL,'website',NULL,NULL,NULL,NULL,'2025-10-13 02:47:31','2025-10-13 02:47:31'),(11,10,'1month','pending',NULL,NULL,1600000.00,0.00,0.00,0,NULL,NULL,0,0.00,0.00,NULL,'IRR',1,1,NULL,'website',NULL,NULL,NULL,NULL,'2025-10-29 17:45:18','2025-10-29 17:45:18'),(12,10,'1month','pending',NULL,NULL,10000.00,0.00,0.00,0,NULL,NULL,0,0.00,0.00,NULL,'IRR',1,1,NULL,'website',NULL,NULL,NULL,NULL,'2025-10-29 17:48:19','2025-10-29 17:48:19'),(13,3,'1month','active','2025-10-30 11:33:09','2025-11-29 11:33:09',10000.00,0.00,0.00,0,NULL,NULL,0,0.00,0.00,NULL,'IRR',1,1,NULL,'website',NULL,NULL,NULL,NULL,'2025-10-30 11:31:52','2025-10-30 11:33:09'),(14,11,'1month','pending',NULL,NULL,10000.00,0.00,0.00,0,NULL,NULL,0,0.00,0.00,NULL,'IRR',1,1,NULL,'website',NULL,NULL,NULL,NULL,'2025-11-01 16:29:12','2025-11-01 16:29:12'),(15,13,'1month','pending',NULL,NULL,10000.00,0.00,0.00,0,NULL,NULL,0,0.00,0.00,NULL,'IRR',1,1,NULL,'website',NULL,NULL,NULL,NULL,'2025-11-03 20:27:03','2025-11-03 20:27:03'),(16,1,'1month','pending',NULL,NULL,10000.00,0.00,0.00,0,NULL,NULL,0,0.00,0.00,NULL,'IRR',1,1,NULL,'website',NULL,NULL,NULL,NULL,'2025-11-03 20:33:46','2025-11-03 20:33:46'),(41,16,'1month','cancelled','2025-12-16 22:51:13','2026-01-15 22:51:13',1000.00,0.00,0.00,0,NULL,NULL,0,0.00,0.00,NULL,'IRT',0,1,'zarinpal','website',NULL,NULL,NULL,NULL,'2025-12-16 22:50:19','2025-12-17 01:12:34'),(42,17,'1month','pending','2025-12-17 23:51:11','2026-01-16 23:51:11',160000.00,0.00,0.00,0,NULL,NULL,0,0.00,0.00,NULL,'IRT',0,1,'zarinpal','website',NULL,NULL,NULL,NULL,'2025-12-17 23:51:11','2025-12-17 23:51:11'),(43,17,'1year','pending','2025-12-17 23:52:31','2026-12-17 23:52:31',960000.00,0.00,0.00,0,NULL,NULL,0,0.00,0.00,NULL,'IRT',0,1,'zarinpal','website',NULL,NULL,NULL,NULL,'2025-12-17 23:52:31','2025-12-17 23:52:31'),(44,17,'1month','active','2025-12-17 23:56:29','2026-01-16 23:56:29',1000.00,0.00,0.00,0,NULL,NULL,0,0.00,0.00,NULL,'IRT',0,1,'zarinpal','website',NULL,NULL,NULL,NULL,'2025-12-17 23:55:34','2025-12-17 23:56:29'),(45,16,'1month','active','2025-12-18 01:44:05','2026-01-17 01:44:05',1000.00,0.00,0.00,0,NULL,NULL,0,0.00,0.00,NULL,'IRT',0,1,'zarinpal','website',NULL,NULL,NULL,NULL,'2025-12-18 01:43:22','2025-12-18 01:44:05'),(46,7,'3months','pending','2025-12-18 12:35:13','2026-03-18 12:35:13',230400.00,0.00,0.00,0,NULL,NULL,0,0.00,0.00,NULL,'IRT',0,1,'zarinpal','website',NULL,NULL,NULL,NULL,'2025-12-18 12:35:13','2025-12-18 12:35:13');
/*!40000 ALTER TABLE `subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_alerts`
--

DROP TABLE IF EXISTS `system_alerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_alerts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `severity` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `acknowledged` tinyint(1) NOT NULL DEFAULT '0',
  `acknowledged_at` timestamp NULL DEFAULT NULL,
  `acknowledged_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resolved` tinyint(1) NOT NULL DEFAULT '0',
  `resolved_at` timestamp NULL DEFAULT NULL,
  `resolved_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `triggered_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_alerts_severity_triggered_at_index` (`severity`,`triggered_at`),
  KEY `system_alerts_acknowledged_triggered_at_index` (`acknowledged`,`triggered_at`),
  KEY `system_alerts_resolved_triggered_at_index` (`resolved`,`triggered_at`),
  KEY `system_alerts_triggered_at_index` (`triggered_at`),
  CONSTRAINT `system_alerts_chk_1` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_alerts`
--

LOCK TABLES `system_alerts` WRITE;
/*!40000 ALTER TABLE `system_alerts` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_alerts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_metrics`
--

DROP TABLE IF EXISTS `system_metrics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_metrics` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `metric_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `metric_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` decimal(10,4) NOT NULL,
  `unit` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `recorded_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_metrics_metric_type_recorded_at_index` (`metric_type`,`recorded_at`),
  KEY `system_metrics_metric_name_recorded_at_index` (`metric_name`,`recorded_at`),
  KEY `system_metrics_recorded_at_index` (`recorded_at`),
  CONSTRAINT `system_metrics_chk_1` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_metrics`
--

LOCK TABLES `system_metrics` WRITE;
/*!40000 ALTER TABLE `system_metrics` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_metrics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teacher_accounts`
--

DROP TABLE IF EXISTS `teacher_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teacher_accounts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `institution_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `institution_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `teaching_subject` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `years_of_experience` int NOT NULL,
  `certification_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `certification_authority` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `certification_date` date DEFAULT NULL,
  `student_count` int NOT NULL DEFAULT '0',
  `max_student_licenses` int NOT NULL DEFAULT '100',
  `discount_rate` decimal(5,2) NOT NULL DEFAULT '50.00',
  `commission_rate` decimal(5,2) NOT NULL DEFAULT '10.00',
  `coupon_code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `coupon_usage_count` int NOT NULL DEFAULT '0',
  `total_commission_earned` decimal(10,2) NOT NULL DEFAULT '0.00',
  `commission_settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `status` enum('pending','verified','suspended','expired') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `verification_documents` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `is_verified` tinyint(1) NOT NULL DEFAULT '0',
  `verified_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `teacher_accounts_user_id_unique` (`user_id`),
  UNIQUE KEY `teacher_accounts_coupon_code_unique` (`coupon_code`),
  KEY `teacher_accounts_status_is_verified_index` (`status`,`is_verified`),
  KEY `teacher_accounts_institution_type_index` (`institution_type`),
  KEY `teacher_accounts_coupon_code_index` (`coupon_code`),
  KEY `teacher_accounts_status_commission_rate_index` (`status`,`commission_rate`),
  CONSTRAINT `teacher_accounts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `teacher_accounts_chk_1` CHECK (json_valid(`commission_settings`)),
  CONSTRAINT `teacher_accounts_chk_2` CHECK (json_valid(`verification_documents`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teacher_accounts`
--

LOCK TABLES `teacher_accounts` WRITE;
/*!40000 ALTER TABLE `teacher_accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `teacher_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uptime_monitoring`
--

DROP TABLE IF EXISTS `uptime_monitoring`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `uptime_monitoring` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `service_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `service_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_up` tinyint(1) NOT NULL,
  `response_time` decimal(8,3) DEFAULT NULL,
  `status_code` int DEFAULT NULL,
  `error_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `checked_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `uptime_monitoring_service_name_checked_at_index` (`service_name`,`checked_at`),
  KEY `uptime_monitoring_is_up_checked_at_index` (`is_up`,`checked_at`),
  KEY `uptime_monitoring_checked_at_index` (`checked_at`),
  CONSTRAINT `uptime_monitoring_chk_1` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uptime_monitoring`
--

LOCK TABLES `uptime_monitoring` WRITE;
/*!40000 ALTER TABLE `uptime_monitoring` DISABLE KEYS */;
/*!40000 ALTER TABLE `uptime_monitoring` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_achievements`
--

DROP TABLE IF EXISTS `user_achievements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_achievements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `achievement_id` bigint unsigned NOT NULL,
  `unlocked_at` timestamp NULL DEFAULT NULL,
  `progress_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `is_notified` tinyint(1) NOT NULL DEFAULT '0',
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_achievements_user_id_achievement_id_unique` (`user_id`,`achievement_id`),
  KEY `user_achievements_user_id_unlocked_at_index` (`user_id`,`unlocked_at`),
  KEY `user_achievements_achievement_id_unlocked_at_index` (`achievement_id`,`unlocked_at`),
  CONSTRAINT `user_achievements_achievement_id_foreign` FOREIGN KEY (`achievement_id`) REFERENCES `achievements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_achievements_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_achievements_chk_1` CHECK (json_valid(`progress_data`)),
  CONSTRAINT `user_achievements_chk_2` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_achievements`
--

LOCK TABLES `user_achievements` WRITE;
/*!40000 ALTER TABLE `user_achievements` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_achievements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_activities`
--

DROP TABLE IF EXISTS `user_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_activities` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `activity_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `activity_target_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activity_target_id` bigint unsigned DEFAULT NULL,
  `activity_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `activity_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `is_public` tinyint(1) NOT NULL DEFAULT '1',
  `is_anonymous` tinyint(1) NOT NULL DEFAULT '0',
  `activity_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_activities_user_id_activity_at_index` (`user_id`,`activity_at`),
  KEY `user_activities_activity_type_activity_at_index` (`activity_type`,`activity_at`),
  KEY `user_activities_activity_target_type_activity_target_id_index` (`activity_target_type`,`activity_target_id`),
  KEY `user_activities_is_public_activity_at_index` (`is_public`,`activity_at`),
  CONSTRAINT `user_activities_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_activities_chk_1` CHECK (json_valid(`activity_data`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_activities`
--

LOCK TABLES `user_activities` WRITE;
/*!40000 ALTER TABLE `user_activities` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_badges`
--

DROP TABLE IF EXISTS `user_badges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_badges` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `badge_id` bigint unsigned NOT NULL,
  `earned_at` timestamp NULL DEFAULT NULL,
  `is_displayed` tinyint(1) NOT NULL DEFAULT '1',
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_badges_user_id_badge_id_unique` (`user_id`,`badge_id`),
  KEY `user_badges_user_id_earned_at_index` (`user_id`,`earned_at`),
  KEY `user_badges_badge_id_earned_at_index` (`badge_id`,`earned_at`),
  CONSTRAINT `user_badges_badge_id_foreign` FOREIGN KEY (`badge_id`) REFERENCES `badges` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_badges_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_badges_chk_1` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_badges`
--

LOCK TABLES `user_badges` WRITE;
/*!40000 ALTER TABLE `user_badges` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_badges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_challenges`
--

DROP TABLE IF EXISTS `user_challenges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_challenges` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `challenge_id` bigint unsigned NOT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `progress` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `completed_objectives` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `rewards_claimed` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_challenges_user_id_challenge_id_unique` (`user_id`,`challenge_id`),
  KEY `user_challenges_user_id_status_index` (`user_id`,`status`),
  KEY `user_challenges_challenge_id_status_index` (`challenge_id`,`status`),
  KEY `user_challenges_status_started_at_index` (`status`,`started_at`),
  CONSTRAINT `user_challenges_challenge_id_foreign` FOREIGN KEY (`challenge_id`) REFERENCES `challenges` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_challenges_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_challenges_chk_1` CHECK (json_valid(`progress`)),
  CONSTRAINT `user_challenges_chk_2` CHECK (json_valid(`completed_objectives`)),
  CONSTRAINT `user_challenges_chk_3` CHECK (json_valid(`rewards_claimed`)),
  CONSTRAINT `user_challenges_chk_4` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_challenges`
--

LOCK TABLES `user_challenges` WRITE;
/*!40000 ALTER TABLE `user_challenges` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_challenges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_coins`
--

DROP TABLE IF EXISTS `user_coins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_coins` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `total_coins` int NOT NULL DEFAULT '0',
  `available_coins` int NOT NULL DEFAULT '0',
  `earned_coins` int NOT NULL DEFAULT '0',
  `spent_coins` int NOT NULL DEFAULT '0',
  `last_earned_at` timestamp NULL DEFAULT NULL,
  `last_spent_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_coins_user_id_unique` (`user_id`),
  KEY `user_coins_user_id_available_coins_index` (`user_id`,`available_coins`),
  CONSTRAINT `user_coins_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_coins`
--

LOCK TABLES `user_coins` WRITE;
/*!40000 ALTER TABLE `user_coins` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_coins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_comments`
--

DROP TABLE IF EXISTS `user_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_comments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `commentable_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `commentable_id` bigint unsigned NOT NULL,
  `parent_id` bigint unsigned DEFAULT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_approved` tinyint(1) NOT NULL DEFAULT '1',
  `is_pinned` tinyint(1) NOT NULL DEFAULT '0',
  `likes_count` int NOT NULL DEFAULT '0',
  `replies_count` int NOT NULL DEFAULT '0',
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `commented_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_comments_user_id_commented_at_index` (`user_id`,`commented_at`),
  KEY `user_comments_commentable_type_commentable_id_index` (`commentable_type`,`commentable_id`),
  KEY `user_comments_parent_id_commented_at_index` (`parent_id`,`commented_at`),
  KEY `user_comments_is_approved_commented_at_index` (`is_approved`,`commented_at`),
  KEY `user_comments_is_pinned_commented_at_index` (`is_pinned`,`commented_at`),
  CONSTRAINT `user_comments_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `user_comments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_comments_chk_1` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_comments`
--

LOCK TABLES `user_comments` WRITE;
/*!40000 ALTER TABLE `user_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_follows`
--

DROP TABLE IF EXISTS `user_follows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_follows` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `follower_id` bigint unsigned NOT NULL,
  `following_id` bigint unsigned NOT NULL,
  `followed_at` timestamp NULL DEFAULT NULL,
  `is_mutual` tinyint(1) NOT NULL DEFAULT '0',
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_follows_follower_id_following_id_unique` (`follower_id`,`following_id`),
  KEY `user_follows_follower_id_followed_at_index` (`follower_id`,`followed_at`),
  KEY `user_follows_following_id_followed_at_index` (`following_id`,`followed_at`),
  KEY `user_follows_is_mutual_followed_at_index` (`is_mutual`,`followed_at`),
  CONSTRAINT `user_follows_follower_id_foreign` FOREIGN KEY (`follower_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_follows_following_id_foreign` FOREIGN KEY (`following_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_follows_chk_1` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_follows`
--

LOCK TABLES `user_follows` WRITE;
/*!40000 ALTER TABLE `user_follows` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_follows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_mentions`
--

DROP TABLE IF EXISTS `user_mentions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_mentions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `mentioned_by` bigint unsigned NOT NULL,
  `mentionable_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `mentionable_id` bigint unsigned NOT NULL,
  `context` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `mentioned_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_mentions_user_id_mentioned_at_index` (`user_id`,`mentioned_at`),
  KEY `user_mentions_mentioned_by_mentioned_at_index` (`mentioned_by`,`mentioned_at`),
  KEY `user_mentions_mentionable_type_mentionable_id_index` (`mentionable_type`,`mentionable_id`),
  KEY `user_mentions_is_read_mentioned_at_index` (`is_read`,`mentioned_at`),
  CONSTRAINT `user_mentions_mentioned_by_foreign` FOREIGN KEY (`mentioned_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_mentions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_mentions`
--

LOCK TABLES `user_mentions` WRITE;
/*!40000 ALTER TABLE `user_mentions` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_mentions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_permissions`
--

DROP TABLE IF EXISTS `user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `permission_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_permissions_user_id_permission_id_unique` (`user_id`,`permission_id`),
  KEY `user_permissions_permission_id_foreign` (`permission_id`),
  CONSTRAINT `user_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_permissions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_permissions`
--

LOCK TABLES `user_permissions` WRITE;
/*!40000 ALTER TABLE `user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_playlists`
--

DROP TABLE IF EXISTS `user_playlists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_playlists` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_public` tinyint(1) NOT NULL DEFAULT '0',
  `is_collaborative` tinyint(1) NOT NULL DEFAULT '0',
  `cover_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_playlists_user_id_created_at_index` (`user_id`,`created_at`),
  KEY `user_playlists_is_public_created_at_index` (`is_public`,`created_at`),
  KEY `user_playlists_is_collaborative_created_at_index` (`is_collaborative`,`created_at`),
  CONSTRAINT `user_playlists_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_playlists_chk_1` CHECK (json_valid(`metadata`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_playlists`
--

LOCK TABLES `user_playlists` WRITE;
/*!40000 ALTER TABLE `user_playlists` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_playlists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_points`
--

DROP TABLE IF EXISTS `user_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_points` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `total_points` int NOT NULL DEFAULT '0',
  `available_points` int NOT NULL DEFAULT '0',
  `spent_points` int NOT NULL DEFAULT '0',
  `level` int NOT NULL DEFAULT '1',
  `experience` int NOT NULL DEFAULT '0',
  `level_progress` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `last_activity_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_points_user_id_unique` (`user_id`),
  KEY `user_points_total_points_level_index` (`total_points`,`level`),
  KEY `user_points_level_experience_index` (`level`,`experience`),
  CONSTRAINT `user_points_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_points_chk_1` CHECK (json_valid(`level_progress`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_points`
--

LOCK TABLES `user_points` WRITE;
/*!40000 ALTER TABLE `user_points` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_profiles`
--

DROP TABLE IF EXISTS `user_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_profiles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `age` int NOT NULL,
  `favorite_category_id` bigint unsigned DEFAULT NULL,
  `preferences` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_profiles_favorite_category_id_foreign` (`favorite_category_id`),
  KEY `user_profiles_user_id_index` (`user_id`),
  KEY `user_profiles_age_index` (`age`),
  CONSTRAINT `user_profiles_favorite_category_id_foreign` FOREIGN KEY (`favorite_category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `user_profiles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_profiles_chk_1` CHECK (json_valid(`preferences`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_profiles`
--

LOCK TABLES `user_profiles` WRITE;
/*!40000 ALTER TABLE `user_profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_quiz_attempts`
--

DROP TABLE IF EXISTS `user_quiz_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_quiz_attempts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `question_id` bigint unsigned NOT NULL,
  `selected_answer` enum('a','b','c','d') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_correct` tinyint(1) NOT NULL,
  `coins_earned` int NOT NULL DEFAULT '0',
  `attempted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_quiz_attempts_user_id_question_id_unique` (`user_id`,`question_id`),
  KEY `user_quiz_attempts_user_id_attempted_at_index` (`user_id`,`attempted_at`),
  KEY `user_quiz_attempts_question_id_is_correct_index` (`question_id`,`is_correct`),
  CONSTRAINT `user_quiz_attempts_question_id_foreign` FOREIGN KEY (`question_id`) REFERENCES `episode_questions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_quiz_attempts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_quiz_attempts`
--

LOCK TABLES `user_quiz_attempts` WRITE;
/*!40000 ALTER TABLE `user_quiz_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_quiz_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_recommendation_history`
--

DROP TABLE IF EXISTS `user_recommendation_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_recommendation_history` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `story_id` bigint unsigned NOT NULL,
  `recommendation_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `recommendation_score` decimal(8,4) NOT NULL,
  `position` int NOT NULL,
  `clicked` tinyint(1) NOT NULL DEFAULT '0',
  `played` tinyint(1) NOT NULL DEFAULT '0',
  `favorited` tinyint(1) NOT NULL DEFAULT '0',
  `recommended_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_rec_hist_user_idx` (`user_id`,`recommended_at`),
  KEY `user_rec_hist_story_idx` (`story_id`,`recommended_at`),
  KEY `user_rec_hist_type_idx` (`recommendation_type`,`recommended_at`),
  KEY `user_rec_hist_clicked_idx` (`clicked`,`recommended_at`),
  CONSTRAINT `user_recommendation_history_story_id_foreign` FOREIGN KEY (`story_id`) REFERENCES `stories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_recommendation_history_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_recommendation_history`
--

LOCK TABLES `user_recommendation_history` WRITE;
/*!40000 ALTER TABLE `user_recommendation_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_recommendation_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_recommendation_preferences`
--

DROP TABLE IF EXISTS `user_recommendation_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_recommendation_preferences` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `preference_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `preference_value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` decimal(5,2) NOT NULL DEFAULT '1.00',
  `interaction_count` int NOT NULL DEFAULT '1',
  `last_updated` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_pref_unique` (`user_id`,`preference_type`,`preference_value`),
  KEY `user_pref_type_idx` (`user_id`,`preference_type`),
  KEY `pref_type_value_idx` (`preference_type`,`preference_value`),
  CONSTRAINT `user_recommendation_preferences_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_recommendation_preferences`
--

LOCK TABLES `user_recommendation_preferences` WRITE;
/*!40000 ALTER TABLE `user_recommendation_preferences` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_recommendation_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_role`
--

DROP TABLE IF EXISTS `user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_role` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_role_user_id_role_id_unique` (`user_id`,`role_id`),
  KEY `user_role_role_id_foreign` (`role_id`),
  CONSTRAINT `user_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_role_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_role`
--

LOCK TABLES `user_role` WRITE;
/*!40000 ALTER TABLE `user_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_similarity_matrix`
--

DROP TABLE IF EXISTS `user_similarity_matrix`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_similarity_matrix` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `similar_user_id` bigint unsigned NOT NULL,
  `similarity_score` decimal(5,4) NOT NULL,
  `common_items` int NOT NULL,
  `calculated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_similarity_matrix_user_id_similar_user_id_unique` (`user_id`,`similar_user_id`),
  KEY `user_sim_user_idx` (`user_id`,`similarity_score`),
  KEY `user_sim_similar_idx` (`similar_user_id`,`similarity_score`),
  CONSTRAINT `user_similarity_matrix_similar_user_id_foreign` FOREIGN KEY (`similar_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_similarity_matrix_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_similarity_matrix`
--

LOCK TABLES `user_similarity_matrix` WRITE;
/*!40000 ALTER TABLE `user_similarity_matrix` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_similarity_matrix` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_social_settings`
--

DROP TABLE IF EXISTS `user_social_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_social_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `show_activity_feed` tinyint(1) NOT NULL DEFAULT '1',
  `allow_followers` tinyint(1) NOT NULL DEFAULT '1',
  `allow_sharing` tinyint(1) NOT NULL DEFAULT '1',
  `allow_comments` tinyint(1) NOT NULL DEFAULT '1',
  `allow_mentions` tinyint(1) NOT NULL DEFAULT '1',
  `notify_follows` tinyint(1) NOT NULL DEFAULT '1',
  `notify_shares` tinyint(1) NOT NULL DEFAULT '1',
  `notify_comments` tinyint(1) NOT NULL DEFAULT '1',
  `notify_mentions` tinyint(1) NOT NULL DEFAULT '1',
  `privacy_settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_social_settings_user_id_unique` (`user_id`),
  CONSTRAINT `user_social_settings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_social_settings_chk_1` CHECK (json_valid(`privacy_settings`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_social_settings`
--

LOCK TABLES `user_social_settings` WRITE;
/*!40000 ALTER TABLE `user_social_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_social_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_streaks`
--

DROP TABLE IF EXISTS `user_streaks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_streaks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `streak_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `current_streak` int NOT NULL DEFAULT '0',
  `longest_streak` int NOT NULL DEFAULT '0',
  `last_activity_date` date NOT NULL,
  `streak_start_date` date DEFAULT NULL,
  `streak_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_streaks_user_id_streak_type_unique` (`user_id`,`streak_type`),
  KEY `user_streaks_streak_type_current_streak_index` (`streak_type`,`current_streak`),
  KEY `user_streaks_streak_type_longest_streak_index` (`streak_type`,`longest_streak`),
  CONSTRAINT `user_streaks_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_streaks_chk_1` CHECK (json_valid(`streak_data`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_streaks`
--

LOCK TABLES `user_streaks` WRITE;
/*!40000 ALTER TABLE `user_streaks` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_streaks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `phone_number` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `profile_image_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('parent','child','admin','basic') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'basic',
  `status` enum('active','inactive','suspended','pending') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `requires_2fa` tinyint(1) NOT NULL DEFAULT '0',
  `phone_verified_at` timestamp NULL DEFAULT NULL,
  `parent_id` bigint unsigned DEFAULT NULL,
  `timezone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Asia/Tehran',
  `registration_source` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referral_code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referred_by` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `os` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_sessions` int NOT NULL DEFAULT '0',
  `total_play_time` int NOT NULL DEFAULT '0',
  `total_favorites` int NOT NULL DEFAULT '0',
  `total_ratings` int NOT NULL DEFAULT '0',
  `total_spent` decimal(10,2) NOT NULL DEFAULT '0.00',
  `last_activity_at` timestamp NULL DEFAULT NULL,
  `first_purchase_at` timestamp NULL DEFAULT NULL,
  `last_purchase_at` timestamp NULL DEFAULT NULL,
  `analytics_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `preferences` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `last_login_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_phone_number_unique` (`phone_number`),
  KEY `users_phone_number_index` (`phone_number`),
  KEY `users_parent_id_index` (`parent_id`),
  KEY `users_status_index` (`status`),
  KEY `users_registration_source_index` (`registration_source`),
  KEY `users_referral_code_index` (`referral_code`),
  KEY `users_referred_by_index` (`referred_by`),
  KEY `users_device_type_index` (`device_type`),
  KEY `users_country_index` (`country`),
  KEY `users_last_activity_at_index` (`last_activity_at`),
  KEY `users_first_purchase_at_index` (`first_purchase_at`),
  KEY `users_last_purchase_at_index` (`last_purchase_at`),
  CONSTRAINT `users_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `users_chk_1` CHECK (json_valid(`analytics_data`)),
  CONSTRAINT `users_chk_2` CHECK (json_valid(`preferences`))
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'09138333293','$2y$12$4scguNSEbOLKM4wZb7/HJu0T27/69gtoqR6lzs45lMT4q4uIViNLS','Armiti','Admin',NULL,'admin','active',1,NULL,NULL,'Asia/Tehran',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0.00,NULL,NULL,NULL,NULL,NULL,'2025-11-03 20:32:44','2025-10-05 19:57:22','2025-11-03 20:32:44'),(2,'09025472668','$2y$12$jOj2UWr37Sums7fXCed0bO9hNmrHk.15ijn8K6AxSysPkf2KJGp9m','Sogand','Admin',NULL,'admin','active',1,NULL,NULL,'Asia/Tehran',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0.00,NULL,NULL,NULL,NULL,NULL,'2025-11-03 19:46:32','2025-10-05 19:57:24','2025-11-03 19:46:32'),(3,'09136708883','$2y$12$sKTpOL.iZ4r6qo0XagDoWux4JvZFju9AM/WFoePLWMI0vKHk70BYS','Abolfazl','Admin',NULL,'admin','active',0,NULL,NULL,'Asia/Tehran',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0.00,NULL,NULL,NULL,NULL,NULL,'2025-12-18 13:21:26','2025-10-05 19:57:24','2025-12-18 13:21:26'),(4,'09393676109','$2y$12$/xtMP9eAO8oT5oxAdc.9f.x1XUp0Nu9XVUl.ClbX3V9IMD6OimQ8O','Mahmood','Admin',NULL,'admin','active',1,NULL,NULL,'Asia/Tehran',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0.00,NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-05 19:57:24','2025-10-05 19:57:24'),(5,'09131397003','$2y$12$UiQPDXkSmIL5rFxBOqn9xu3ZzBAniY7H5mA3wKFrTL4K2RyvHK/Xq','Masood','Admin',NULL,'admin','active',1,NULL,NULL,'Asia/Tehran',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0.00,NULL,NULL,NULL,NULL,NULL,'2025-11-05 19:05:09','2025-10-05 19:57:24','2025-11-05 19:05:09'),(7,'09135740095',NULL,'ESMAT','ANSARI',NULL,'parent','active',0,'2025-10-13 02:36:08',NULL,'Asia/Tehran',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0.00,NULL,NULL,NULL,NULL,NULL,'2025-12-18 12:34:58','2025-10-13 02:36:08','2025-12-18 12:34:58'),(8,'09966190559',NULL,'تست','بازار',NULL,'parent','active',0,'2025-10-18 10:30:32',NULL,'Asia/Tehran',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0.00,NULL,NULL,NULL,NULL,NULL,'2025-11-29 12:08:43','2025-10-18 10:30:32','2025-11-29 12:08:43'),(9,'09929767361',NULL,'امین','لوو',NULL,'parent','active',0,'2025-10-18 10:50:06',NULL,'Asia/Tehran',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0.00,NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-18 10:50:06','2025-10-18 10:50:06'),(10,'09389264688',NULL,'amir','mousavi',NULL,'parent','active',0,'2025-10-29 17:25:56',NULL,'Asia/Tehran',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0.00,NULL,NULL,NULL,NULL,NULL,'2025-10-29 17:44:34','2025-10-29 17:25:56','2025-10-29 17:44:34'),(11,'09166252484',NULL,'محمد','نادعلی',NULL,'parent','active',0,'2025-10-31 00:44:05',NULL,'Asia/Tehran',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0.00,NULL,NULL,NULL,NULL,NULL,'2025-11-01 16:28:43','2025-10-31 00:44:05','2025-11-01 16:28:43'),(12,'09966397911',NULL,'تست','مایکتت',NULL,'parent','active',0,'2025-11-02 15:18:13',NULL,'Asia/Tehran',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0.00,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-02 15:18:13','2025-11-02 15:18:13'),(13,'09388052829',NULL,'sli','yazdani',NULL,'parent','active',0,'2025-11-03 20:08:42',NULL,'Asia/Tehran',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0.00,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-03 20:08:42','2025-11-03 20:08:42'),(14,'09123793284',NULL,'علی','رضا',NULL,'parent','active',0,'2025-11-16 21:03:49',NULL,'Asia/Tehran',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0.00,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-16 21:03:49','2025-11-16 21:03:49'),(15,'09926418233',NULL,'شراره','شاهین',NULL,'parent','active',0,'2025-11-17 19:05:04',NULL,'Asia/Tehran',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0.00,NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-17 19:05:04','2025-11-17 19:05:04'),(16,'09339487801',NULL,'alireza','adamiyat',NULL,'parent','active',0,'2025-12-16 22:49:05',NULL,'Asia/Tehran',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0.00,NULL,NULL,NULL,NULL,NULL,'2025-12-18 01:43:10','2025-12-16 22:49:05','2025-12-18 01:43:10'),(17,'09387925245',NULL,'علیرضا','پشم فروش',NULL,'parent','active',0,'2025-12-17 23:49:54',NULL,'Asia/Tehran',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0.00,NULL,NULL,NULL,NULL,NULL,'2025-12-17 23:50:50','2025-12-17 23:49:54','2025-12-17 23:50:50');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'sarvca_st'
--

--
-- Dumping routines for database 'sarvca_st'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-18 10:08:46
